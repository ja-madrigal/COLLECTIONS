# Density

Type: dimension
Status: draft

## Intent

Help interfaces become information-efficient without making them feel
compressed, difficult to scan, or cognitively exhausting.

## Required Context

Density cannot be judged from visual structure alone.

Before making a strong density judgment, understand when possible:

- who the primary user is
- what they are trying to accomplish
- how frequently they use the interface
- whether they are scanning, comparing, reading, entering, or monitoring information
- whether the workflow is familiar or unfamiliar
- whether speed, comprehension, attention, or exploration is more important

If this context is unknown, do not infer it from the visual form of the interface.

For example, the presence of dashboards, tables, charts, or dense information does not by itself imply that the interface should be dense.

When important context is missing:

1. Separate direct observations from interpretations.
2. Identify assumptions explicitly.
3. Avoid strong recommendations that depend on those assumptions.
4. Ask for the missing context when it would materially change the judgment.
5. Prefer a lower-confidence assessment over inventing user or task context.

## Signals

Density may be too high when:

- Groups are difficult to distinguish.
- Interactive elements begin visually merging.
- Hierarchy becomes unclear because whitespace has disappeared.
- Reading or scanning requires excessive concentration.

Density may be too low when:

- Related elements feel disconnected.
- Users must travel unnecessarily across the interface.
- Whitespace dominates the information structure.
- Repetitive workflows feel inefficient.

## Levers

Density can be changed through:

- internal padding
- spacing between elements
- spacing between groups
- typography
- line height
- control size
- content quantity
- grouping
- dividers

Prefer changing spacing and grouping before reducing text size.

## Relationships

Changing density can affect:

- breathing
- hierarchy
- complexity
- scanability

## Context

Higher density may be appropriate for:

- expert workflows
- repetitive tasks
- tables
- monitoring
- comparison-heavy interfaces

Lower density may be appropriate for:

- onboarding
- unfamiliar workflows
- low-frequency tasks
- high-attention decisions

## Principle

Density is not a fixed value.

The appropriate density depends on the task, user, information,
and surrounding design decisions.

Spatial occupancy and user burden are not the same thing.

An interface with many elements may still be manageable when the user
is familiar, confident, and able to find what they need.

An interface with very few elements may still demand significant
attention, interpretation, action, or responsibility.

Do not use the amount of visible content alone as evidence that an
interface is too dense or too sparse.