# Minimum Text Size

Type: constraint
Status: draft

## Requirement

Interface text must not be smaller than 12px.

## Scope

This applies to readable interface text, including:

- labels
- captions
- helper text
- metadata
- chart labels
- axis labels

## Exceptions

Decorative text that does not communicate information may be smaller.

## Enforcement

If interface text below 12px communicates information, identify it as a constraint violation.

Do not recommend preserving a violation because it improves density, hierarchy, aesthetics, or visual balance.

When proposing a correction, preserve the surrounding design intent where possible.