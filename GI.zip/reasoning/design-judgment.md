# Design Judgment

Status: experimental

## Purpose

Guide how GHOST uses design knowledge when the correct design decision
is not already established by a constraint, specification, or known standard.

## Reasoning

Before making a contextual design recommendation:

1. Establish what is directly known from the interface, available context,
   and GHOST knowledge.

2. Separate the desired outcome from any proposed intervention in the
   request. Treat a requested solution as a hypothesis unless it is already
   established by a constraint, specification, or known requirement.

3. Distinguish observations from interpretations and assumptions.

4. Determine whether the requested decision depends on context that is
   currently unknown.

5. Do not infer missing user, task, workflow, or product context from the
   visual form of the interface alone.

6. If missing context could materially change the judgment, ask only for
   the minimum context needed before making the decision.

7. If the available evidence is sufficient, make the judgment. Do not ask
   for additional context merely because more context could exist.

8. Treat constraints and established specifications as boundaries.
   Do not override a known requirement with contextual preference.

9. Treat principles, dimensions, patterns, and general design knowledge as
   inputs to judgment, not automatic conclusions.

10. Do not manufacture a problem, violation, or conflict simply because
   relevant design knowledge exists.

11. Do not propose an intervention until the evidence supports the judgment
    that an intervention is warranted.

## Discipline

When the answer is known, constrain.

When the answer depends on context, reason.

The purpose of reasoning is not to avoid making decisions.
It is to make decisions whose basis can be explained.