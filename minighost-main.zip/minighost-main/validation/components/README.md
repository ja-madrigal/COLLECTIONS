# Component Testing Templates

This directory contains templates for testing Unity components in both light and dark modes.

## Template File

**`component-test-template.html`** - A reusable template for testing any component in both modes.

### How to Use

1. Open `component-test-template.html`
2. Find the `<!-- DROP YOUR COMPONENT HERE -->` comments in both the light and dark sections
3. Replace the placeholder with your component HTML
4. The template provides:
   - Two vertical sections (light on top, dark on bottom)
   - Light section background: `#fbfbfb`
   - Dark section background: `#343A46`
   - 40px padding inside each section
   - Labels indicating "Light Mode" and "Dark Mode"
   - Link to `BOO/unity/dist/tokens.css` for design tokens

### Example

```html
<!-- Light Mode Section -->
<div class="section light-section">
  <div class="component-container">
    <div class="label">Light Mode</div>
    <!-- Your component here -->
    <div class="your-component">...</div>
  </div>
</div>

<!-- Dark Mode Section -->
<div class="section dark-section">
  <div class="component-container">
    <div class="label">Dark Mode</div>
    <!-- Your component here -->
    <div class="your-component">...</div>
  </div>
</div>
```

## Recent Tests

### Window Chrome Test (2026-06-17)

**File:** `window-chrome-test.html`

**What was tested:**
- Window Chrome component in both light and dark modes
- Validated against Figma specs (nodes 190-4549 for light, 11009-719 for dark)
- Verified background opacity (light: 95%, dark: 75%)
- Confirmed gradient overlay matches Figma
- Validated masthead controls (4 icons: back, minimize, maximize, close)
- Verified dimensions (1132px × 782px, 9px radius, 12.5px backdrop blur)

**Token corrections made:**
- Updated `background-app` dark mode from 95% to 75% opacity in `02-tokens.yaml`
- Regenerated `tokens.css` to apply the correction

**Key specs from Figma:**
- Width: 1132px
- Height: 782px
- Radius: 9px
- Shadow: 0px 4px 4px 0px rgba(0,0,0,0.06)
- Backdrop blur: 12.5px
- Gradient: 5 stops at specific percentages
- Masthead: 60px height, 25px/14px padding, 24px control gap, 16px button size, 10px icon size

## Verified Components

This table tracks Unity components that have been verified against Figma specs and updated in the component quick ref.

| Component | Date Verified | Figma Nodes (Light/Dark) | Quick Ref Updated | Test File | Notes |
|-----------|---------------|--------------------------|-------------------|-----------|-------|
| Window Chrome | 2026-06-17 | 190-4549 / 11009-719 | Yes | window-chrome-test.html | Updated background-app dark mode opacity from 95% to 75%; added complete masthead icon set |

## Notes

- Always link to `../../BOO/unity/dist/tokens.css` for design tokens
- Use semantic token names from the component quick ref
- Test both modes to ensure contrast and accessibility compliance
- Compare with Figma specs when validating components
