# Reference Screens

Known-good reference screens used for comparison during the validation pass. These are the ground truth — agent outputs are compared against these.

---

*Reference screens coming in Phase 2.*
