```
░█▄█░▀█▀░█▀█░▀█▀░█▀▀░█░█░█▀█░█▀▀░▀█▀
░█░█░░█░░█░█░░█░░█░█░█▀█░█░█░▀▀█░░█░
░▀░▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░░▀░
```

# MINIGHOST — Version Alpha

**MINIGHOST** is a constraint system for AI Agents. It guides the agent to produce **full UI screens** in the Dell Unity design language. It uses the **Book of Origins (BOO)** — a structured design spec — to guide the composition of existing Unity components into complete screens.

Version Alpha outputs are browser-based HTML comps and prototypes that mimic native and electron UIs — no build toolchain required on the consumer side.

The goal is consistency first, creative generation second.

---

## Available on Minighost

| System | Folder | Status | Figma Link |
|---|---|---|---|
| `unity` | `BOO/unity/` | Active — Dell Unity design system | [Figma](https://www.figma.com/design/ti10RX3jGJ7pw0cfpDEVt8/Unity-Component-Library) |

---

## Installation

Requires **git** and **Node.js** installed. Requires git access to `githubcsg.cec.delllabs.net`.

Open Terminal and run:

```powershell
git clone https://githubcsg.cec.delllabs.net/CSG-EDG/minighost $env:USERPROFILE\minighost; cd $env:USERPROFILE\minighost; node setup.js
```

That's it! MINIGHOST is ready. Open your project in Windsurf and run `ghost --project` in the terminal — or just ask the AI agent to do it.

**Enable for a project** — navigate to your design project folder and run:
```sh
ghost --project
```

---

## CLI Commands

| Command | Description |
|---|---|
| `ghost --project` | Enable MiniGhost in the current project folder |
| `ghost --project-off` | Remove MiniGhost from the current project folder |
| `ghost --update` | Update to latest version |
| `ghost --uninstall` | Remove MiniGhost and uninstall |
| `ghost --status` | Show current status and version |
| `ghost --help` | Show usage |

---

## How to Enable MINIGHOST in a Project

Navigate to your design project folder and run:

```powershell
ghost --project
```

This creates two files in the project root:
- **`.windsurfrules`** — picked up automatically by Windsurf
- **`CLAUDE.md`** — picked up automatically by Claude Code

Both files contain the full MiniGhost ruleset with absolute paths to the BOO files, so the AI agent can read them from this project. MiniGhost is only active in projects where you run this command.

To remove MINIGHOST from a project:

```powershell
ghost --project-off
```

This cleanly removes both files. No orphaned content is left behind.

---

## Ready to generate?

See [documentation/How-to-use-GHOST.md](documentation/How-to-use-GHOST.md) for a full walkthrough — prompting, iterating, running validation, and more.

---

## The Book of Origins (BOO)

BOO is the knowledge layer. Contains principles, patterns, and design standards. Each design system has its own BOO under `BOO/{system}/boo/`. The agent consults knowledge files before generating anything.

| File | Role |
|---|---|
| `01-constitution.yaml` | **The rules.** Generation sequence, page frameworks, grid models, color usage, components, typography, shape, elevation, motion, and accessibility hard rules. |
| `02-tokens.yaml` | **The values.** Single canonical source for all design tokens — primitives, semantic colors (light + dark), typography, spacing, radius, elevation, motion, grid, z-index, and all 30+ components. |
| `03-icon-map.yaml` | **The visual vocabulary.** Maps every icon name to its SVG path. The agent looks up icons here — it never invents names. |
| `04-accessibility.md` | **The hard limits.** WCAG 2.2 AA + Microsoft Learn requirements. Every MUST and MUST NOT is a release blocker. |
| `05-component-quick-ref.yaml` | **The rendering spec.** Dimensions, colors, and states per component. Agent reads the relevant entry before rendering any component. |

---

## Skills

Skills are reusable validation and quality check procedures that the AI agent can run. Skills are located in `BOO/{system}/skills/{skill-name}/skill.md` with frontmatter metadata:

- `name`: skill identifier
- `description`: what the skill does
- `trigger`: when the skill runs (e.g., "after_generation")
- `execution`: how the skill runs (e.g., "automatic or user_prompt")
- `scope`: what the skill applies to

**Current Skills:**
- `technical-validation` — Self-validates Unity design system output against technical criteria (Dimensions 2-4 of the validation rubric) before human visual review.

Skills run automatically after screen generation (if `trigger: "after_generation"`) or can be invoked by user prompt.

---

## Project Structure

For detailed folder structure and file descriptions, see [documentation/folder-structure.md](documentation/folder-structure.md).

---

## The Agent Contract

With MiniGhost enabled, the agent automatically:

1. Reads BOO knowledge files before generating anything.
2. Follows the 9-step generation sequence — no skipping, no reordering.
3. Uses only tokens defined in `02-tokens.yaml`. No invented values.
4. Uses only icons and names from `03-icon-map.yaml`. No invented names.
5. Consults `05-component-quick-ref.yaml` before rendering any component.
6. Emits a manifest block at the top of every output (screen name, framework, grid, mode, primary action, a11y status).
7. Runs the acceptance checklist before returning any artifact.