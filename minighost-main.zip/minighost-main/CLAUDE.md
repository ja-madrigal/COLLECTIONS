# MINIGHOST
AI-assisted UI generation.

## Before You Do Anything

Ask the user which design system they want to work with.

Available systems:
- `unity` — Dell's Unity design system

Once the user answers, read the Book of Origins (BOO) for that system in this order:

1. `BOO/{system}/boo/01-constitution.yaml` — the rules
2. `BOO/{system}/boo/02-tokens.yaml` — the values
3. `BOO/{system}/boo/03-icon-map.yaml` — flat list of all icons; each entry has name + svg path
4. `BOO/{system}/boo/04-accessibility.md` — the hard limits
5. `BOO/{system}/boo/05-component-quick-ref.yaml` — rendering dimensions, colors, and states per component

Do not generate, modify, or prototype anything until the user has answered and all five files are read.

At step 7b of the generation sequence, use `05-component-quick-ref.yaml` as your lookup table.
Do not render a component without first reading its entry here.

## Component Selection (step 7a — before rendering)

Before choosing components, consult these files in order:

1. `BOO/{system}/component-selection/04-patterns-manifest.yaml` — check for a named screen or section recipe first. If a pattern matches, record it and fill its key_decisions.
2. `BOO/{system}/component-selection/01-task-ontology.md` — if no pattern matches, walk the task tree to find candidate components.
3. `BOO/{system}/component-selection/02-selection-decisions.md` — if two or more candidates are returned, use the decision tables to resolve.
4. `BOO/{system}/component-selection/03-components-manifest.yaml` — after selecting a component, read its entry for anti-patterns and accessibility requirements.

Do not select components by keyword matching. Always enter from the task.

## Skills

Skills are reusable validation and quality check procedures. Skills are located in `BOO/{system}/skills/{skill-name}/skill.md` with frontmatter metadata:
- `name`: skill identifier
- `description`: what the skill does
- `trigger`: when the skill runs (e.g., "after_generation")
- `execution`: how the skill runs (e.g., "automatic or user_prompt")
- `scope`: what the skill applies to

After generating a screen, run the `technical-validation` skill (located in `BOO/{system}/skills/technical-validation/skill.md`) to self-validate against technical criteria (Dimensions 2-4 of the validation rubric). The agent can also run skills on user prompt.

## What We're Building

Browser-based HTML prototypes that mimic Windows native / Electron apps. No build toolchain. One `tokens.css` import, semantic CSS custom properties, `data-theme="light"` or `data-theme="dark"` on the root.

Import tokens as: `BOO/{system}/dist/tokens.css`

## Rules

- Use only tokens from the active system's `02-tokens.yaml`. No invented values, no raw hex.
- Use only icon names from the active system's `03-icon-map.yaml`. No invented names. SVG files live at the path listed in each entry.
- One page framework per screen. One color mode per screen.
- Follow the 9-step generation sequence in the constitution.
- Every output starts with the manifest block (screen, framework, grid, mode, primary action, a11y status).

## Rebuilding Tokens

If `02-tokens.yaml` changes, run:
```sh
python scripts/build-tokens.py
```
Commit the generated outputs under `BOO/{system}/dist/`.
