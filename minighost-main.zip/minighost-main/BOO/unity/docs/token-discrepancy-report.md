# Unity Token Discrepancy Report

**Project:** MINIGHOST — AI-assisted UI generation POC
**Audience:** Unity design system team
**Method:** Figma component nodes pulled via MCP and diffed against `systems/unity/boo/02-tokens.yaml`
**Last updated:** 2026-06-10

Figma is treated as the source of truth throughout. Every discrepancy listed here means the token file does not match what Figma renders. These are fixes needed in the token file, not in Figma.

---

## How to read this report

Each entry has:
- **Component + state** — where the discrepancy appears
- **Token file says** — what `unity-tokens.yaml` currently specifies
- **Figma renders** — what the Figma component actually shows
- **Figma node** — the node ID used to validate
- **Recommended fix** — the change needed in the token file

---

## Discrepancies

### 1. Button / Secondary — default border (light mode)

| Field | Value |
|---|---|
| Component | `button.secondary.default.light.border` |
| Token file says | `semantic.color.light.border.brand-base` → `#0672CB` (blue.600) |
| Figma renders | `#0063B8` (blue.700 = `border-brand-emphasis`) |
| Figma node | `12044-1915` (light mode button table) |
| Recommended fix | Change `secondary.default.light.border` from `border-brand-base` to `border-brand-emphasis` |

---

### 2. Button / Secondary — hover border (light mode)

| Field | Value |
|---|---|
| Component | `button.secondary.hover.light.border` |
| Token file says | `semantic.color.light.border.brand-emphasis` → `#0063B8` (blue.700) |
| Figma renders | `#0063B8` (blue.700) — **matches** |
| Figma node | `12044-1915` |
| Note | No change needed. Listed for completeness — hover was already correct. |

---

### 3. Button / Secondary — default border (dark mode)

| Field | Value |
|---|---|
| Component | `button.secondary.default.dark.border` |
| Token file says | `semantic.color.dark.border.brand-base` → `#0672CB` (blue.600) |
| Figma renders | `#F5F6F7` (gray.100 = `border-brand-inverse-base`) |
| Figma node | `12044-2736` (dark mode button table) |
| Recommended fix | Change `secondary.default.dark.border` from `border-brand-base` to `border-brand-inverse-base` |

---

### 4. Button / Secondary — hover + pressed border (dark mode)

| Field | Value |
|---|---|
| Component | `button.secondary.hover.dark.border` and `button.secondary.pressed.dark.border` |
| Token file says | `border-brand-emphasis` / `border-brand-strong` respectively |
| Figma renders | `#F5F6F7` (gray.100 = `border-brand-inverse-base`) for both |
| Figma node | `12044-2736` |
| Recommended fix | Align hover and pressed dark borders to `border-brand-inverse-base` to match default — Figma uses the same white border across all non-disabled dark secondary states |

---

### 5. Textbox — watermark text color (dark mode)

| Field | Value |
|---|---|
| Component | `textbox.watermark.dark.foreground` |
| Token file says | `semantic.color.dark.foreground.neutral-contrast` → `#C5D4E3` (slate.200) |
| Figma renders | `#F5F6F7` (gray.100 = `foreground-default`) |
| Figma node | `12049-3901` (dark mode textbox table) |
| Recommended fix | Change `textbox.watermark.dark.foreground` to `foreground-default`, OR update the Figma component to use `foreground-neutral-contrast` (slate.200) — the current Figma value makes the watermark text indistinguishable from typed text in dark mode, which is likely a Figma error |
| Flag for designer | If watermark text = `foreground-default` is intentional in dark mode, the token file needs updating. If it's a Figma mistake, the component needs fixing. Needs a design decision. |

---

### 5. Hyperlink — disabled foreground (dark mode)

| Field | Value |
|---|---|
| Component | `hyperlink.disabled.dark.foreground` |
| Token file says | `foreground-disabled-brand` (expected to be brand blue at opacity) |
| Figma renders | `#636363` at 40% opacity = `rgba(99,99,99,0.4)` — neutral gray, not brand blue |
| Figma node | `12046-10399` (dark mode hyperlink table) |
| Recommended fix | Confirm whether `foreground-disabled-brand` in dark mode is intentionally mapped to neutral gray (#636363), or whether dark disabled hyperlinks should remain brand-colored. If neutral is correct, rename the token or add a separate dark-mode alias. |
| Flag for designer | Light disabled = `rgba(6,114,203,0.4)` (brand blue). Dark disabled = `rgba(99,99,99,0.4)` (neutral gray). This is a significant visual difference — may be intentional for contrast reasons on dark backgrounds, but the token naming is misleading. |

---

### 6. Hyperlink — focused text color (dark mode only)

| Field | Value |
|---|---|
| Component | `hyperlink.focus.dark.foreground` |
| Token file says | No distinct focused foreground token; focus is outline-only |
| Figma renders | Text shifts from `#31A2E3` (default) to `#94DCF7` (lighter blue) when focused in dark mode |
| Figma node | `12046-10399` |
| Recommended fix | Add a `foreground-interactive-accessible` (or equivalent) token for the focused text state in dark mode, mapped to `#94DCF7`. Light mode does not change text color on focus — this is a dark-mode-only behavior that improves visibility of the focused state against dark backgrounds. |

---

### 8. Masthead — dark background opacity (internal Figma conflict)

| Field | Value |
|---|---|
| Component | `masthead.dark.background` |
| Figma spec table says | `#FFFFFF` at 30% → `rgba(255,255,255,0.30)` |
| Figma component code renders | `rgba(255,255,255,0.05)` (5% white overlay) |
| Figma node | `11522-2525` (dark mode masthead table) |
| Recommended fix | Align the spec table to match the component code: `rgba(255,255,255,0.05)`. The component code is the authoritative render. The 30% value in the spec table appears to be a stale or incorrect annotation. Needs designer confirmation. |

---

### 9. Masthead — icon color (dark mode)

| Field | Value |
|---|---|
| Component | `masthead.dark.foreground` |
| Token file says | `foreground-default` dark → `#F5F6F7` |
| Figma spec table renders | `#FFFFFF` (pure white) |
| Figma node | `11522-2525` |
| Recommended fix | Minor discrepancy — `#FFFFFF` vs `#F5F6F7` (2-step difference). Either the masthead intentionally uses pure white for icons (not the semantic token), or the token should resolve to `#FFFFFF` in dark mode. Needs designer confirmation. |

---

### 7. Masthead — height

| Field | Value |
|---|---|
| Component | `masthead.height` |
| Quick-ref previously said | 64px |
| Figma renders | 60px (14px top padding + 32px controls row + 14px bottom padding) |
| Figma node | `209-1685` (light mode masthead) |
| Recommended fix | Update `masthead.height` to 60px. Not a token file issue — this was a quick-ref data entry error. Corrected in `component-quick-ref.yaml`. |

---

## Summary table

| # | Component | Mode | Property | Token file | Figma | Action |
|---|---|---|---|---|---|---|
| 1 | Button / Secondary | Light | Default border | `brand-base` (#0672CB) | `#0063B8` (brand-emphasis) | Fix token file |
| 2 | Button / Secondary | Dark | Default border | `brand-base` (#0672CB) | `#F5F6F7` (brand-inverse-base) | Fix token file |
| 3 | Button / Secondary | Dark | Hover + pressed border | emphasis/strong | `#F5F6F7` (brand-inverse-base) | Fix token file |
| 4 | Textbox | Dark | Watermark foreground | `neutral-contrast` (#C5D4E3) | `#F5F6F7` (foreground-default) | Design decision needed |
| 5 | Hyperlink | Dark | Disabled foreground | `disabled-brand` (brand blue) | `#636363` at 40% (neutral gray) | Design decision needed |
| 6 | Hyperlink | Dark | Focused text color | No foreground token for focus | `#94DCF7` (lighter blue on focus) | Add focused foreground token |

---

## Components validated (Figma-confirmed clean)

These components were pulled from Figma and matched the token file with no discrepancies.

| Component | Light node | Dark node | Status |
|---|---|---|---|
| Button / Primary | (previous session) | `12044-2736` | ✓ Clean — brand tokens are mode-invariant |
| Button / Secondary | `12044-1915` | `12044-2736` | ⚠ See discrepancies 1–3 above |
| Textbox | `385-1058` | `12049-3901` | ⚠ See discrepancy 4 above |
| Hyperlink | `382-1556` | `12046-10399` | ⚠ See discrepancies 5–6 above |
| Masthead | `209-1685` | `11522-2525` | ⚠ See discrepancies 7–9 above (height corrected, 2 dark-mode flags) |

---

## Components not yet validated

- `checkbox`
- `toggle`
- `radio`
- `card_main` + `card_explore`
- `window_chrome`
- `alert` (all 4 variants)
- `toast`
- `dropdown`
- `content_layer`
- `progress_button`
- `busy_indicator`

---

## Notes

- Validation methodology: Figma nodes pulled via Figma MCP (`get_design_context`), hex values extracted from the rendered component and the color code reference table within each node, then diffed against `systems/unity/boo/02-tokens.yaml` and `component-quick-ref.yaml`.
- All confirmed values are recorded in `component-quick-ref.yaml` with inline discrepancy notes.
- This report will be updated as remaining components are validated.
