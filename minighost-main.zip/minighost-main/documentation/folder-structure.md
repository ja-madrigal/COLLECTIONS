```sh
minighost/                                 # Installed to ~/minighost via install.sh
├── README.md                              # Project overview and agent contract
├── CLAUDE.md                              # Agent runtime instructions
├── ghost.js                               # CLI entry point (ghost --enable, --disable, etc.)
├── setup.js                               # One-time setup script for local environment
├── install.sh                             # Installer script (curl | bash)
├── package.json                           # Package metadata and version
├── .windsurfrules                         # MiniGhost rules injected into AI agent configs
│
├── BOO/                                   # Knowledge layer — one subfolder per design system
│   ├── design-rule.md                     # Cross-system design rules
│   ├── principles-quick-check.yaml        # Quick validation checklist
│   ├── principles-quick-ref.yaml          # Quick reference for design principles
│   ├── 12 columns grid layout/            # Grid layout templates and UI guide
│   │   ├── UI-TEMPLATE-GUIDE.md
│   │   ├── layout-template.html
│   │   ├── layout-template-subpage.html
│   │   └── layout-template-thirdlayer.html
│   ├── skills/                            # Reusable validation procedures
│   │   └── technical-validation/
│   │       └── skill.md                  # Technical validation skill (Dimensions 2-4)
│   └── unity/                             # Dell Unity design system
│       ├── boo/                           # Book of Origins — read before generating
│       │   ├── 01-constitution.yaml       # Rules: generation sequence, frameworks, grid, token usage
│       │   ├── 02-tokens.yaml             # Values: all design tokens (primitives + semantic)
│       │   ├── 03-icon-map.yaml           # Icon vocabulary: name → SVG path (auto-generated)
│       │   ├── 04-accessibility.md        # Hard limits: WCAG 2.2 AA + Microsoft Learn
│       │   ├── 05-component-quick-ref.yaml# Rendering spec: dimensions, colors, states per component
│       │   └── design-philosophy.md       # Unity design principles and rationale
│       ├── component-selection/           # 4-layer component selection mechanism
│       │   ├── 01-task-ontology.md        # Task tree — enter here when no pattern matches
│       │   ├── 02-selection-decisions.md  # Decision tables for resolving multiple candidates
│       │   ├── 03-components-manifest.yaml# Anti-patterns and a11y requirements per component
│       │   └── 04-patterns-manifest.yaml  # Named screen/section recipes — check first
│       ├── dist/                          # Generated outputs (do not hand-edit)
│       │   ├── tokens.css                 # CSS custom properties for browser prototyping
│       │   ├── tokens.tailwind.config.js  # Tailwind theme extension
│       │   └── tokens.styles.xml          # WinUI/Fluent ResourceDictionary
│       ├── docs/                          # Unity supplemental documentation
│       └── layout-contract/               # Layout contracts for specific screens
│   ├── icons/                             # Shared SVG assets (431 DDS2 icons)
│   │   └── dds2/
│   │       └── ...
│
├── scripts/
│   ├── build-tokens.py                    # Compiles 02-tokens.yaml → dist/ outputs
│   ├── build-icon-map.py                  # Regenerates 03-icon-map.yaml from icons/dds2/
│   ├── install.js                         # Legacy npm install script (not used)
│   ├── uninstall.js                       # Legacy npm uninstall script (not used)
│   ├── sync-enterprise.sh                 # Syncs changes to enterprise remote
│   └── installer/                         # Shared installer utilities
│       ├── common.js                      # Shared functions (injectRules, removeRules, etc.)
│       ├── install.js                     # Postinstall rule injection
│       └── uninstall.js                   # Pre-uninstall rule removal
│
├── documentation/
│   ├── folder-structure.md                # This file
│   ├── glossary.md                        # Term definitions
│   ├── How-to-use-GHOST.md                # Usage guide
│   ├── model-profile.md                   # Observed AI model behavior notes
│   ├── pass-criteria.md                   # Validation pass/fail criteria
│   └── patterns-journal.md                # Design pattern observations
│
├── validation/                            # ⚠️ Alpha-phase only — temporary structure
│   ├── prompts/                           # Canonical prompts for reference screens
│   ├── screens/                           # Generated HTML screens (alpha output)
│   ├── components/                        # Component-level HTML test files
│   ├── screen-validation-results/         # Scored validation result files
│   └── results.md                         # Rubric scores per screen
│
```
