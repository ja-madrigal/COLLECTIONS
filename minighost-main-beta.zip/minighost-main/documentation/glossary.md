# Glossary

A shared vocabulary for navigating Project Ghost

_Last updated: June 30, 2026_

<br>

## Project Terms

<table>
  <tbody>
    <tr><td><strong>MINIGHOST</strong></td><td>GHOST Alpha. A constraint system that guides AI generation using rules and inputs derived from the Book of Origins (BOO).</td></tr>
    <tr><td><strong>Model profile</strong></td><td>A living document tracking observed and hypothesized AI behavior patterns during generation. Used to inform BOO rule-writing and identify systematic agent failures.</td></tr>
    <tr><td><strong>Patterns journal</strong></td><td>An append-only log of individual AI output failures — each entry has an ID (<code>MG-NNN</code>), root cause, and proposed BOO fix. Companion to the model profile: model profile captures the broad pattern, the journal captures the specific instance.</td></tr>
    <tr><td><strong>BOO</strong> <em>(Book of Origins)</em></td><td>A canonical knowledge layer containing the source files that define all design rules, patterns, and system behavior.</td></tr>
    <tr><td><strong>Book of Origins</strong></td><td>Full name for BOO. The canonical home of design knowledge.</td></tr>
    <tr><td><strong>Unity</strong></td><td>The Dell UI design library for Windows-native applications. Also referred to as <strong>Unity Component Library</strong> or <strong>Unity Design System</strong>.</td></tr>
    <tr><td><strong>Devin (Windsurf)</strong></td><td>An AI-powered IDE by Cognition Labs</td></tr>
    <tr><td><strong>Claude.md / .windsurf rules</strong></td><td>Agent instruction files that define how AI systems interpret and interact with the Book of Origins (BOO).</td></tr>
    <tr><td><strong>ghost --command</strong></td><td>The CLI command used for controlling minighost (<code>ghost --project</code> / <code>ghost --project-off</code> / <code>ghost --update</code>) / <code>ghost --status</code>.</td></tr>
  </tbody>
</table>

<br>

## Ghost Design Terms

<table>
  <tbody>
    <tr><td><strong>Generation sequence</strong></td><td>The mandatory 9-step process the agent must execute before producing any output: identify purpose → select framework → select navigation → select grid → judge overlays → select components → apply visual values → run acceptance checklist → emit manifest block. Steps cannot be skipped or reordered.</td></tr>
    <tr><td><strong>Acceptance checklist</strong></td><td>The 17-point self-audit the agent runs before returning any output. All checks must pass.</td></tr>
    <tr><td><strong>Manifest block</strong></td><td>The structured header emitted at the top of every agent output. Contains: screen name, purpose, framework, grid, mode, primary action, location, return path, components, overlays, and a11y status.</td></tr>
    <tr><td><strong>Constitution</strong></td><td>The main rules file. Covers: generation sequence, frameworks, grids, color usage, components, typography, shape, elevation, motion, and accessibility.</td></tr>
    <tr><td><strong>Tokens Library</strong></td><td>The values file. All resolved design token values, mode-aware (light + dark).</td></tr>
    <tr><td><strong>Semantic token</strong></td><td>A token named for its role (e.g. <code>background-brand-base</code>), not its raw value. Components reference semantic tokens, never primitives directly.</td></tr>
    <tr><td><strong>Primitive token</strong></td><td>A raw value token (e.g. <code>blue.600 = #0672CB</code>). Semantic tokens reference primitives. Components should not reference primitives directly.</td></tr>
    <tr><td><strong>Page framework</strong></td><td>The full-page structure the agent selects before placing any components. One per screen.</td></tr>
    <tr><td><strong>Layout contract</strong></td><td>The spatial layout system that maps to the selected framework. Defines major regions, alignment lines, rail widths, gutters, and padding.</td></tr>
    <tr><td><strong>Spacing hierarchy</strong></td><td>The gap ladder that encodes semantic distance between elements: <code>closely_coupled → standard → major_transition</code>. Token choice is determined by structural relationship, not visual preference. Skipping rungs or applying a larger gap to a tighter relationship is a violation.</td></tr>
    <tr><td><strong>Type budget</strong></td><td>Maximum 3 reading tiers per screen. The tiers are structural, content, and support. A 4th tier is a structural error. The interactive layer (<code>button_2</code>) sits outside the budget and does not count against it.</td></tr>
    <tr><td><strong>Atmospheric background</strong></td><td>The radial gradient applied to <code>body</code> on every screen. Not a design token — a screen-level atmosphere rule. Defined separately per mode (light/dark) in the design rules file.</td></tr>
  </tbody>
</table>

<br>

## Icon Terms

<table>
  <tbody>
    <tr><td><strong>dds2 prefix</strong></td><td>Prefix for all Dell Design System v2 icons. Used in Unity component icon properties.</td></tr>
    <tr><td><strong>Icon map</strong></td><td>Maps icon names to their corresponding file names and file paths. The agent must resolve all icon references through this map and must not invent or infer new icon names.</td></tr>
  </tbody>
</table>

<br>
