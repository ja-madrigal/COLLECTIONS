﻿# How to use GHOST

---

## Set up GHOST

Requires **git** and **Node.js**. Open Terminal and run:

```powershell
git clone https://githubcsg.cec.delllabs.net/CSG-EDG/minighost $env:USERPROFILE\minighost; cd $env:USERPROFILE\minighost; node setup.js
```

Once setup confirms, navigate to your design project folder and enable GHOST:

```sh
ghost --project
```

GHOST is now active in that project. Open the project in Windsurf — the agent will pick up the rules automatically.

---

## Turn off GHOST

Navigate to your project folder and run:

```sh
ghost --project-off
```

Or tell the agent directly in chat:

> "Turn off GHOST in this project."

---

## Generate with GHOST

Once GHOST is on, just prompt normally. The agent handles the rest.

**Recommended:** Write your prompt as a separate `.md` file before pasting it into chat. It keeps your prompts reusable and easy to tweak.

Example prompt:

```md
Generate a Unity login screen for a Dell peripheral management desktop app (Electron, 1280x782). Light mode.

The user opens the app for the first time on a new machine. They need to sign in with their Dell account before they can manage their devices.

The screen should feel like a focused task, not a homepage. One thing to do: sign in. There is a secondary path for users who need to create an account.

Generate the full HTML screen using Unity design tokens from tokens.css. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.
```

---

## Using a screenshot, code, or other context

Attach context directly in the chat alongside your prompt. Be explicit about what the context is for.

```md
Here is a screenshot of the current screen design. Use it as reference for the layout structure only — do not copy colors or typography from it. Generate a Unity-compliant version.

[attach screenshot]

Generate a Unity peripheral settings screen. Light mode. The user is adjusting DPI for a connected mouse.
```

---

## Iterate

Keep prompting. The agent retains the context of the current screen.

```md
Check this screen for accessibility issues against the Unity a11y rules.
```

```md
The primary button is too close to the input field. Adjust the spacing to follow the spacing hierarchy.
```

---

## Run technical validation

Ask the agent to run the technical validation skill on the generated screen. It self-validates against Dimensions 2-4 of the pass criteria (structural correctness, token compliance, component compliance).

Using the login form as an example:

```md
Run the technical validation skill on the login screen output.
```

The agent will check the screen against the rubric and return a pass/fail result per dimension. Dimension 1 (visual fidelity) is a human gate — you review that yourself.

---

## What ghost --project and ghost --project-off actually do

`ghost --project` creates two files in your project root:

- **`.windsurfrules`** — picked up automatically by Windsurf. Contains the full GHOST ruleset with absolute paths to the BOO files.
- **`CLAUDE.md`** — picked up automatically by Claude Code. Same content.

Both files tell the agent where the BOO lives and how to behave. Without them, the agent has no GHOST context.

`ghost --project-off` removes both files cleanly. No orphaned content is left behind. The agent returns to its default behavior in that project.
