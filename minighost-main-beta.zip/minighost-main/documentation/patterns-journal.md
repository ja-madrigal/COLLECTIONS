# Patterns Journal

Append-only log of AI output failure patterns observed during MINIGHOST validation runs — their root causes and the BOO rules added in response.

**Purpose:**
- Stay honest about what the BOO catches vs. what slips through.
- Make recurring failure modes visible so we don't re-derive solutions.
- Show contributors (and future-me) why a rule exists.

**Rules:**
- Entries are ID-ascending (MG-001 first). Append at the bottom — never reorder.
- Mark `status: resolved` when the BOO fix is in. Mark `status: superseded_by: MG-NNN` if a later entry replaces this one.
- Do not delete entries. The history is the point.

**How to use alongside `model-profile.md`:**
- `model-profile.md` tracks **broad behavioral tendencies** by category — the *what*.
- This file tracks **individual failure entries** with root cause and proposed BOO fix — the *why and how*.
- When you spot a failure: note the pattern in the model profile, then create or update an `MG-NNN` entry here with the specifics.

---

## Entry schema

```yaml
---
id: MG-NNN
type: bug | gap | ambiguity
confidence: hypothesis | observed | verified | established
status: active | resolved | superseded_by: MG-NNN
date: YYYY-MM-DD
contributor: [name or alias]
screen: [screen name or prompt]
fixed_in: [constitution vX.X | tokens vX.X | BOO/system-prompt | n/a]
---
```

**Confidence levels:**
- `hypothesis` — expected failure, not yet seen in validation
- `observed` — seen once in a real session
- `verified` — reproduced across 2+ independent runs
- `established` — root cause confirmed, fix verified in re-run

---

## Pre-validation hypotheses

> ⚠️ **Not observed in real MINIGHOST runs.** These are seeded from general Claude behavior patterns as a starting point. Confidence is `hypothesis` on all entries. Do not treat them as established facts — verify in Phase 2 and update the `confidence` and `status` fields accordingly.

---
id: MG-001
type: bug
confidence: hypothesis
status: active
date: 2026-06-09
contributor: system
screen: any
fixed_in: n/a
---

### MG-001 — Agent invents icon names

**Expected:** Agent generates icon names that don't exist in `icons/unity-icon-map.yaml` (e.g. `dds2_wifi-off`, `dds2_error-circle`).

**Root cause (hypothesis):** The icon map lookup instruction exists in the BOO but is easy to skip when the agent is mid-generation and confident about the icon name. The acceptance checklist step should catch this but may not if the agent self-audits lazily.

**Fix (proposed):** Add explicit STOP instruction in the system prompt failure-mode handlers. Confirm the acceptance checklist item requires looking up every icon name, not just flagging unfamiliar ones.

---
id: MG-002
type: bug
confidence: hypothesis
status: active
date: 2026-06-09
contributor: system
screen: any
fixed_in: n/a
---

### MG-002 — Focus ring omitted

**Expected:** Interactive elements generated without the `#A95ADC` 2px focus ring.

**Root cause (hypothesis):** Focus states are easy to skip in a generation pass focused on layout and color. The acceptance checklist has `focus_visible` as a check but the agent may pass it without actually generating the CSS.

**Fix (proposed):** Add a focus ring utility class to `tokens.css` (`.focus-ring`) and require its use in all interactive element examples in the BOO.

---
id: MG-003
type: bug
confidence: hypothesis
status: active
date: 2026-06-09
contributor: system
screen: settings
fixed_in: n/a
---

### MG-003 — Category rail added to focused settings screens

**Expected:** Agent adds a left category rail to `settings_focused` framework screens where it is explicitly forbidden.

**Root cause (hypothesis):** The word "settings" in the prompt triggers the `settings_global` layout pattern regardless of which framework was selected. The distinction between `settings_global` (has rail) and `settings_focused` (no rail) may not be emphasized enough in the BOO.

**Fix (proposed):** Add an explicit anti-pattern entry: "Do not add a category rail to settings_focused screens." Reinforce in the framework selection rules.

---
id: MG-004
type: bug
confidence: hypothesis
status: active
date: 2026-06-09
contributor: system
screen: any
fixed_in: n/a
---

### MG-004 — Raw hex used instead of semantic token

**Expected:** Agent writes `#0672CB` or `color: white` instead of `var(--background-brand-base)`.

**Root cause (hypothesis):** When uncertain which semantic token maps to the desired color, the agent falls back to the resolved hex value it knows from the constitution. This is technically accurate but bypasses the token system.

**Fix (proposed):** Add a STOP instruction in the system prompt: "If you know the hex but not the token name, STOP and look it up in unity-tokens.yaml." Consider adding a quick-reference color → token mapping to the BOO.

---

## Validation entries

*No entries yet. Phase 2 validation pending.*
