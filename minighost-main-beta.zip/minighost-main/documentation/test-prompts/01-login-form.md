# Canonical Prompt — Screen 01: Login Form

**Validation role:** Warmup screen. Low complexity. Tests that the agent reads the BOO correctly and applies the right framework, grid, and component selection before writing any code.

**Contributor instructions:** Use this prompt verbatim. Do not add context, clarify the brief, or modify the wording. Run it in your branch. Capture the HTML output.

---

## Prompt

Generate a Unity login screen for a Dell peripheral management desktop app (Electron, 1280×782). Light mode.

The user opens the app for the first time on a new machine. They need to sign in with their Dell account before they can manage their devices.

The screen should feel like a focused task, not a homepage. One thing to do: sign in. There is a secondary path for users who need to create an account.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

## Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | User needs to authenticate to access the peripheral manager |
| Primary action | Sign in (submit button) |
| Secondary action | Create account (link) |
| User location | First screen after app open, or after session expiry |
| Return path | None — this is the entry point |

**Expected components** (reviewer checklist — not shown to agent)
- `textbox` — username
- `textbox` — password (type=password)
- `label` — paired with each input
- `button-primary` — sign in
- `hyperlink` — create account

**What should NOT appear**
- Persistent navigation or sidebar
- Dashboard widgets
- Marketing content
- More than one primary button
