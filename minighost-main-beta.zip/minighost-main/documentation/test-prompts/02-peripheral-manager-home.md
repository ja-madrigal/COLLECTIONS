# Canonical Prompt — Screen 02: Peripheral Manager Home

**Validation role:** Full-screen complexity. Tests framework selection (welcome vs. hero+feature), grid application, component composition, and the agent's judgment about what to show on a hub screen.

**Contributor instructions:** Use this prompt verbatim. Do not add context, clarify the brief, or modify the wording. Run it in your branch. Capture the HTML output.

---

## Prompt

Generate the home screen for a Dell peripheral management desktop app (Electron, 1280×782). Dark mode.

The user has already signed in. They land here after login. The app manages keyboards, mice, monitors, and headsets connected to a Dell workstation. The user's name is visible somewhere on the screen.

The screen is a hub — the user picks which device category or feature to go into. They are not here to configure anything yet; they are orienting and choosing where to go next.

There are four capability areas: Devices, Firmware, Display Settings, and Support. The user has 5 connected peripherals: 2 monitors, 1 dock, 1 keyboard, and 1 mouse. 3 are connected and healthy, 1 is disconnected, and 1 has outdated firmware. Surface this status at a glance — color, icon, and label, not color alone.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

## Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | User is orienting — choosing which area of the app to enter |
| Primary action | Navigate into a capability area (card or tile tap) |
| Secondary action | None at this level |
| User location | Home screen, post-login |
| Return path | None — this is the root screen |

**Expected components** (reviewer checklist — not shown to agent)
- `masthead` — 64px, app title + window controls
- `card-explore` or `card-main` — one per capability area (Devices, Firmware, Display Settings, Support)
- User identity label — name visible somewhere
- Device summary — 5 devices: 2 monitors, 1 dock, 1 keyboard, 1 mouse
- Status indicators — 3 connected/healthy, 1 disconnected, 1 firmware outdated; each state must use color + icon + label (not color alone)

**What should NOT appear**
- Settings rail or configuration controls
- Onboarding progression (steps, progress bar)
- A full device list (too much detail for a hub)
- More than one primary button
