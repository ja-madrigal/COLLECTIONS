# Canonical Prompt — Screen 04: Dell Application Control Center

**Validation role:** Device management hub with toggle controls. Tests the agent's ability to present device information, configuration cards, and toggle switches while maintaining clear visual hierarchy and action affordances.

**Contributor instructions:** Use this prompt verbatim. Do not add context, clarify the brief, or modify the wording. Run it in your branch. Capture the HTML output.

---

## Prompt

Generate a Dell Application Control Center screen for a desktop app (Electron). Light mode.

**Layout Contract:**
See `BOO/unity/layout-contract/layout-contract-dacc01.yaml` for the authoritative frame, zone, and sizing specification.

The user is managing a Dell Pro 24 All-in-One 35W Desktop. They need to view device information and access configuration options.

**Zone content mapping:**
- **header_zone (app_bar):** App title "Dell Application Control Center" in caption/default type style (12px/400 weight) on the left, window controls on the right (dds2_minus-minimize, dds2_stop for maximize/restore, dds2_close-x)
- **gap (secondary_nav_or_breadcrumb):** Empty (respect the 62px height)
- **sidebar_zone (sidebar_nav_or_details):** Device information section flowing from device model to device details to Write Filter element. Device info displays: "Dell Pro 24 All-in-One 35W Desktop", OS (Windows 11 IoT Enterprise LTSC 2024), Device Name (Desktop-1660 G2E), Service Tag (HJA7589), IP (192.168.0.1). Write Filter element: recreate the UI element using Unity styles — toggle switch set to ON with label "ON" (16px/400 weight), and hyperlink "Make changes in Write Filter Settings" below it
- **dynamic_zone (primary_content):** Four navigation cards in a 2x2 grid with icons and titles — Easy Setup (dds2_toolbox), WMS Settings (dds2_gear-wrench), Device Overview (dds2_device-desktop), Write Filter Settings (dds2_filter). Each card displays an icon followed by the title text
- **footer_zone (status_bar):** Two tertiary-style buttons with icons and text labels — Notifications (dds2_alarm-bell) and Utilities (dds2_toolbox)

The screen is a hub for device management. The user can navigate to different configuration areas or toggle the Write Filter. The primary actions are tapping the navigation cards or the Write Filter toggle/link.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

## Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | User needs to view device information and access configuration options |
| Primary action | Navigate to a configuration area (card tap) or toggle Write Filter |
| Secondary action | Access Notifications or Utilities |
| User location | Device management hub screen |
| Return path | None — this is a root management screen |

**Expected components** (reviewer checklist — not shown to agent)
- Frame: 1132px width, corner_radius: 9px
- header_zone: 64px (app_bar) with app title and window controls
- gap: 62px (secondary_nav_or_breadcrumb) empty
- body_zone: horizontal layout with sidebar_zone (284px) + dynamic_zone (fill, min_width 400px)
- margin_left / margin_right: 44px each
- gap_sidebar_dynamic: 80px
- footer_zone: 94px (status_bar)
- Device information section in sidebar_zone — displays device model, OS, Device Name, Service Tag, IP
- Write Filter card in sidebar_zone — toggle switch set to ON with label "ON", hyperlink "Make changes in Write Filter Settings"
- Navigation cards — 2x2 grid in dynamic_zone with Easy Setup (dds2_toolbox), WMS Settings (dds2_gear-wrench), Device Overview (dds2_device-desktop), Write Filter Settings (dds2_filter)
- Footer buttons — Notifications (dds2_alarm-bell) and Utilities (dds2_toolbox) as tertiary-style buttons with text labels
- Status indicators — toggle state must use color + icon + label, not color alone

**Expected data on screen**
- Device: Dell Pro 24 All-in-One 35W Desktop
- OS: Windows 11 IoT Enterprise LTSC 2024
- Device Name: Desktop-1660 G2E
- Service Tag: HJA7589
- IP: 192.168.0.1
- Write Filter: ON
- Four navigation cards: Easy Setup, WMS Settings, Device Overview, Write Filter Settings

**What should NOT appear**
- Settings rail or sidebar navigation
- Onboarding or progress flows
- Marketing content or upsell
- More than one primary action per card
- Battery-related information or controls
