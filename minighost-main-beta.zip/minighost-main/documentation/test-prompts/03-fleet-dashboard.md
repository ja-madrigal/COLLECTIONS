# Canonical Prompt — Screen 03: Fleet Management Dashboard

**Validation role:** Compositional judgment at scale. Tests the status dashboard framework, three-column card grid, multi-status scanning layout, and the agent's ability to organize dense information without breaking the visual hierarchy.

**Contributor instructions:** Use this prompt verbatim. Do not add context, clarify the brief, or modify the wording. Run it in your branch. Capture the HTML output.

---

## Prompt

Generate a fleet management dashboard for a Dell IT admin desktop app (Electron, 1280×782). Dark mode.

The IT admin manages a fleet of 240 workstations across three office locations: Austin, Nashville, and Portland. They open this screen to get a fast read on fleet health — they should be able to spot problems without clicking into anything.

The dashboard needs to show: overall fleet health, firmware update status across the fleet, active alerts, and a count of devices by location. There are currently 240 workstations across 3 locations: Austin (94), Nashville (81), Portland (65). Of those: 218 are healthy, 12 have pending firmware updates, 7 are offline, and 3 have critical alerts (one per location).

The screen is for scanning, not for acting. Actions (like pushing an update) happen on a detail screen the admin navigates to from here. The primary action on this screen is navigating into an alert or device group — a card tap or row tap, not a page-level button.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

## Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | IT admin needs a fast status read on the whole fleet |
| Primary action | Navigate into an alert or device group |
| Secondary action | None — actions happen on detail screens |
| User location | Fleet overview, top-level admin screen |
| Return path | None — this is the root admin screen |

**Expected components** (reviewer checklist — not shown to agent)
- `masthead` — 64px, app title + window controls
- Status cards — fleet health, firmware status, alerts, devices by location
- `card-main` or equivalent — for alert rows or device group rows
- Alert indicators — 3 critical alerts surfaced visually, one per location; each must use color + icon + label, not color alone
- Offline device count — 7 offline surfaced clearly
- Firmware count — 12 pending updates surfaced clearly

**Expected data on screen**
- 240 total workstations
- 3 locations: Austin (94), Nashville (81), Portland (65)
- 218 healthy, 12 pending firmware, 7 offline, 3 critical alerts
- Status variety must be visually distinguishable without relying on color alone

**What should NOT appear**
- Action buttons for pushing updates (those are on the detail screen)
- Settings controls or settings rail
- Onboarding or progress flows
- A flat list of all 240 devices
- Per-device marketing or upsell content
