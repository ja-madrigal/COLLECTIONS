```sh
minighost/                                 # Installed to ~/minighost via install.sh
├── README.md                              # Project overview and agent contract
├── CLAUDE.md                              # Agent runtime instructions
├── ghost.js                               # CLI entry point (ghost --enable, --disable, etc.)
├── setup.js                               # One-time setup script for local environment
├── install.sh                             # Installer script (curl | bash)
├── package.json                           # Package metadata and version
├── .windsurfrules                         # MiniGhost rules injected into AI agent configs
│
├── BOO/                                   # Knowledge layer — three-layer architecture
│   ├── ghost-onboarding.md                # Agent onboarding process for new products
│   ├── boo-restructure.md                 # Architecture notes and rationale
│   │
│   ├── global/                            # LAYER 1 — Universal constraints (all systems)
│   │   ├── design-rules.md                # Cross-system design rules
│   │   ├── design-philosophy.md           # Design principles and rationale
│   │   ├── accessibility-guides.md        # Hard limits: WCAG 2.2 AA + Microsoft Learn
│   │   ├── responsive-guides.md           # Responsive design patterns (not yet created)
│   │   ├── principles-quick-check.yaml    # Quick validation checklist
│   │   ├── principles-quick-ref.yaml      # Quick reference for design principles
│   │   ├── grids/                         # Grid layout templates and UI guide
│   │   │   ├── UI-TEMPLATE-GUIDE.md
│   │   │   ├── layout-template.html
│   │   │   ├── layout-template-subpage.html
│   │   │   └── layout-template-thirdlayer.html
│   │   ├── assets/
│   │   │   └── icons-dds2/                # Shared icon library (431 DDS2 icons)
│   │   │       ├── 03-icon-map.yaml       # Icon vocabulary: name → SVG path
│   │   │       └── *.svg                  # Individual icon files
│   │   ├── component-selection/           # Universal component selection methodology
│   │   │   ├── 01-task-ontology.md        # Task tree — enter here when no pattern matches
│   │   │   └── 02-selection-decisions.md  # Decision tables for resolving candidates
│   │   └── skills/
│   │       └── technical-validation/
│   │           └── skill.md               # Technical validation skill (Dimensions 2-4)
│   │
│   ├── design-systems/                    # LAYER 2 — Design systems
│   │   └── unity/                         # Dell Unity Component Library
│   │       ├── canonical/                 # Authoritative agent-facing files
│   │       │   ├── 00-orchestrator.yaml   # Files index and load sequence (not yet created)
│   │       │   └── 01-constitution.yaml   # Generation sequence and design rules
│   │       ├── components/                # Unity component reference
│   │       │   ├── components-manifest.yaml   # Semantic usage rules per component
│   │       │   ├── patterns-manifest.yaml     # Named screen/section recipes
│   │       │   ├── 05-component-quick-ref.yaml# DEPRECATED — historical reference only; use components.md
│   │       │   ├── tokens.css                 # Component CSS variables (light + dark mode)
│   │       │   └── tokens.yaml                # Semantic color + typography tokens
│   │       ├── layout-contract/           # Layout contracts for specific screens
│   │       │   └── layout-contract-dacc01.yaml
│   │       └── recipes/                   # LAYER 3 — Product recipes (Unity overrides)
│   │           └── ddpm-recipe/           # DDPM product customizations
│   │               ├── 00-orchestrator.yaml
│   │               ├── token-overrides.yaml
│   │               ├── component-overrides.yaml
│   │               ├── rules.md
│   │               └── components/
│   │                   ├── components-manifest.yaml
│   │                   ├── patterns-manifest.yaml
│   │                   ├── html/
│   │                   ├── tsx/
│   │                   └── tokens.css
│   │
│   └── core-products/                     # Product knowledge — layout, contracts, data
│       ├── UUE/                           # Unity User Experience product
│       │   ├── product-context.md
│       │   ├── component-manifest.md
│       │   ├── information-architecture.md
│       │   ├── screen-references.md
│       │   ├── onboarding-status.md
│       │   ├── layouts/
│       │   └── system-overrides/
│       └── ddpm/                          # DDPM product artifacts
│           ├── layout-contract/
│           ├── screen-patterns/
│           └── data/
│
├── scripts/
│   ├── build-tokens.py                    # Compiles tokens.yaml → tokens.css outputs
│   ├── build-icon-map.py                  # Regenerates 03-icon-map.yaml from icons-dds2/
│   ├── install.js                         # Legacy npm install script (not used)
│   ├── uninstall.js                       # Legacy npm uninstall script (not used)
│   ├── sync-enterprise.sh                 # Syncs changes to enterprise remote
│   └── installer/                         # Shared installer utilities
│       ├── common.js                      # Shared functions (injectRules, removeRules, etc.)
│       ├── install.js                     # Postinstall rule injection
│       └── uninstall.js                   # Pre-uninstall rule removal
│
├── documentation/
│   ├── folder-structure.md                # This file
│   ├── glossary.md                        # Term definitions
│   ├── How-to-use-GHOST.md                # Usage guide
│   ├── model-profile.md                   # Observed AI model behavior notes
│   ├── pass-criteria.md                   # Validation pass/fail criteria
│   ├── patterns-journal.md                # Design pattern observations
│   └── test-prompts/                      # Canonical prompts for reference screens
│       ├── README.md
│       ├── 01-login-form.md
│       ├── 02-peripheral-manager-home.md
│       ├── 03-fleet-dashboard.md
│       └── 04-dacc-home.md
│
└── validation/                            # ⚠️ Alpha-phase only — temporary structure
    ├── results.md                         # Rubric scores per screen
    └── screen-validation-results/         # Scored validation result files
        └── validation-results-template.html
```
