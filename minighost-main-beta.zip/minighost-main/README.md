```
░█▄█░▀█▀░█▀█░▀█▀░█▀▀░█░█░█▀█░█▀▀░▀█▀
░█░█░░█░░█░█░░█░░█░█░█▀█░█░█░▀▀█░░█░
░▀░▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░░▀░
```

# MINIGHOST — Version Beta

**MINIGHOST** is a constraint system for AI Agents. It guides the agent to produce **full UI screens** in the Dell Unity design language. It uses the **Book of Origins (BOO)** — a structured design spec — to guide the composition of existing Unity components into complete screens.

Version Beta outputs are browser-based HTML comps and prototypes that mimic native and electron UIs — no build toolchain required on the consumer side.

The goal is consistency first, creative generation second.

---

## Available on Minighost

| System | Folder | Status | Figma Link |
|---|---|---|---|
| `unity` | `BOO/design-systems/unity/` | Active — Dell Unity design system | [Figma](https://www.figma.com/design/8TipUKvce0k9JPezXvpGrP/Unity-Component-Library) |

---

## Installation

Requires **git** and **Node.js** installed. Requires git access to `githubcsg.cec.delllabs.net`.

Open Terminal and run:

```powershell
git clone https://githubcsg.cec.delllabs.net/CSG-EDG/minighost $env:USERPROFILE\minighost; cd $env:USERPROFILE\minighost; node setup.js
```

That's it! MINIGHOST is ready. Open your project in Windsurf and run `ghost --project` in the terminal — or just ask the AI agent to do it.

**Enable for a project** — navigate to your design project folder and run:
```sh
ghost --project
```

---

## CLI Commands

| Command | Description |
|---|---|
| `ghost --project` | Enable MiniGhost in the current project folder |
| `ghost --project-off` | Remove MiniGhost from the current project folder |
| `ghost --onboard` | Start the onboarding flow for a new product |
| `ghost --onboard-off` | Remove onboarding context |
| `ghost --update` | Update to latest version |
| `ghost --uninstall` | Remove MiniGhost and uninstall |
| `ghost --status` | Show current status and version |
| `ghost --help` | Show usage |

---

## How to Enable MINIGHOST in a Project

Navigate to your design project folder and run:

```powershell
ghost --project
```

This creates two files in the project root:
- **`.windsurfrules`** — picked up automatically by Windsurf
- **`CLAUDE.md`** — picked up automatically by Claude Code

Both files contain the full MiniGhost ruleset with absolute paths to the BOO files, so the AI agent can read them from this project. MiniGhost is only active in projects where you run this command.

To remove MINIGHOST from a project:

```powershell
ghost --project-off
```

This cleanly removes both files. No orphaned content is left behind.

---

## Ready to generate?

See [documentation/How-to-use-GHOST.md](documentation/How-to-use-GHOST.md) for a full walkthrough — prompting, iterating, running validation, and more.

---

## The Book of Origins (BOO)

BOO is the knowledge layer. Contains principles, patterns, and design standards. Each design system has its own BOO under `BOO/design-systems/{system}/canonical/` and `BOO/design-systems/{system}/components/`. Product-specific knowledge lives under `BOO/core-products/{product}/`. The agent consults knowledge files before generating anything.

| File | Role |
|---|---|
| `01-constitution.yaml` | **The rules.** Generation sequence, page frameworks, grid models, color usage, components, typography, shape, elevation, motion, and accessibility hard rules. |
| `tokens.css` | **The values.** Single canonical source for all design tokens — component, semantic colors (light + dark), typography, spacing, radius, elevation, motion, z-index, and layout constants. |
| `03-icon-map.yaml` | **The visual vocabulary.** Maps every icon name to its SVG path. The agent looks up icons here — it never invents names. |
| `accessibility-guides.md` | **The hard limits.** WCAG 2.2 AA + Microsoft Learn requirements. Every MUST and MUST NOT is a release blocker. |
| `components.md` | **The rendering spec.** Props, states, key tokens, and shadow/blur values per component. Agent reads the relevant entry before rendering any component. |

---

## Skills

Skills are reusable validation and quality check procedures that the AI agent can run. Skills are located in `BOO/{system}/skills/{skill-name}/skill.md` with frontmatter metadata:

- `name`: skill identifier
- `description`: what the skill does
- `trigger`: when the skill runs (e.g., "after_generation")
- `execution`: how the skill runs (e.g., "automatic or user_prompt")
- `scope`: what the skill applies to

**Current Skills:**
- `technical-validation` — Self-validates Unity design system output against technical criteria (Dimensions 2-4 of the validation rubric) before human visual review.

Skills run automatically after screen generation (if `trigger: "after_generation"`) or can be invoked by user prompt.

---

## Project Structure

For detailed folder structure and file descriptions, see [documentation/folder-structure.md](documentation/folder-structure.md).

---

## Starting a Session

When you open a project with MiniGhost enabled, the agent will ask:

> "What are you working on today?"
> 1. An existing product
> 2. A new product
> 3. Just exploring or testing

**Tip:** Start every session with a simple message like `"let's get started"` or `"hey"` rather than jumping straight into a design prompt. This lets the agent ask the question first — if you open with a full design prompt, the agent will pause and ask anyway, so starting simple saves a step.

- **Option 1** — The agent reads `BOO/core-products/` and presents your existing products as a numbered list. Pick by number. If your product isn't listed, pick "None of these" and onboarding will run.
- **Option 2** — Kicks off the onboarding flow to set up a new product folder.
- **Option 3** — No product context loaded. Use this for exploration, testing, or one-off work.

---

## The Agent Contract

With MiniGhost enabled, the agent automatically:

1. Reads BOO knowledge files before generating anything.
2. Follows the 9-step generation sequence — no skipping, no reordering.
3. Uses only tokens defined in `tokens.css`. No invented values.
4. Uses only icons and names from `03-icon-map.yaml`. No invented names.
5. Consults `components.md` before rendering any component.
6. Emits a manifest block at the top of every output (screen name, framework, grid, mode, primary action, a11y status).
7. Runs the acceptance checklist before returning any artifact.
8. For new products, runs `ghost --onboard` to load product context from `BOO/core-products/{product}/`.
