#!/usr/bin/env node

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { execSync } = require('child_process');

// Install dir = wherever the user cloned the repo (where this script lives).
const INSTALL_DIR = path.dirname(fs.realpathSync(__filename));
const IS_WINDOWS  = process.platform === 'win32';

function checkDep(cmd) {
  try {
    execSync(`${IS_WINDOWS ? 'where' : 'which'} ${cmd}`, { stdio: 'ignore' });
  } catch {
    console.error(`Error: "${cmd}" not found.`);
    if (cmd === 'git')  console.error('  Install Git: https://git-scm.com/download/win');
    if (cmd === 'node') console.error('  Install Node.js: https://nodejs.org');
    process.exit(1);
  }
}

const ART = `
░█▄█░▀█▀░█▀█░▀█▀░█▀▀░█░█░█▀█░█▀▀░▀█▀
░█░█░░█░░█░█░░█░░█░█░█▀█░█░█░▀▀█░░█░
░▀░▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░░▀░`;

console.log(ART);
console.log('\n=== MiniGhost Installer ===\n');

checkDep('git');
checkDep('node');

console.log(`Install dir: ${INSTALL_DIR}\n`);

// --- create launcher ---
if (IS_WINDOWS) {
  const cmd = path.join(INSTALL_DIR, 'ghost.cmd');
  if (!fs.existsSync(cmd)) {
    fs.writeFileSync(cmd, '@node "%~dp0ghost.js" %*\r\n', 'ascii');
    console.log('✓ Created ghost.cmd');
  } else {
    console.log('✓ ghost.cmd already present');
  }
} else {
  const link = path.join(INSTALL_DIR, 'ghost');
  if (!fs.existsSync(link)) {
    fs.symlinkSync(path.join(INSTALL_DIR, 'ghost.js'), link);
    fs.chmodSync(path.join(INSTALL_DIR, 'ghost.js'), 0o755);
    console.log('✓ Created ghost symlink');
  } else {
    console.log('✓ ghost symlink already present');
  }
}

// --- add to PATH ---
if (IS_WINDOWS) {
  const userPath = execSync(
    'reg query "HKCU\\Environment" /v PATH',
    { encoding: 'utf8' }
  ).match(/PATH\s+REG_(?:EXPAND_)?SZ\s+(.+)/i)?.[1]?.trim() ?? '';

  if (!userPath.toLowerCase().includes(INSTALL_DIR.toLowerCase())) {
    const newPath = `${INSTALL_DIR};${userPath}`;
    execSync(`setx PATH "${newPath}"`, { stdio: 'ignore' });
    console.log(`✓ Added ${INSTALL_DIR} to PATH`);
    console.log('  (Open a new terminal for PATH to take effect)');
  } else {
    console.log(`✓ ${INSTALL_DIR} already in PATH`);
  }
} else {
  const shellRc = process.env.SHELL?.includes('zsh')
    ? path.join(os.homedir(), '.zshrc')
    : path.join(os.homedir(), '.bash_profile');

  const existing = fs.existsSync(shellRc) ? fs.readFileSync(shellRc, 'utf8') : '';
  if (!existing.includes(INSTALL_DIR)) {
    fs.appendFileSync(shellRc, `\n# MiniGhost\nexport PATH="${INSTALL_DIR}:$PATH"\n`);
    console.log(`✓ Added to PATH (${shellRc})`);
    console.log('  (Run: source ' + shellRc + ' or open a new terminal)');
  } else {
    console.log(`✓ ${INSTALL_DIR} already in PATH`);
  }
}

console.log(`\n✓ MiniGhost installed to ${INSTALL_DIR}`);
console.log('\nNext step: open your design project folder and run:');
console.log('  ghost --project');
