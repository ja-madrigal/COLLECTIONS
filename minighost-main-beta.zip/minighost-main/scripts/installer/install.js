#!/usr/bin/env node

const path = require('path');
const common = require('./common');

const AGENTS = [
  { name: 'Windsurf', path: common.getWindsurfPath() },
  { name: 'Claude Code', path: common.getClaudePath() },
];

function main() {
  console.log('=== MiniGhost Installation ===');
  console.log(`Platform: ${process.platform}`);
  console.log(`MiniGhost path: ${common.MINIGHOST_PATH}\n`);

  let anyInstalled = false;

  for (const agent of AGENTS) {
    try {
      const injected = common.injectRules(agent.path);
      if (injected) {
        console.log(`✓ ${agent.name}: rules injected`);
        anyInstalled = true;
      } else {
        console.log(`✓ ${agent.name}: already active`);
      }
    } catch (error) {
      console.log(`✗ ${agent.name}: ${error.message}`);
    }
  }

  console.log('');
  if (anyInstalled) {
    console.log('MiniGhost is now active!');
  }
  console.log('Open a new terminal, then: ghost --status');
}

main();
