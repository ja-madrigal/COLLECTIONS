#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const os = require('os');

const MINIGHOST_PATH = path.resolve(__dirname, '../..');
const START_MARKER = '# MINIGHOST START';
const END_MARKER = '# MINIGHOST END';

const ORPHAN_PATTERNS = [
  '# MINIGHOST CONFIGURATION',
  '# Minighost is active.',
  '# Design system: unity (default)',
  '# Mode: strict (enforces all design system rules)',
];

function getWindsurfPath() {
  return path.join(os.homedir(), '.codeium', 'windsurf', 'memories', 'global_rules.md');
}

function getClaudePath() {
  return path.join(os.homedir(), '.claude', 'CLAUDE.md');
}

function buildBlock() {
  const rulesPath = path.join(MINIGHOST_PATH, '.windsurfrules');
  let content = fs.readFileSync(rulesPath, 'utf8');

  const absBase = MINIGHOST_PATH.replace(/\\/g, '/');
  content = content.replace(/`BOO\//g, `\`${absBase}/BOO/`);

  const pkg = JSON.parse(fs.readFileSync(path.join(MINIGHOST_PATH, 'package.json'), 'utf8'));
  return `${START_MARKER} (v${pkg.version})\n${content}\n${END_MARKER}`;
}

function cleanOrphanedStubs(filePath) {
  if (!fs.existsSync(filePath)) return;
  const lines = fs.readFileSync(filePath, 'utf8').split('\n');
  const filtered = lines.filter(line => !ORPHAN_PATTERNS.some(p => line.includes(p)));
  const cleaned = filtered.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  fs.writeFileSync(filePath, cleaned ? cleaned + '\n' : '');
}

function injectRules(filePath) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  cleanOrphanedStubs(filePath);

  const existing = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : '';
  if (existing.includes(START_MARKER)) {
    return false;
  }

  const block = buildBlock();
  const trimmed = existing.trim();
  const newContent = trimmed ? `${block}\n\n${trimmed}\n` : `${block}\n`;
  fs.writeFileSync(filePath, newContent);
  return true;
}

function removeRules(filePath) {
  if (!fs.existsSync(filePath)) return false;

  const content = fs.readFileSync(filePath, 'utf8');
  const startIdx = content.indexOf(START_MARKER);
  const endIdx = content.indexOf(END_MARKER);

  if (startIdx === -1 || endIdx === -1) {
    cleanOrphanedStubs(filePath);
    return false;
  }

  const before = content.substring(0, startIdx).trimEnd();
  const after = content.substring(endIdx + END_MARKER.length).trimStart();
  const newContent = [before, after].filter(Boolean).join('\n\n');
  fs.writeFileSync(filePath, newContent ? newContent + '\n' : '');
  return true;
}

function buildRawContent() {
  const rulesPath = path.join(MINIGHOST_PATH, '.windsurfrules');
  let content = fs.readFileSync(rulesPath, 'utf8');
  const absBase = MINIGHOST_PATH.replace(/\\/g, '/');
  content = content.replace(/`BOO\//g, `\`${absBase}/BOO/`);
  return content;
}

function injectProjectRules(windsurfPath, claudePath) {
  const results = { windsurf: 'skipped', claude: 'skipped' };

  const existingWs = fs.existsSync(windsurfPath) ? fs.readFileSync(windsurfPath, 'utf8') : '';
  if (existingWs.includes(START_MARKER)) {
    results.windsurf = 'exists';
  } else {
    const block = buildBlock();
    const trimmed = existingWs.trim();
    fs.writeFileSync(windsurfPath, trimmed ? `${block}\n\n${trimmed}\n` : `${block}\n`);
    results.windsurf = trimmed ? 'injected' : 'created';
  }

  if (!fs.existsSync(claudePath)) {
    fs.writeFileSync(claudePath, buildBlock() + '\n');
    results.claude = 'created';
  } else {
    const existing = fs.readFileSync(claudePath, 'utf8');
    if (!existing.includes(START_MARKER)) {
      fs.writeFileSync(claudePath, existing.trim() + '\n\n' + buildBlock() + '\n');
      results.claude = 'injected';
    } else {
      results.claude = 'exists';
    }
  }

  return results;
}

function removeProjectRules(windsurfPath, claudePath) {
  const results = { windsurf: false, claude: false };

  if (fs.existsSync(windsurfPath)) {
    results.windsurf = removeRules(windsurfPath);
  }

  if (fs.existsSync(claudePath)) {
    results.claude = removeRules(claudePath);
  }

  return results;
}

function isEnabled(filePath) {
  if (!fs.existsSync(filePath)) return false;
  return fs.readFileSync(filePath, 'utf8').includes(START_MARKER);
}

function getInstalledVersion(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const content = fs.readFileSync(filePath, 'utf8');
  const match = content.match(/# MINIGHOST START \(v([^)]+)\)/);
  return match ? match[1] : null;
}

module.exports = {
  MINIGHOST_PATH,
  START_MARKER,
  END_MARKER,
  getWindsurfPath,
  getClaudePath,
  buildBlock,
  buildRawContent,
  cleanOrphanedStubs,
  injectRules,
  removeRules,
  injectProjectRules,
  removeProjectRules,
  isEnabled,
  getInstalledVersion,
};
