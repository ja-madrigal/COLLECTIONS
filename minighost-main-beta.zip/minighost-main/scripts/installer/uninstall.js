#!/usr/bin/env node

const common = require('./common');

const AGENTS = [
  { name: 'Windsurf', path: common.getWindsurfPath() },
  { name: 'Claude Code', path: common.getClaudePath() },
];

function main() {
  console.log('=== MiniGhost Pre-uninstall Cleanup ===\n');

  for (const agent of AGENTS) {
    try {
      const removed = common.removeRules(agent.path);
      common.cleanOrphanedStubs(agent.path);
      console.log(removed ? `✓ ${agent.name}: removed` : `- ${agent.name}: not active`);
    } catch (error) {
      console.log(`✗ ${agent.name}: ${error.message}`);
    }
  }

  console.log('\nMiniGhost rules removed from all agent configs.');
}

main();
