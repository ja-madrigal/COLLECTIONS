#!/usr/bin/env python3
"""Regenerate BOO/unity/boo/03-icon-map.yaml from the BOO/icons/dds2/ directory."""

import os
from datetime import date

ICONS_DIR = os.path.join(os.path.dirname(__file__), "..", "BOO", "icons", "dds2")
OUTPUT = os.path.join(os.path.dirname(__file__), "..", "BOO", "unity", "boo", "03-icon-map.yaml")
FIGMA_FILE = "nBvcv4I2nV3MNaWxoPDEk9"
FIGMA_PAGE = "Icons"

icons = sorted(f[:-4] for f in os.listdir(ICONS_DIR) if f.endswith(".svg"))

lines = [
    "# Unity Icon Library — DDS2",
    f"# Auto-generated {date.today()} from BOO/icons/dds2/",
    "# SVG files are the source of truth for browser builds",
    f"# Figma source: file {FIGMA_FILE}, page: {FIGMA_PAGE} (search by name)",
    "# Do not hand-edit. Regenerate by running: python scripts/build-icon-map.py",
    "",
    f"figma_file: {FIGMA_FILE}",
    f"figma_page: {FIGMA_PAGE}",
    "svg_root: BOO/icons/dds2/",
    "",
    "icons:",
]

for name in icons:
    lines.append(f"  - name: {name}")
    lines.append(f"    svg: BOO/icons/dds2/{name}.svg")

with open(OUTPUT, "w") as f:
    f.write("\n".join(lines) + "\n")

print(f"Written {len(icons)} icons to BOO/unity/boo/03-icon-map.yaml")
