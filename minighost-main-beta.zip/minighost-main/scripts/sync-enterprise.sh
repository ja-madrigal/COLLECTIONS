#!/bin/bash
# sync-enterprise.sh
# Generates a fresh git bundle for transfer to the Dell enterprise repo.

set -e

BUNDLE_NAME="minighost.bundle"
ENTERPRISE_REMOTE="https://githubcsg.cec.delllabs.net/CSG-EDG/minighost.git"

echo "=> Generating bundle..."
git bundle create "$BUNDLE_NAME" --all

echo "=> Committing bundle to GitHub..."
git add "$BUNDLE_NAME"
git commit -m "Update git bundle for enterprise sync"
git push

echo ""
echo "========================================"
echo "  Bundle ready: $BUNDLE_NAME"
echo "========================================"
echo ""
echo "On your Dell machine:"
echo ""
echo "  1. Download $BUNDLE_NAME from GitHub"
echo "  2. Run:"
echo ""
echo "     git pull $BUNDLE_NAME main"
echo "     git push $ENTERPRISE_REMOTE main"
echo ""
echo "  3. Done. Then delete the bundle file."
echo ""
