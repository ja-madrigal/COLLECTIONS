#!/usr/bin/env python3
"""
build-tokens.py
Reads unity-tokens.yaml and generates:
  - tokens.css (CSS custom properties for web)
  - tokens.tailwind.config.js (Tailwind theme extension)
  - tokens.styles.xml (WinUI/Fluent resource dictionary, optional)

Usage:
  python scripts/build-tokens.py              # builds all outputs
  python scripts/build-tokens.py --css        # CSS only
  python scripts/build-tokens.py --tailwind   # Tailwind only
  python scripts/build-tokens.py --winui      # WinUI only
  python scripts/build-tokens.py --watch      # rebuild on change (requires watchdog)
"""

import argparse
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    print("ERROR: pyyaml is required. Install with: pip install pyyaml", file=sys.stderr)
    sys.exit(1)

# ----------------------------------------------------------------------------
# PATHS
# ----------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
SOURCE_FILE = PROJECT_ROOT / "systems" / "unity" / "boo" / "02-tokens.yaml"
OUTPUT_CSS = PROJECT_ROOT / "systems" / "unity" / "dist" / "tokens.css"
OUTPUT_TAILWIND = PROJECT_ROOT / "systems" / "unity" / "dist" / "tokens.tailwind.config.js"
OUTPUT_WINUI = PROJECT_ROOT / "systems" / "unity" / "dist" / "tokens.styles.xml"


# ----------------------------------------------------------------------------
# REFERENCE RESOLVER
# ----------------------------------------------------------------------------
# Semantic tokens have refs like "primitives.color.blue.600".
# This walks the nested dict to resolve them.
# For transparent values (hex + alpha), the ref is to the wrapper dict;
# we resolve the inner .hex and .alpha and produce rgba() in CSS.

class TokenResolver:
    def __init__(self, source: dict):
        self.source = source
    
    def resolve(self, ref: str) -> Any:
        """Resolve a dotted path like 'primitives.color.blue.600' to its value."""
        parts = ref.split(".")
        node = self.source
        for part in parts:
            if isinstance(node, dict) and part in node:
                node = node[part]
            elif isinstance(node, dict) and part.isdigit() and int(part) in node:
                node = node[int(part)]
            else:
                raise KeyError(f"Could not resolve ref '{ref}' at part '{part}'")
        return node
    
    def resolve_to_css_value(self, ref_or_hex) -> str:
        """
        Resolve a ref/hex/alpha to a CSS color value.
        - "primitives.color.blue.600" → "#0672CB"
        - {"ref": "primitives.color.blue.600"} → "#0672CB"
        - {"hex": "#0672CB", "alpha": 0.6} → "rgba(6, 114, 203, 0.6)"
        - "#94DCF7" → "#94DCF7"
        """
        # Unwrap { ref: "..." } dicts
        if isinstance(ref_or_hex, dict) and "ref" in ref_or_hex:
            ref_or_hex = ref_or_hex["ref"]

        # If it's already a transparent dict, produce rgba immediately
        if isinstance(ref_or_hex, dict) and "hex" in ref_or_hex and "alpha" in ref_or_hex:
            return hex_to_rgba(ref_or_hex["hex"], ref_or_hex["alpha"])

        # Try as a ref first
        try:
            value = self.resolve(ref_or_hex)
        except KeyError:
            value = ref_or_hex  # it's already a literal
        
        # If it's a transparent dict, produce rgba
        if isinstance(value, dict) and "hex" in value and "alpha" in value:
            return hex_to_rgba(value["hex"], value["alpha"])
        
        # If it's a plain hex string, return as-is
        if isinstance(value, str) and value.startswith("#"):
            return value
        
        # Otherwise return the resolved value (e.g., for "transparent" → "rgba(...)")
        if isinstance(value, dict) and "ref" in value:
            return self.resolve_to_css_value(value["ref"])
        
        return str(value)


def hex_to_rgba(hex_color: str, alpha: float) -> str:
    """Convert #RRGGBB + alpha to rgba(r, g, b, a)."""
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    # Round alpha to 2 decimal places to keep CSS readable
    a = round(alpha, 2)
    return f"rgba({r}, {g}, {b}, {a})"


# ----------------------------------------------------------------------------
# CSS GENERATION
# ----------------------------------------------------------------------------

def generate_css(source: dict) -> str:
    resolver = TokenResolver(source)
    primitives = source["primitives"]
    semantic = source["semantic"]
    typography = source["typography"]
    spacing = source["spacing"]
    radius = source["radius"]
    elevation = source["elevation"]
    motion = source["motion"]
    
    lines = [
        "/* " + "=" * 76,
        " * tokens.css",
        " * GENERATED FILE — do not edit directly.",
        " * Source: unity-tokens.yaml",
        " * Regenerate with: python scripts/build-tokens.py",
        " * " + "=" * 76,
        " */",
        "",
        "/* -------------------------------------------------------------------------",
        " * PRIMITIVES",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    
    # --- Primitives: colors ---
    lines.append("  /* Primitives: Color */")
    primitives_color = primitives["color"]
    for family, values in primitives_color.items():
        if not isinstance(values, dict):
            continue
        for step, value in values.items():
            if isinstance(value, str) and value.startswith("#"):
                lines.append(f"  --color-{family}-{step}: {value};")
    
    # --- Primitives: transparent colors (as rgba) ---
    lines.append("")
    lines.append("  /* Primitives: Transparent (resolved to rgba) */")
    for family, values in primitives_color.items():
        if not isinstance(values, dict):
            continue
        for step, value in values.items():
            if isinstance(value, dict) and "hex" in value and "alpha" in value:
                rgba = hex_to_rgba(value["hex"], value["alpha"])
                lines.append(f"  --color-{family}-{step}: {rgba};")
    
    lines.append("}")
    lines.append("")
    
    # --- Light mode (default) ---
    lines.extend(_css_mode_block("Light", semantic["color"]["light"], resolver, "light"))
    lines.append("")
    
    # --- Dark mode ---
    lines.extend(_css_mode_block("Dark", semantic["color"]["dark"], resolver, "dark"))
    lines.append("")
    
    # --- Typography ---
    lines.extend(_css_typography(typography))
    lines.append("")
    
    # --- Spacing ---
    lines.extend(_css_spacing(spacing))
    lines.append("")
    
    # --- Radius ---
    lines.extend(_css_radius(radius))
    lines.append("")
    
    # --- Elevation ---
    lines.extend(_css_elevation(elevation))
    lines.append("")
    
    # --- Motion ---
    lines.extend(_css_motion(motion))
    lines.append("")
    
    # --- Z-index ---
    if "z_index" in source:
        lines.extend(_css_z_index(source["z_index"]))
        lines.append("")
    
    return "\n".join(lines)


def _css_mode_block(label: str, mode_tokens: dict, resolver: TokenResolver, mode_key: str) -> list:
    """Generate a [data-theme="X"] or @media block for one mode."""
    selector = f'[data-theme="{mode_key}"]'
    lines = [
        "/* -------------------------------------------------------------------------",
        f" * SEMANTIC TOKENS — {label.upper()} MODE",
        " * ------------------------------------------------------------------------- */",
        f"{selector} {{",
    ]
    
    for category in ["background", "foreground", "border"]:
        lines.append(f"  /* {label} {category.title()} */")
        for token_name, token_value in mode_tokens[category].items():
            css_value = resolver.resolve_to_css_value(token_value)
            lines.append(f"  --{category}-{token_name}: {css_value};")
        lines.append("")
    
    lines.append("}")
    return lines


def _css_typography(typography: dict) -> list:
    lines = [
        "/* -------------------------------------------------------------------------",
        " * TYPOGRAPHY",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    
    # Font families
    lines.append("  /* Font families */")
    for family_name, family_value in typography["family"].items():
        lines.append(f"  --font-family-{family_name}: {family_value};")
    
    lines.append("")
    lines.append("  /* Type scale */")
    scale = typography["scale"]
    for role, props in scale.items():
        if not isinstance(props, dict):
            continue
        size = props.get("size")
        line_height = props.get("lineHeight")
        weight = props.get("weight")
        tracking = props.get("tracking", 0)
        # Convert lineHeight (multiplier) to pixel value
        lh_px = round(size * line_height) if isinstance(line_height, (int, float)) and isinstance(size, (int, float)) else None
        # Convert tracking (% or decimal) to em
        if isinstance(tracking, (int, float)):
            tracking_em = round(tracking / 100, 4) if abs(tracking) > 0.05 else 0
        else:
            tracking_em = 0
        
        lines.append(f"  --type-{role}-size: {size}px;")
        if lh_px:
            lines.append(f"  --type-{role}-line-height: {lh_px}px;")
        if weight is not None:
            lines.append(f"  --type-{role}-weight: {weight};")
        lines.append(f"  --type-{role}-tracking: {tracking_em}em;")
        if props.get("transform"):
            lines.append(f"  --type-{role}-transform: {props['transform']};")
        if "family" in props:
            lines.append(f"  --type-{role}-family: {props['family']};")
    
    lines.append("}")
    return lines


def _css_spacing(spacing: dict) -> list:
    lines = [
        "/* -------------------------------------------------------------------------",
        " * SPACING",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    lines.append(f"  --spacing-base: {spacing['base']}px;")
    lines.append("")
    
    lines.append("  /* Component spacing */")
    for category in ["margin", "gap"]:
        lines.append(f"  /* {category} */")
        for step, value in spacing[category].items():
            lines.append(f"  --spacing-{category}-{step}: {value}px;")
        lines.append("")
    
    lines.append("  /* Page relationship spacing */")
    for rel, value in spacing["relationship"].items():
        lines.append(f"  --spacing-relationship-{rel.replace('_', '-')}: {value}px;")
    
    lines.append("}")
    return lines


def _css_radius(radius: dict) -> list:
    lines = [
        "/* -------------------------------------------------------------------------",
        " * RADIUS",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    for role, value in radius.items():
        css_value = "50%" if value == "100%" else f"{value}px"
        # Convert camelCase to kebab-case
        css_role = "".join(["-" + c.lower() if c.isupper() else c for c in role]).lstrip("-")
        lines.append(f"  --radius-{css_role}: {css_value};")
    lines.append("}")
    return lines


def _css_elevation(elevation: dict) -> list:
    lines = [
        "/* -------------------------------------------------------------------------",
        " * ELEVATION",
        " * Multi-layer shadow stacks + chrome shadows",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    color = elevation.get("color", "rgba(0, 42, 88, 0.08)")
    lines.append(f"  --elevation-color: {color};")
    lines.append("")
    
    # Elevation levels
    lines.append("  /* Elevation levels (3 directions × 4 levels) */")
    for level in ["1", "2", "3", "4"]:
        if level not in elevation:
            continue
        for direction in ["right", "bottom", "left"]:
            if direction not in elevation[level]:
                continue
            shadows = elevation[level][direction]
            shadow_values = []
            for s in shadows:
                ox = s.get("offsetX", 0)
                oy = s.get("offsetY", 0)
                blur = s.get("blur", 0)
                spread = s.get("spread", 0)
                shadow_values.append(f"{ox}px {oy}px {blur}px {spread}px {color}")
            shadow_str = ", ".join(shadow_values)
            lines.append(f"  --elevation-{level}-{direction}: {shadow_str};")
    
    # Chrome shadows
    lines.append("")
    lines.append("  /* Chrome shadows (separate category) */")
    if "chrome" in elevation:
        for name, value in elevation["chrome"].items():
            if isinstance(value, dict) and "value" in value:
                lines.append(f"  --shadow-chrome-{name.replace('_', '-')}: {value['value']};")
                if "use" in value:
                    lines.append(f"  /* {value['use']} */")
            elif isinstance(value, (int, float)):
                lines.append(f"  --backdrop-blur-{name.replace('_', '-')}: {value}px;")
    
    lines.append("}")
    return lines


def _css_motion(motion: dict) -> list:
    lines = [
        "/* -------------------------------------------------------------------------",
        " * MOTION",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    lines.append("  /* Easing */")
    for name, value in motion["easing"].items():
        lines.append(f"  --ease-{name}: {value};")
    
    lines.append("")
    lines.append("  /* Duration */")
    for name, value in motion["duration"].items():
        lines.append(f"  --duration-{name}: {value}s;")
    
    lines.append("")
    lines.append("  /* Delay */")
    for name, value in motion["delay"].items():
        lines.append(f"  --delay-{name}: {value}s;")
    
    lines.append("}")
    return lines


def _css_z_index(z_index: dict) -> list:
    lines = [
        "/* -------------------------------------------------------------------------",
        " * Z-INDEX",
        " * ------------------------------------------------------------------------- */",
        ":root {",
    ]
    for layer, value in z_index.items():
        if isinstance(value, (int, float)):
            lines.append(f"  --z-index-{layer.replace('_', '-')}: {value};")
    lines.append("}")
    return lines


# ----------------------------------------------------------------------------
# TAILWIND GENERATION
# ----------------------------------------------------------------------------

def generate_tailwind(source: dict) -> str:
    primitives = source["primitives"]
    semantic = source["semantic"]
    typography = source["typography"]
    spacing = source["spacing"]
    radius = source["radius"]
    elevation = source["elevation"]
    motion = source["motion"]
    
    # Tailwind theme keys (used in class names like bg-brand-base, text-default)
    # We use camelCase keys inside the JS object, Tailwind handles the rest.
    
    lines = [
        "// " + "=" * 76,
        "// tokens.tailwind.config.js",
        "// GENERATED FILE — do not edit directly.",
        "// Source: unity-tokens.yaml",
        "// Regenerate with: python scripts/build-tokens.py",
        "// " + "=" * 76,
        "",
        "/** @type {import('tailwindcss').Config} */",
        "module.exports = {",
        "  darkMode: ['selector', '[data-theme=\"dark\"]'],",
        "  theme: {",
        "    extend: {",
    ]
    
    # ---- COLORS ----
    lines.append("      colors: {")
    
    # Primitives (accessible as blue-600, gray-100, etc.)
    lines.append("        // Primitives (direct values)")
    primitives_color = primitives["color"]
    for family, values in primitives_color.items():
        if not isinstance(values, dict):
            continue
        for step, value in values.items():
            if isinstance(value, str) and value.startswith("#"):
                # JS key can't have hyphens in some contexts, but object keys are fine
                lines.append(f"        '{family}-{step}': '{value}',")
            elif isinstance(value, dict) and "hex" in value:
                rgba = hex_to_rgba(value["hex"], value["alpha"])
                lines.append(f"        '{family}-{step}': '{rgba}',")
    
    # Semantic (light is default; dark overrides via [data-theme="dark"])
    lines.append("")
    lines.append("        // Semantic — light (default)")
    for category in ["background", "foreground", "border"]:
        lines.append(f"        // {category}")
        for token_name, token_value in semantic["color"]["light"][category].items():
            # Convert token name to Tailwind class-friendly: remove category prefix
            # "background-brand-base" → "bg-brand-base" via key "brand-base"
            js_value = _token_to_js_value(token_value)
            lines.append(f"        '{token_name}': '{js_value}',")
    
    lines.append("      },")
    lines.append("")
    lines.append("      // Semantic — dark mode (use with [data-theme=\"dark\"] selector)")
    lines.append("      // Applied via the darkMode config above; tokens switch automatically.")
    lines.append("      // For component-level dark mode, use the 'dark:' prefix in classes.")
    
    # ---- TYPOGRAPHY ----
    lines.append("")
    lines.extend(_tailwind_typography(typography))
    
    # ---- SPACING ----
    lines.append("")
    lines.extend(_tailwind_spacing(spacing))
    
    # ---- RADIUS ----
    lines.append("")
    lines.extend(_tailwind_radius(radius))
    
    # ---- BOX SHADOW (elevation) ----
    lines.append("")
    lines.extend(_tailwind_elevation(elevation))
    
    # ---- TRANSITION (motion) ----
    lines.append("")
    lines.extend(_tailwind_motion(motion))
    
    lines.append("    },")
    lines.append("  },")
    lines.append("};")
    return "\n".join(lines)


def _token_to_js_value(token_value: Any) -> str:
    """Convert a token ref/hex/transparent to a CSS value string for Tailwind."""
    if isinstance(token_value, str):
        if token_value.startswith("#"):
            return token_value
        if token_value.startswith("rgba") or token_value.startswith("rgb"):
            return token_value
        # It's a ref path; resolve via TokenResolver
        # (We need the source here, so this function is context-dependent)
        return token_value  # Will be resolved by caller
    if isinstance(token_value, dict) and "ref" in token_value:
        return token_value["ref"]  # Also resolve via caller
    if isinstance(token_value, dict) and "hex" in token_value:
        return hex_to_rgba(token_value["hex"], token_value["alpha"])
    return str(token_value)


def _tailwind_typography(typography: dict) -> list:
    lines = ["      fontFamily: {"]
    for name, value in typography["family"].items():
        # CSS string for font-family
        css_value = ", ".join(f'"{v}"' if " " in v else v for v in [value]) if isinstance(value, str) else value
        lines.append(f"        {name}: [{css_value}],")
    lines.append("      },")
    
    lines.append("")
    lines.append("      fontSize: {")
    for role, props in typography["scale"].items():
        if not isinstance(props, dict):
            continue
        size = props.get("size")
        lh = props.get("lineHeight")
        lh_str = f'lineHeight: "{round(size * lh, 2)}px"' if lh else ""
        weight = props.get("weight")
        weight_str = f"fontWeight: {weight}" if weight else ""
        tracking = props.get("tracking", 0)
        tracking_em = round(tracking / 100, 4) if isinstance(tracking, (int, float)) and abs(tracking) > 0.05 else 0
        tracking_str = f"letterSpacing: '{tracking_em}em'" if tracking_em else ""
        
        extras = ", ".join(filter(None, [lh_str, weight_str, tracking_str]))
        extras_part = f", {{ {extras} }}" if extras else ""
        lines.append(f"        '{role}': ['{size}px'{extras_part}],")
    lines.append("      },")
    return lines


def _tailwind_spacing(spacing: dict) -> list:
    lines = ["      spacing: {"]
    lines.append(f"        base: '{spacing['base']}px',")
    
    for category in ["margin", "gap"]:
        for step, value in spacing[category].items():
            lines.append(f"        '{category}-{step}': '{value}px',")
    
    for rel, value in spacing["relationship"].items():
        lines.append(f"        'rel-{rel.replace("_", "-")}': '{value}px',")
    
    lines.append("      },")
    return lines


def _tailwind_radius(radius: dict) -> list:
    lines = ["      borderRadius: {"]
    for role, value in radius.items():
        css_value = "50%" if value == "100%" else f"{value}px"
        css_role = "".join(["-" + c.lower() if c.isupper() else c for c in role]).lstrip("-")
        lines.append(f"        '{css_role}': '{css_value}',")
    lines.append("      },")
    return lines


def _tailwind_elevation(elevation: dict) -> list:
    lines = ["      boxShadow: {"]
    color = elevation.get("color", "rgba(0, 42, 88, 0.08)")
    for level in ["1", "2", "3", "4"]:
        if level not in elevation:
            continue
        for direction in ["right", "bottom", "left"]:
            if direction not in elevation[level]:
                continue
            shadows = elevation[level][direction]
            shadow_values = []
            for s in shadows:
                ox = s.get("offsetX", 0)
                oy = s.get("offsetY", 0)
                blur = s.get("blur", 0)
                spread = s.get("spread", 0)
                shadow_values.append(f"{ox}px {oy}px {blur}px {spread}px {color}")
            shadow_str = ", ".join(shadow_values)
            lines.append(f"        'elevation-{level}-{direction}': '{shadow_str}',")
    
    if "chrome" in elevation:
        for name, value in elevation["chrome"].items():
            if isinstance(value, dict) and "value" in value:
                lines.append(f"        'chrome-{name.replace("_", "-")}': '{value['value']}',")
    
    lines.append("      },")
    return lines


def _tailwind_motion(motion: dict) -> list:
    lines = ["      transitionTimingFunction: {"]
    for name, value in motion["easing"].items():
        lines.append(f"        '{name}': '{value}',")
    lines.append("      },")
    
    lines.append("")
    lines.append("      transitionDuration: {")
    for name, value in motion["duration"].items():
        lines.append(f"        '{name}': '{value}s',")
    lines.append("      },")
    
    lines.append("")
    lines.append("      transitionDelay: {")
    for name, value in motion["delay"].items():
        lines.append(f"        '{name}': '{value}s',")
    lines.append("      },")
    return lines


# ----------------------------------------------------------------------------
# WINUI GENERATION
# ----------------------------------------------------------------------------

def generate_winui(source: dict) -> str:
    primitives = source["primitives"]
    semantic = source["semantic"]
    
    lines = [
        "<?xml version=\"1.0\" encoding=\"utf-8\"?>",
        "<!-- " + "=" * 76,
        "  tokens.styles.xml",
        "  GENERATED FILE — do not edit directly.",
        "  Source: unity-tokens.yaml",
        "  Regenerate with: python scripts/build-tokens.py",
        "  " + "=" * 76,
        "-->",
        "<ResourceDictionary",
        "    xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"",
        "    xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\">",
        "",
        "    <!-- ==================== LIGHT THEME ==================== -->",
    ]
    
    # Resolve all light semantic tokens
    for category in ["background", "foreground", "border"]:
        lines.append(f"    <!-- {category.title()} (Light) -->")
        for token_name, token_value in semantic["color"]["light"][category].items():
            css_value = _token_to_js_value(token_value)
            # If still a ref, resolve it
            if isinstance(css_value, str) and css_value.startswith("semantic.") or \
               (isinstance(css_value, str) and "primitives" in css_value):
                # Use TokenResolver inline
                resolver = TokenResolver(source)
                css_value = resolver.resolve_to_css_value(css_value)
            winui_name = _camel_to_pascal(f"Unity{_underscore_to_pascal(token_name)}")
            lines.append(f"    <Color x:Key=\"{winui_name}\">{_to_winui_color(css_value)}</Color>")
        lines.append("")
    
    # Dark theme
    lines.append("    <!-- ==================== DARK THEME ==================== -->")
    lines.append("    <ResourceDictionary.ThemeDictionaries>")
    lines.append("        <ResourceDictionary x:Key=\"Dark\">")
    for category in ["background", "foreground", "border"]:
        lines.append(f"            <!-- {category.title()} (Dark) -->")
        for token_name, token_value in semantic["color"]["dark"][category].items():
            resolver = TokenResolver(source)
            css_value = resolver.resolve_to_css_value(token_value)
            winui_name = _camel_to_pascal(f"Unity{_underscore_to_pascal(token_name)}")
            lines.append(f"            <Color x:Key=\"{winui_name}\">{_to_winui_color(css_value)}</Color>")
        lines.append("")
    lines.append("        </ResourceDictionary>")
    lines.append("    </ResourceDictionary.ThemeDictionaries>")
    
    lines.append("</ResourceDictionary>")
    return "\n".join(lines)


def _camel_to_pascal(name: str) -> str:
    return name[0].upper() + name[1:] if name else name


def _underscore_to_pascal(name: str) -> str:
    return "".join(p.capitalize() for p in name.split("-"))


def _to_winui_color(value: str) -> str:
    """Convert CSS color (hex or rgba) to WinUI #AARRGGBB format."""
    if value.startswith("#"):
        # Pad to 8 hex digits with FF alpha
        hex_val = value.lstrip("#")
        if len(hex_val) == 6:
            return f"#{hex_val}FF"
        return f"#{hex_val}"
    if value.startswith("rgba"):
        # Parse rgba(r, g, b, a) → #AARRGGBB
        import re
        match = re.match(r"rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)", value)
        if match:
            r, g, b, a = match.groups()
            a = int(float(a or 1) * 255)
            return f"#{a:02X}{int(r):02X}{int(g):02X}{int(b):02X}"
    return value


# ----------------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Build Unity design tokens from unity-tokens.yaml")
    parser.add_argument("--css", action="store_true", help="Build CSS only")
    parser.add_argument("--tailwind", action="store_true", help="Build Tailwind config only")
    parser.add_argument("--winui", action="store_true", help="Build WinUI resource dictionary only")
    parser.add_argument("--watch", action="store_true", help="Rebuild on change (requires watchdog)")
    args = parser.parse_args()
    
    # If no specific output requested, build all
    build_all = not (args.css or args.tailwind or args.winui)
    
    if not SOURCE_FILE.exists():
        print(f"ERROR: {SOURCE_FILE} not found", file=sys.stderr)
        sys.exit(1)
    
    with open(SOURCE_FILE, "r", encoding="utf-8") as f:
        source = yaml.safe_load(f)
    
    # ---- Watch mode ----
    if args.watch:
        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler
        except ImportError:
            print("ERROR: --watch requires watchdog. Install with: pip install watchdog", file=sys.stderr)
            sys.exit(1)
        
        class RebuildHandler(FileSystemEventHandler):
            def on_modified(self, event):
                if event.src_path.endswith("unity-tokens.yaml"):
                    print(f"Detected change in {event.src_path}, rebuilding...")
                    build(source)
        
        observer = Observer()
        observer.schedule(RebuildHandler, str(SOURCE_FILE.parent), recursive=False)
        observer.start()
        print(f"Watching {SOURCE_FILE} for changes. Press Ctrl+C to stop.")
        try:
            while True:
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
        observer.join()
        return
    
    build(source, css=build_all or args.css,
                tailwind=build_all or args.tailwind,
                winui=build_all or args.winui)


def build(source: dict, css: bool = True, tailwind: bool = True, winui: bool = True):
    if css:
        css_output = generate_css(source)
        with open(OUTPUT_CSS, "w", encoding="utf-8") as f:
            f.write(css_output)
        print(f"✓ Generated {OUTPUT_CSS.relative_to(PROJECT_ROOT)} ({len(css_output):,} chars)")
    
    if tailwind:
        tw_output = generate_tailwind(source)
        with open(OUTPUT_TAILWIND, "w", encoding="utf-8") as f:
            f.write(tw_output)
        print(f"✓ Generated {OUTPUT_TAILWIND.relative_to(PROJECT_ROOT)} ({len(tw_output):,} chars)")
    
    if winui:
        winui_output = generate_winui(source)
        with open(OUTPUT_WINUI, "w", encoding="utf-8") as f:
            f.write(winui_output)
        print(f"✓ Generated {OUTPUT_WINUI.relative_to(PROJECT_ROOT)} ({len(winui_output):,} chars)")


if __name__ == "__main__":
    main()
