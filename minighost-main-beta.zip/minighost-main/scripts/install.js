// Moved to scripts/installer/install.js
// This file is no longer used. Run: node scripts/installer/install.js

// Get minighost installation directory
const MINIGHOST_PATH = path.dirname(__dirname);

// Platform-specific paths
const isWindows = process.platform === 'win32';
const isMac = process.platform === 'darwin';
const isLinux = process.platform === 'linux';

function getHomeDir() {
  return os.homedir();
}

// Claude config paths
function getClaudeConfigPath() {
  const home = getHomeDir();
  if (isWindows) {
    return path.join(home, '.claude');
  } else {
    return path.join(home, '.claude');
  }
}

// Windsurf global rules path
function getWindsurfGlobalRulesPath() {
  const home = getHomeDir();
  return path.join(home, '.codeium', 'windsurf', 'memories', 'global_rules.md');
}

// Backup a file
function backupFile(filePath) {
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const backupPath = `${filePath}.minighost-backup`;
  fs.copyFileSync(filePath, backupPath);
  console.log(`✓ Backed up: ${filePath} -> ${backupPath}`);
  return backupPath;
}

// Restore a file from backup
function restoreFile(originalPath) {
  const backupPath = `${originalPath}.minighost-backup`;
  if (fs.existsSync(backupPath)) {
    fs.copyFileSync(backupPath, originalPath);
    fs.unlinkSync(backupPath);
    console.log(`✓ Restored: ${originalPath}`);
    return true;
  }
  return false;
}

// Install Claude integration
function installClaude() {
  const claudeDir = getClaudeConfigPath();
  const claudeMdPath = path.join(claudeDir, 'CLAUDE.md');
  
  console.log('\n--- Claude Desktop Integration ---');
  
  // Create .claude directory if it doesn't exist
  if (!fs.existsSync(claudeDir)) {
    fs.mkdirSync(claudeDir, { recursive: true });
    console.log(`✓ Created directory: ${claudeDir}`);
  }
  
  // Backup existing CLAUDE.md
  const backupPath = backupFile(claudeMdPath);
  
  // Add minighost configuration
  const minighostConfig = `
# MINIGHOST CONFIGURATION
# Minighost is active. To disable, remove this section or run: ghost --disable
# Design system: unity (default)
# Mode: strict (enforces all design system rules)

`;
  
  if (fs.existsSync(claudeMdPath)) {
    // Prepend to existing file
    const existingContent = fs.readFileSync(claudeMdPath, 'utf8');
    fs.writeFileSync(claudeMdPath, minighostConfig + existingContent);
    console.log(`✓ Updated: ${claudeMdPath}`);
  } else {
    // Create new file
    fs.writeFileSync(claudeMdPath, minighostConfig);
    console.log(`✓ Created: ${claudeMdPath}`);
  }
  
  return true;
}

// Install Windsurf integration
function installWindsurf() {
  const windsurfRulesPath = getWindsurfGlobalRulesPath();
  const windsurfDir = path.dirname(windsurfRulesPath);
  
  console.log('\n--- Windsurf Integration ---');
  
  // Create directory structure if it doesn't exist
  if (!fs.existsSync(windsurfDir)) {
    fs.mkdirSync(windsurfDir, { recursive: true });
    console.log(`✓ Created directory: ${windsurfDir}`);
  }
  
  // Backup existing global_rules.md
  const backupPath = backupFile(windsurfRulesPath);
  
  // Add minighost configuration
  const minighostConfig = `# MINIGHOST CONFIGURATION
# Minighost is active. To disable, remove this section or run: ghost --disable
# Design system: unity (default)
# Mode: strict (enforces all design system rules)

`;
  
  if (fs.existsSync(windsurfRulesPath)) {
    // Prepend to existing file
    const existingContent = fs.readFileSync(windsurfRulesPath, 'utf8');
    fs.writeFileSync(windsurfRulesPath, minighostConfig + existingContent);
    console.log(`✓ Updated: ${windsurfRulesPath}`);
  } else {
    // Create new file
    fs.writeFileSync(windsurfRulesPath, minighostConfig);
    console.log(`✓ Created: ${windsurfRulesPath}`);
  }
  
  return true;
}

// Main installation
function main() {
  console.log('=== Minighost Installation ===');
  console.log(`Platform: ${process.platform}`);
  console.log(`Minighost path: ${MINIGHOST_PATH}`);
  
  let claudeInstalled = false;
  let windsurfInstalled = false;
  
  // Try to install Claude integration
  try {
    claudeInstalled = installClaude();
  } catch (error) {
    console.log(`✗ Claude integration failed: ${error.message}`);
  }
  
  // Try to install Windsurf integration
  try {
    windsurfInstalled = installWindsurf();
  } catch (error) {
    console.log(`✗ Windsurf integration failed: ${error.message}`);
  }
  
  console.log('\n=== Installation Summary ===');
  console.log(`Claude Desktop: ${claudeInstalled ? '✓ Installed' : '✗ Not installed'}`);
  console.log(`Windsurf: ${windsurfInstalled ? '✓ Installed' : '✗ Not installed'}`);
  
  if (claudeInstalled || windsurfInstalled) {
    console.log('\nMinighost is now active!');
    console.log('To disable: ghost --disable');
    console.log('To enable: ghost --enable');
    console.log('To check status: ghost --status');
  } else {
    console.log('\nNo AI agents detected. Minighost files are installed but not activated.');
    console.log('You can manually configure your AI agent to use minighost rules.');
  }
}

// Run installation
main();
