// Moved to scripts/installer/uninstall.js
// This file is no longer used. Run: node scripts/installer/uninstall.js

// Platform-specific paths
const isWindows = process.platform === 'win32';
const isMac = process.platform === 'darwin';
const isLinux = process.platform === 'linux';

function getHomeDir() {
  return os.homedir();
}

// Claude config paths
function getClaudeConfigPath() {
  const home = getHomeDir();
  if (isWindows) {
    return path.join(home, '.claude');
  } else {
    return path.join(home, '.claude');
  }
}

// Windsurf global rules path
function getWindsurfGlobalRulesPath() {
  const home = getHomeDir();
  return path.join(home, '.codeium', 'windsurf', 'memories', 'global_rules.md');
}

// Remove minighost configuration from a file
function removeMinighostConfig(filePath) {
  if (!fs.existsSync(filePath)) {
    console.log(`✗ File not found: ${filePath}`);
    return false;
  }
  
  const backupPath = `${filePath}.minighost-backup`;
  
  // If backup exists, restore it
  if (fs.existsSync(backupPath)) {
    fs.copyFileSync(backupPath, filePath);
    fs.unlinkSync(backupPath);
    console.log(`✓ Restored from backup: ${filePath}`);
    return true;
  }
  
  // Otherwise, remove minighost section from file
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  
  // Find and remove minighost configuration block
  const minighostStart = lines.findIndex(line => line.includes('MINIGHOST CONFIGURATION'));
  if (minighostStart === -1) {
    console.log(`✗ No minighost configuration found in: ${filePath}`);
    return false;
  }
  
  // Find the end of the minighost block (next section or empty line after config)
  let minighostEnd = minighostStart;
  for (let i = minighostStart + 1; i < lines.length; i++) {
    if (lines[i].trim() === '' && i > minighostStart + 5) {
      minighostEnd = i;
      break;
    }
    if (lines[i].startsWith('#') && !lines[i].includes('MINIGHOST')) {
      minighostEnd = i;
      break;
    }
  }
  
  // Remove the minighost block
  const newLines = lines.slice(0, minighostStart).concat(lines.slice(minighostEnd + 1));
  const newContent = newLines.join('\n').trim() + '\n';
  
  fs.writeFileSync(filePath, newContent);
  console.log(`✓ Removed minighost configuration from: ${filePath}`);
  return true;
}

// Uninstall Claude integration
function uninstallClaude() {
  const claudeDir = getClaudeConfigPath();
  const claudeMdPath = path.join(claudeDir, 'CLAUDE.md');
  
  console.log('\n--- Claude Desktop Integration ---');
  
  if (!fs.existsSync(claudeMdPath)) {
    console.log('✗ Claude CLAUDE.md not found (already uninstalled?)');
    return false;
  }
  
  return removeMinighostConfig(claudeMdPath);
}

// Uninstall Windsurf integration
function uninstallWindsurf() {
  const windsurfRulesPath = getWindsurfGlobalRulesPath();
  
  console.log('\n--- Windsurf Integration ---');
  
  if (!fs.existsSync(windsurfRulesPath)) {
    console.log('✗ Windsurf global_rules.md not found (already uninstalled?)');
    return false;
  }
  
  return removeMinighostConfig(windsurfRulesPath);
}

// Main uninstallation
function main() {
  console.log('=== Minighost Uninstallation ===');
  console.log(`Platform: ${process.platform}`);
  
  let claudeUninstalled = false;
  let windsurfUninstalled = false;
  
  // Try to uninstall Claude integration
  try {
    claudeUninstalled = uninstallClaude();
  } catch (error) {
    console.log(`✗ Claude uninstallation failed: ${error.message}`);
  }
  
  // Try to uninstall Windsurf integration
  try {
    windsurfUninstalled = uninstallWindsurf();
  } catch (error) {
    console.log(`✗ Windsurf uninstallation failed: ${error.message}`);
  }
  
  console.log('\n=== Uninstallation Summary ===');
  console.log(`Claude Desktop: ${claudeUninstalled ? '✓ Uninstalled' : '✗ Not uninstalled'}`);
  console.log(`Windsurf: ${windsurfUninstalled ? '✓ Uninstalled' : '✗ Not uninstalled'}`);
  
  if (claudeUninstalled || windsurfUninstalled) {
    console.log('\nMinighost has been removed from your AI agent configurations.');
  } else {
    console.log('\nNo minighost configurations found to remove.');
  }
}

// Run uninstallation
main();
