# MINIGHOST
AI-assisted UI generation.

## Session Start

At the start of every session, before doing anything else, ask:

> "What are you working on today?"
> 1. An existing product
> 2. A new product
> 3. Just exploring or testing

Wait for one of these three options before doing anything else.
Do not interpret any other message as a design request until this question is answered.
If the user sends a design prompt before answering, respond only with the question and options again.

Then branch based on the answer:

- **Option 1** — Read the subfolders inside `BOO/core-products/` and present them as a numbered list, with one final option: "None of these". Wait for the designer to respond with a number.
  - If they pick a product — load that product folder alongside the global BOO files and begin the session.
  - If they pick "None of these" — treat as Option 2 and read and follow `BOO/ghost-onboarding.md`.
- **Option 2** — Read and follow `BOO/ghost-onboarding.md` before doing anything else.
- **Option 3** — Skip all product and onboarding steps. Do not create or reference any product folder. Proceed directly to design work.

## After product check resolves — read these now:
1. `BOO/global/design-rules.md`
2. `BOO/global/principles-quick-ref.yaml`
3. `BOO/design-systems/unity/canonical/01-constitution.yaml`

Do not generate anything until these three are read.

## At generation step 6 (component selection) — read on demand:
For each component you select, look up only that component's entry in
`BOO/design-systems/unity/components/components.md`.
Do not read the whole file.

## At generation step 7 (visual values) — read on demand:
Use `BOO/design-systems/unity/components/tokens.css` — the single source for all tokens
(component, semantic, shadows, gradients, radius, motion, z-index, layout constants).
`tokens.yaml` is deprecated — do not read it.

## When choosing an icon — read on demand:
Search `BOO/global/assets/icons-dds2/03-icon-map.yaml` for the name only.
Do not load the full file.

## At generation step 8 (acceptance checklist) — read now:
`BOO/global/accessibility-guides.md`

## Component Selection (step 7a — before rendering)

Before choosing components, consult these files in order:

1. `BOO/design-systems/unity/components/patterns-manifest.yaml` — check for a named screen or section recipe first. If a pattern matches, record it and fill its key_decisions.
2. `BOO/global/component-selection/01-task-ontology.md` — if no pattern matches, walk the task tree to find candidate components.
3. `BOO/global/component-selection/02-selection-decisions.md` — if two or more candidates are returned, use the decision tables to resolve.
4. `BOO/design-systems/unity/components/components-manifest.yaml` — after selecting a component, read its entry for anti-patterns and accessibility requirements.

Do not select components by keyword matching. Always enter from the task.

## Skills

Skills are reusable validation and quality check procedures. Skills are located in `BOO/global/skills/{skill-name}/skill.md` with frontmatter metadata:
- `name`: skill identifier
- `description`: what the skill does
- `trigger`: when the skill runs (e.g., "after_generation")
- `execution`: how the skill runs (e.g., "automatic or user_prompt")
- `scope`: what the skill applies to

After generating a screen, run the `technical-validation` skill (located in `BOO/global/skills/technical-validation/skill.md`) to self-validate against technical criteria (Dimensions 2-4 of the validation rubric). The agent can also run skills on user prompt.

## What We're Building

Browser-based HTML prototypes that mimic Windows native / Electron apps. No build toolchain. One `tokens.css` import, semantic CSS custom properties, `data-theme="light"` or `data-theme="dark"` on the root.

Import tokens as: `BOO/design-systems/unity/components/tokens.css`

## Rules

- Use only tokens from `BOO/design-systems/unity/components/tokens.css`. No invented values, no raw hex.
- Use only icon names from `BOO/global/assets/icons-dds2/03-icon-map.yaml`. No invented names. SVG files live at the path listed in each entry.
- One page framework per screen. One color mode per screen.
- Follow the 9-step generation sequence in the constitution.
- Every output starts with the manifest block (screen, framework, grid, mode, primary action, a11y status).

## Rebuilding Tokens

If `tokens.css` changes (semantic or component tokens), run:
```sh
python scripts/build-tokens.py
```
Commit the generated outputs under `BOO/design-systems/unity/components/`.
