#!/usr/bin/env node

const fs   = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');
const common = require('./scripts/installer/common');

const INSTALL_DIR = path.join(os.homedir(), 'minighost');

const AGENTS = [
  { name: 'Windsurf', path: common.getWindsurfPath() },
  { name: 'Claude Code', path: common.getClaudePath() },
];

const ART = {
  enable: `
░█▄█░▀█▀░█▀█░▀█▀░█▀▀░█░█░█▀█░█▀▀░▀█▀
░█░█░░█░░█░█░░█░░█░█░█▀█░█░█░▀▀█░░█░
░▀░▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░░▀░`,
  disable: `
░█▀▄░█▀█░█▀█░░░█▀▄░█░█░█▀▀
░█▀▄░█░█░█░█░░░█▀▄░░█░░█▀▀
░▀▀░░▀▀▀░▀▀▀░░░▀▀░░░▀░░▀▀▀`,
  uninstall: `
░█░█░█▀█░▀█▀░█▀█░█▀▀░▀█▀░█▀█░█░░░█░░░▀█▀░█▀█░█▀▀░░░░░░░░░
░█░█░█░█░░█░░█░█░▀▀█░░█░░█▀█░█░░░█░░░░█░░█░█░█░█░░░░░░░░░
░▀▀▀░▀░▀░▀▀▀░▀░▀░▀▀▀░░▀░░▀░▀░▀▀▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░░▀░░▀░`,
  update: `
░█░█░█▀█░█▀▄░█▀█░▀█▀░▀█▀░█▀█░█▀▀░░░░░░░░░
░█░█░█▀▀░█░█░█▀█░░█░░░█░░█░█░█░█░░░░░░░░░
░▀▀▀░▀░░░▀▀░░▀░▀░░▀░░▀▀▀░▀░▀░▀▀▀░▀░░▀░░▀░`,
};

function enable() {
  console.log('\nEnabling MiniGhost...');
  console.log(ART.enable);
  console.log('');

  for (const agent of AGENTS) {
    try {
      const injected = common.injectRules(agent.path);
      console.log(injected ? `✓ Enabled: ${agent.name}` : `✓ Already enabled: ${agent.name}`);
    } catch (e) {
      console.log(`✗ ${agent.name}: ${e.message}`);
    }
  }

  console.log('\nEnabled in Windsurf / Claude Code');
}

function disable() {
  console.log('\nDisabling MiniGhost...');
  console.log(ART.disable);
  console.log('');

  for (const agent of AGENTS) {
    try {
      const removed = common.removeRules(agent.path);
      common.cleanOrphanedStubs(agent.path);
      console.log(removed ? `✓ Disabled: ${agent.name}` : `- Not active: ${agent.name}`);
    } catch (e) {
      console.log(`✗ ${agent.name}: ${e.message}`);
    }
  }

  console.log('\nMiniGhost disabled.');
}

function uninstall() {
  console.log('\nUninstalling MiniGhost...');
  console.log(ART.uninstall);
  console.log('');

  for (const agent of AGENTS) {
    try {
      common.removeRules(agent.path);
      common.cleanOrphanedStubs(agent.path);
      console.log(`✓ Removed from: ${agent.name}`);
    } catch (e) {
      console.log(`✗ ${agent.name}: ${e.message}`);
    }
  }

  console.log('\nNote: If you have run "ghost --project" in any design projects, run');
  console.log('"ghost --project-off" in each of those folders to remove the MiniGhost block from those files.');
  console.log('');
  console.log('\nRemoving MiniGhost directory...');
  try {
    const isWindows = process.platform === 'win32';
    if (isWindows) {
      execSync(`powershell -Command "Remove-Item '${INSTALL_DIR}' -Recurse -Force"`, { stdio: 'inherit' });
    } else {
      execSync(`rm -rf "${INSTALL_DIR}"`, { stdio: 'inherit' });
    }
    console.log(`✓ Removed ${INSTALL_DIR}`);
  } catch (e) {
    console.log(`✗ Could not remove ${INSTALL_DIR}: ${e.message}`);
    console.log(`  Make sure you're not in the directory, then remove manually:`);
    if (process.platform === 'win32') {
      console.log(`  Remove-Item '${INSTALL_DIR}' -Recurse -Force`);
    } else {
      console.log(`  rm -rf ${INSTALL_DIR}`);
    }
  }

  console.log('\nMiniGhost removed.');
  if (process.platform === 'win32') {
    console.log('Remove the MiniGhost PATH entry from System Environment Variables manually.');
  } else {
    console.log('Remove the MiniGhost PATH entry from your shell rc file manually.');
  }
}

function update() {
  const oldVersion = common.getInstalledVersion(common.getWindsurfPath()) || 'unknown';
  console.log(`\nChecking for updates (current: v${oldVersion})...`);

  try {
    execSync(`git -C "${INSTALL_DIR}" pull`, { stdio: 'inherit' });
  } catch (e) {
    console.log(`✗ Update failed: ${e.message}`);
    process.exit(1);
  }

  const pkgPath = path.join(INSTALL_DIR, 'package.json');
  delete require.cache[require.resolve(pkgPath)];
  const { version: newVersion } = require(pkgPath);

  if (oldVersion === newVersion) {
    console.log(`\nAlready up to date (v${newVersion})`);
    return;
  }

  console.log(ART.update);
  console.log(`\nUpdating MiniGhost v${oldVersion} → v${newVersion}...`);

  for (const agent of AGENTS) {
    try {
      common.removeRules(agent.path);
      common.injectRules(agent.path);
      console.log(`✓ Rules refreshed: ${agent.name}`);
    } catch (e) {
      console.log(`✗ ${agent.name}: ${e.message}`);
    }
  }

  console.log(`\nUpdated to v${newVersion}`);
}

function status() {
  console.log('\n=== MiniGhost Status ===\n');

  const { version } = require(path.join(common.MINIGHOST_PATH, 'package.json'));
  console.log(`Package version: v${version}\n`);

  let anyEnabled = false;
  for (const agent of AGENTS) {
    const enabled = common.isEnabled(agent.path);
    const agentVersion = enabled ? common.getInstalledVersion(agent.path) : null;
    const label = enabled ? `✓ Enabled (v${agentVersion})` : '✗ Disabled';
    console.log(`${agent.name}: ${label}`);
    if (enabled) anyEnabled = true;
  }

  if (anyEnabled) {
    console.log(ART.enable);
    console.log('\nMiniGhost is active. AI agents are constrained to the Unity design system.');
  } else {
    console.log('\nMiniGhost is inactive. Run "ghost --project" in your design project folder to activate.');
  }

  const cwd = process.cwd();
  if (path.resolve(cwd) !== path.resolve(common.MINIGHOST_PATH)) {
    const cwdWindsurf = path.join(cwd, '.windsurfrules');
    const cwdClaude  = path.join(cwd, 'CLAUDE.md');
    const wsExists   = fs.existsSync(cwdWindsurf);
    const clExists   = fs.existsSync(cwdClaude);

    if (wsExists || clExists) {
      console.log('\n--- Project (cwd) ---');
      console.log(`Path: ${cwd}`);

      if (wsExists) {
        const active = common.isEnabled(cwdWindsurf);
        console.log(active
          ? '✓ .windsurfrules: MiniGhost active'
          : '⚠ .windsurfrules: file exists but MiniGhost not detected — run "ghost --project" to repair');
      } else {
        console.log('- .windsurfrules: not found');
      }

      if (clExists) {
        const active = common.isEnabled(cwdClaude);
        console.log(active
          ? '✓ CLAUDE.md: MiniGhost active'
          : '⚠ CLAUDE.md: file exists but MiniGhost not detected — run "ghost --project" to repair');
      } else {
        console.log('- CLAUDE.md: not found');
      }
    }
  }
}

function projectEnable() {
  const cwd = process.cwd();

  if (path.resolve(cwd) === path.resolve(common.MINIGHOST_PATH)) {
    console.log('\n✗ The MiniGhost source folder is protected and cannot be used as a project.');
    console.log('  Navigate to your design project folder (or create a new one) and run "ghost --project" there.');
    process.exit(1);
  }

  const windsurfPath = path.join(cwd, '.windsurfrules');
  const claudePath  = path.join(cwd, 'CLAUDE.md');

  console.log(`\nEnabling MiniGhost for: ${cwd}`);
  console.log(ART.enable);
  console.log('');

  const results = common.injectProjectRules(windsurfPath, claudePath);

  if (results.windsurf === 'created')  console.log('✓ Created .windsurfrules (Windsurf)');
  if (results.windsurf === 'injected') console.log('✓ Injected MiniGhost into existing .windsurfrules (Windsurf)');
  if (results.windsurf === 'exists')   console.log('✓ .windsurfrules already has MiniGhost (Windsurf)');
  if (results.claude  === 'created')   console.log('✓ Created CLAUDE.md (Claude Code)');
  if (results.claude  === 'injected')  console.log('✓ Injected MiniGhost into existing CLAUDE.md (Claude Code)');
  if (results.claude  === 'exists')    console.log('✓ CLAUDE.md already has MiniGhost (Claude Code)');

  console.log('\nMiniGhost active for this project.');
  console.log('Tip: add .windsurfrules and CLAUDE.md to .gitignore if you don\'t want to commit them.');
}

function projectRemove() {
  const cwd = process.cwd();
  const windsurfPath = path.join(cwd, '.windsurfrules');
  const claudePath  = path.join(cwd, 'CLAUDE.md');

  console.log(`\nRemoving MiniGhost from: ${cwd}`);
  console.log('');

  const results = common.removeProjectRules(windsurfPath, claudePath);

  console.log(results.windsurf ? '✓ Removed MiniGhost from .windsurfrules' : '- No MiniGhost block found in .windsurfrules');
  console.log(results.claude  ? '✓ Removed MiniGhost from CLAUDE.md'       : '- No MiniGhost block found in CLAUDE.md');
  console.log('\nMiniGhost removed from this project.');
}

function onboard() {
  const productName = process.argv[3];
  const coreProductsDir = path.join(common.MINIGHOST_PATH, 'BOO', 'core-products');

  console.log('\n=== MiniGhost Product Onboarding ===\n');

  if (productName) {
    const productPath = path.join(coreProductsDir, productName);
    if (fs.existsSync(productPath)) {
      console.log(`✓ Product folder already exists: BOO/core-products/${productName}/`);
      console.log('  To refresh, tell the agent: "refresh ' + productName + '"');
    } else {
      console.log(`Product: ${productName}`);
      console.log(`Target:  BOO/core-products/${productName}/\n`);
      console.log('Tell your AI agent:');
      console.log(`  "Start onboarding for a new product called ${productName}"\n`);
      console.log('The agent will follow BOO/ghost-onboarding.md and generate:');
      console.log('  - product-context.md');
      console.log('  - component-manifest.md');
      console.log('  - information-architecture.md');
      console.log('  - screen-references.md');
      console.log('  - onboarding-status.md');
      console.log('  - layouts/ (one file per page type)');
      console.log('  - system-overrides/ (intentional Unity overrides)');
    }
  } else {
    const existing = fs.existsSync(coreProductsDir)
      ? fs.readdirSync(coreProductsDir).filter(f =>
          fs.statSync(path.join(coreProductsDir, f)).isDirectory()
        )
      : [];

    if (existing.length > 0) {
      console.log('Existing products in BOO/core-products/:');
      existing.forEach((p, i) => console.log(`  ${i + 1}. ${p}`));
      console.log('');
    }

    console.log('Usage:');
    console.log('  ghost --onboard <product-name>   Start onboarding for a new product');
    console.log('');
    console.log('Or tell your AI agent:');
    console.log('  "Start onboarding for a new product"');
    console.log('  The agent will guide you through the process.\n');
  }
}

function showHelp() {
  console.log(`
MiniGhost — AI-assisted UI generation using the Dell Unity design system

Usage:
  ghost [command]

Commands:
  --project      Enable MiniGhost in the current project folder
  --project-off  Remove MiniGhost from the current project folder
  --onboard      Start product onboarding (optionally: --onboard <product-name>)
  --update       Update to latest version
  --uninstall    Remove MiniGhost and uninstall
  --status       Show current status
  --help         Show this help message

Install:
  curl -fsSL https://githubcsg.cec.delllabs.net/CSG-EDG/minighost/raw/main/install.sh | bash
  `);
}

const command = process.argv[2];
switch (command) {
  case '--project':
  case 'project':
    projectEnable();
    break;
  case '--project-off':
  case 'project-off':
    projectRemove();
    break;
  case '--enable':
  case 'enable':
    enable();
    break;
  case '--disable':
  case 'disable':
    disable();
    break;
  case '--update':
  case 'update':
    update();
    break;
  case '--uninstall':
  case 'uninstall':
    uninstall();
    break;
  case '--onboard':
  case 'onboard':
    onboard();
    break;
  case '--status':
  case 'status':
    status();
    break;
  case '--help':
  case 'help':
  case '-h':
    showHelp();
    break;
  default:
    if (!command) {
      showHelp();
    } else {
      console.log(`Unknown command: ${command}`);
      console.log('Run "ghost --help" for usage.');
      process.exit(1);
    }
}
