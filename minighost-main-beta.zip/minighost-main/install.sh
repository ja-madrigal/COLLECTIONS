#!/usr/bin/env bash
set -e

INSTALL_DIR="$HOME/minighost"
REPO_URL="https://github.com/ja-madrigal/MINIGHOST2.git"
SHELL_RC=""

echo ""
echo "░█▄█░▀█▀░█▀█░▀█▀░█▀▀░█░█░█▀█░█▀▀░▀█▀"
echo "░█░█░░█░░█░█░░█░░█░█░█▀█░█░█░▀▀█░░█░"
echo "░▀░▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀▀▀░░▀░"
echo ""
echo "=== MiniGhost Installer ==="
echo ""

# Check dependencies
if ! command -v git &>/dev/null; then
  echo "Error: git not found. Install Git: https://git-scm.com" >&2; exit 1
fi
if ! command -v node &>/dev/null; then
  echo "Error: node not found. Install Node.js: https://nodejs.org" >&2; exit 1
fi

# Detect shell rc file
if [ "$(basename "$SHELL")" = "zsh" ]; then
  SHELL_RC="$HOME/.zshrc"
elif [ "$(basename "$SHELL")" = "bash" ]; then
  SHELL_RC="$HOME/.bashrc"
  [ "$(uname)" = "Darwin" ] && SHELL_RC="$HOME/.bash_profile"
else
  SHELL_RC="$HOME/.profile"
fi

# Clone or update repo
if [ -d "$INSTALL_DIR/.git" ]; then
  echo "Updating existing installation..."
  git -C "$INSTALL_DIR" pull --quiet
else
  echo "Installing to $INSTALL_DIR..."
  git clone --quiet "$REPO_URL" "$INSTALL_DIR"
fi

# Add to PATH if not already there
if echo "$PATH" | grep -q "$INSTALL_DIR"; then
  echo "✓ $INSTALL_DIR already in PATH"
else
  echo "" >> "$SHELL_RC"
  echo "# MiniGhost" >> "$SHELL_RC"
  echo "export PATH=\"$INSTALL_DIR:\$PATH\"" >> "$SHELL_RC"
  export PATH="$INSTALL_DIR:$PATH"
  echo "✓ Added to PATH ($SHELL_RC)"
fi

# Make ghost.js executable and create ghost symlink
chmod +x "$INSTALL_DIR/ghost.js"
ln -sf "$INSTALL_DIR/ghost.js" "$INSTALL_DIR/ghost"

echo ""
echo "✓ MiniGhost installed to $INSTALL_DIR"
echo ""
echo "Next step: open your design project folder and run:"
echo "  ghost --project"
