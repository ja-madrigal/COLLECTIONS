# BOO Restructure — Architecture Notes

**Branch:** `boo-structure`
**Status:** Proposal — not yet implemented

---

## Why This Change

The current `BOO/` folder was built for one design system (Unity) and has no concept of shared assets, global constraints, or product-level customizations. Several structural problems exist today:

- `BOO/` root mixes global constraints, Unity-specific files, and stranded assets with no clear ownership
- `BOO/icons/` (DDS2) lives as if it's global, but is referenced as if it's Unity-only — it's neither; it's shared across Unity, DDS, Agora, and Dama
- `BOO/skills/` is stranded — the README documents skills at `BOO/{system}/skills/` but the actual file lives at `BOO/skills/`
- `unity/boo/` uses the same word as the parent `BOO/` folder, creating naming ambiguity in conversation and in paths
- No defined home for product-level customizations (e.g. DDPM, which arrives this week)
- All five canonical files are loaded upfront before generation begins, regardless of when each file is actually needed

---

## The Three-Layer Model

Every piece of content in `BOO/` belongs to exactly one layer. The layer is expressed through folder path — no manifest file needed to declare ownership.

### Layer 1 — Global
**Path:** `BOO/global/`

Universal constraints that apply to any design system in the repo. These are not system-specific. They include UI composition rules, cross-system accessibility requirements, design philosophy, validation skills, grid templates, and the universal component selection methodology.

### Layer 2 — Design System / Component Library
**Path:** `BOO/design-systems/{system}/`

Everything specific to one design system. Tokens, components, constitution, layout contracts, distribution outputs. Each system has a `canonical/` subfolder for its authoritative agent-facing files.

### Layer 3 — Recipe (Product Customization)
**Path:** `BOO/design-systems/{system}/{recipe}/`

A recipe lives inside the system it extends. It does not modify the system — it only overrides or adds on top. DDPM is a Unity recipe (named `ddpm-recipe/` to distinguish it from the product). If Unity adds another product customization in the future, it gets its own sibling folder inside `BOO/design-systems/unity/`.

The folder path communicates the dependency relationship. A recipe cannot exist without its parent system.

### Core Products — Parallel Area
**Path:** `BOO/core-products/{product}/`

Not a layer in the design system inheritance chain. A dedicated top-level area for product-specific knowledge that is not a design system customization — screen layout contracts, product data, and product-specific patterns. Products here may reference a design system but their artifacts live independently.

---

## Agreed Folder Structure

```
BOO/                                    # The source of truth. Everything in here is authoritative.
│
├── global/                        # LAYER 1 — Universal constraints
│   ├── design-philosophy.md            # moved from unity/boo/
│   ├── design-rules.md
│   ├── accessibility-guides.md         # moved from unity/boo/04-accessibility.md
│   ├── responsive-guides.md            # New file — responsive design patterns
│   ├── principles-quick-check.yaml
│   ├── principles-quick-ref.yaml
│   │   
│   ├── assets/
│   │   └── icons-dds2/                 # Shared icon library (400+ SVG icons)
│   │       ├── icon-map.yaml           # Icon index
│   │       └── *.svg                   # Individual icon files
│   ├── component-selection/          # Universal methodology for selecting components
│   │   ├── 01-task-ontology.md         # moved from unity/component-selection/
│   │   └── 02-selection-decisions.md   # moved from unity/component-selection/
│   └── skills/
│       └── technical-validation/        # moved from BOO/skills/technical-validation/
│           └── skill.md
│
├── design-systems/                 # LAYER 2 — Design systems (renamed from systems/)
│   └── unity/                           # Dell Unity design system
│       │
│       ├── canonical/                   # Guidelines specific for Unity
│       │   ├── 00-orchestrator.yaml     # Files index - Not yet created
│       │   ├── 01-constitution.yaml     # Generation sequence
│       │   ├── tokens.yaml              # Wwill be replaced
│       │   ├── component-quick-ref.yaml # Will be replaced
│       │
│       ├── components/                  # Unity components information
│       │   ├── components-manifest.yaml # Semantic usage rules
│       │   ├── patterns-manifest.yaml   # Semantic usage rules
│       │   ├── html/                    # Components code in HTML
│       │   ├── tsx/                     # Components code in TypeScript
│       │   └── tokens.css               # Unity tokens for components
│       ├── layout-contract/             # Common layout templates
│       │
│       ├── recipes/               # LAYER 3 — Product Recipes
│       │   └── ddpm-recipe/          # Example of a recipe for DDPM product
│       │       ├── 00-orchestrator.yaml
│       │       ├── token-overrides.yaml # Overrides or adds tokens
│       │       ├── component-overrides.yaml # Overrides or adds components
│       │       ├── rules.md            # Overrides/adds design system or global rules
│       │       └── components/          # Unity overrides or add-ons
│       │           ├── components-manifest.yaml
│       │           ├── patterns-manifest.yaml
│       │           ├── html/
│       │           ├── tsx/
│       │           └── tokens.css
│
└── core-products/                       # Product knowledge — layout, contracts, data
    ├── ddpm/                            # DDPM product artifacts (parallel to recipe)
    │   ├── layout-contract/
    │   ├── screen-patterns/
    │   └── data/
    └── UUE/                             # Unity User Experience product
        ├── product-context.md
        ├── component-manifest.md
        ├── information-architecture.md
        ├── screen-references.md
        ├── onboarding-status.md
        ├── layouts/
        └── system-overrides/
```

---

## Key Decisions and Rationale

### `boo/` → `canonical/`
The subfolder inside each system was named `boo/`, the same word as the parent `BOO/` folder. Two different concepts sharing a name caused ambiguity. `canonical/` is more descriptive — it communicates that these are the authoritative, definitive files the agent reads before generating anything. The top-level `BOO/` folder name is unchanged; it refers to the whole knowledge layer (Book of Origins).

### `04-accessibility.md` moves to `global/`
Accessibility constraints are not Unity-specific. WCAG 2.2 AA and Microsoft Learn requirements apply universally. The file lives at the layer that owns it (`global/`), not at the layer that uses it. The orchestrator references it by its actual path at the step it's needed.

### `03-icon-map.yaml` and `icons/dds2/` move to `global/assets/icons/`
DDS2 is the shared icon library for Unity, the Dell Design System, Agora, and Dama. It does not belong inside any single system's folder. Both the raw SVG assets and the generated icon map live at `BOO/global/assets/icons/` — treated as a global shared asset, available to all systems.

### `grid-templates/` → `grids/`
The folder name `grid-templates/` was descriptive but verbose. `grids/` is shorter and consistent with how the rest of the global folder is named. Contents are unchanged.

### `systems/` → `design-systems/`
The folder name `systems/` was ambiguous — it could mean anything. `design-systems/` is explicit about what kind of systems live here. Removes any ambiguity when the repo grows.

### Component selection split: methodology global, manifests per-system
The component selection process has two parts:
- **Methodology** (`01-task-ontology.md`, `02-selection-decisions.md`) — universal, applies to all systems. Moved to `global/component-selection/`.
- **Manifests** (`components-manifest.yaml`, `patterns-manifest.yaml`) — system-specific. Each design system keeps its own inside `design-systems/{system}/components/`.

This allows DDS, Agora, and Dama to follow the same selection process while documenting their own components and patterns. Each system's `components/` folder also houses reference implementations (HTML, TSX) and component-specific token values.

### `core-products/` added at BOO root
A new top-level folder for product-specific artifacts that are not design system customizations: screen layout contracts, product data definitions, and screen patterns. Products in `core-products/` may reference a design system but their knowledge is product-owned, not system-owned. This is separate from the recipe folder (`design-systems/unity/ddpm-recipe/`) — the recipe is about how DDPM customizes Unity; `core-products/ddpm/` is about DDPM as a product.

### DDPM recipe lives at `unity/ddpm-recipe/`, product at `core-products/ddpm/`
The recipe (`ddpm-recipe/`) is a Unity customization — it does not exist independently of Unity. The product (`core-products/ddpm/`) is the actual application and its artifacts. Two separate concerns, two separate folders. Other Unity recipes in the future would be added as additional sibling folders inside `BOO/design-systems/unity/`.

### `products/` top-level folder was dropped
An earlier draft proposed `BOO/products/` as a top-level Layer 3 folder parallel to `BOO/systems/`. This was dropped because it implied product customizations are peers to design systems, which is incorrect. Recipes nest inside the system they extend.

---

## The Orchestrator Pattern

### Problem with current loading
The current agent instructions require reading all five canonical files before the generation sequence begins. This is a blunt approach — tokens and icons are not needed until Step 7, and accessibility is not needed until Step 8. Loading everything upfront is wasteful and does not reflect the actual dependency order of the generation sequence.

### What the orchestrator is
`00-orchestrator.yaml` is a new lightweight file at the top of each `canonical/` folder. It owns two things:
1. The generation sequence (the 9 steps)
2. Load directives — which file to read at which step

The `.windsurfrules` and `CLAUDE.md` entry points reference only the orchestrator. The canonical files become on-demand references, not upfront reads. The orchestrator is the cross-layer bridge — its load directives can point to files anywhere in the BOO tree.

### Load directive map for Unity

| Step | Action | File loaded |
|---|---|---|
| 1 | Identify Purpose | — |
| 2–5 | Framework, Nav, Grid, Overlays | `design-systems/unity/canonical/01-constitution.yaml` |
| 6 | Select Components | `design-systems/unity/canonical/05-component-quick-ref.yaml` |
| 7 | Apply Visual Values | `design-systems/unity/canonical/02-tokens.yaml` + `global/assets/icons/icon-map.yaml` |
| 8 | Acceptance Checklist | `global/accessibility.md` |
| 9 | Statement of Work | — |

### Load directive map for DDPM (extends Unity)
DDPM's orchestrator runs the same sequence but adds its override files at Steps 6 and 7:

| Step | File loaded |
|---|---|
| 2–5 | `design-systems/unity/canonical/01-constitution.yaml` |
| 6 | `design-systems/unity/canonical/05-component-quick-ref.yaml` + `design-systems/unity/ddpm-recipe/component-overrides.yaml` |
| 7 | `design-systems/unity/canonical/02-tokens.yaml` + `design-systems/unity/ddpm-recipe/token-overrides.yaml` + `global/assets/icons/icon-map.yaml` |
| 8 | `global/accessibility.md` |

Unity canonical files are never touched by the DDPM recipe. The overrides stack on top at the right step.

---

## What Changes From Current State

| Item | Current path | New path |
|---|---|---|
| Unity canonical files | `BOO/unity/boo/` | `BOO/design-systems/unity/canonical/` |
| Design philosophy | `BOO/unity/boo/design-philosophy.md` | `BOO/global/design-philosophy.md` |
| Accessibility | `BOO/unity/boo/04-accessibility.md` | `BOO/global/accessibility-guides.md` |
| Icon map | `BOO/unity/boo/03-icon-map.yaml` | `BOO/global/assets/icons-dds2/icon-map.yaml` |
| Icon assets | `BOO/icons/dds2/` | `BOO/global/assets/icons-dds2/` (400+ SVG files) |
| Tokens | `BOO/unity/boo/02-tokens.yaml` | `BOO/design-systems/unity/components/tokens.css` |
| Component quick ref | `BOO/unity/boo/05-component-quick-ref.yaml` | `BOO/design-systems/unity/components/` (integrated) |
| Responsive guides | does not exist yet | `BOO/global/responsive-guides.md` |
| Technical validation skill | `BOO/skills/technical-validation/` | `BOO/global/skills/technical-validation/` |
| Grid templates | `BOO/12 columns grid layout/` | `BOO/global/grids/` |
| Global principles | `BOO/design-rule.md`, `BOO/principles-*.yaml` | `BOO/global/` |
| Component selection (methodology) | `BOO/unity/component-selection/01-02` | `BOO/global/component-selection/` |
| Component manifests | `BOO/unity/component-selection/03-04` | `BOO/design-systems/unity/components/` |
| Layout contract | `BOO/unity/layout-contract/` | `BOO/design-systems/unity/layout-contract/` |
| DDPM recipe | does not exist yet | `BOO/design-systems/unity/recipes/ddpm-recipe/` |
| DDPM product artifacts | does not exist yet | `BOO/core-products/ddpm/` |
| Orchestrator | does not exist yet | `BOO/design-systems/unity/canonical/00-orchestrator.yaml` |

---

## Scaling Pattern

When a new design system is added, the pattern is:

```
BOO/design-systems/{system}/
├── canonical/     ← authoritative files for this system
└── {recipe}/      ← one folder per product that extends this system
```

When a new recipe is added to an existing system:

```
BOO/design-systems/unity/
├── canonical/
├── ddpm-recipe/
└── {new-recipe}/  ← add here, touch nothing else
```

When a new product is added to core-products:

```
BOO/core-products/
├── ddpm/
└── {new-product}/  ← layout contracts, screen patterns, data
```
