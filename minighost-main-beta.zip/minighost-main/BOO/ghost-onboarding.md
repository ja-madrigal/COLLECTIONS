# ghost-onboarding.md

> This file is triggered when a designer begins working on a product that does not yet have a folder in `BOO/core-products/`. Run the steps below in order. Do not begin design work until onboarding is complete or explicitly deferred by the designer.

---

## Step 1 — Design System

Ask the designer which design system this product uses.

If the system is one Ghost houses in BOO (e.g. Unity), ask:

> "Does this product follow Unity as-is, or should I expect product-specific overrides when I review your files?"

The designer does not need to know what the overrides are — a yes or no is enough. You will identify the actual overrides yourself during file ingestion in Step 3. This question is asked first so you know to look for them when interpreting files.

---

## Step 2 — File Collection

Ask the designer to share Figma files in the following order. Collect each before moving to the next.

1. **Component library** — the Figma library file for this product
2. **Screen references** — existing designed screens or flows
3. **IA artifact** — a FigJam, site map, or any document representing the product's information architecture (optional)

For each file received, confirm receipt and state what you will extract from it.

If no IA artifact is provided, note:

> "No IA artifact provided — I'll derive the information architecture from your screen files and flag my confidence level."

---

## Step 3 — File Ingestion and Inference

Ingest all provided files. During ingestion:

**Cross-reference against Unity baseline**
Compare the product's component library and screen files against the Unity token set and component specs stored in BOO. Log every discrepancy — values that differ, components that are structurally different, and components with no Unity equivalent.

**Build an inference map**
For each of the following, assign a confidence level (confirmed / inferred / unknown):

- Product description and purpose
- User type
- Platform and surface constraints (desktop, mobile, web, embedded)
- Key workflows and user journeys
- Navigation model and information architecture
- Interaction patterns

Do not treat inferences as ground truth. Surface them for confirmation in Step 4.

---

## Step 4 — Override Classification

Present every discrepancy found between the product files and the Unity baseline. For each one, ask the designer to classify it:

- **Intentional** — a deliberate product-specific override. Document it in `system-overrides/`.
- **Design error** — flag it for correction. Do not document as an override.
- **Unsure** — log it in `onboarding-status.md` as an open question. Does not block onboarding.

Do not write anything to the overrides folder until the designer has classified it.

---

## Step 5 — Confirmation and Probabilistic Q&A

Present your inferences from Step 3 for the designer to confirm or correct. Lead with the highest-confidence items.

Example format:
> "Based on your screens, here's what I'm reading — let me know what to correct:
> - Product: B2B internal tool for operations teams
> - Platform: Desktop web
> - Primary user: IT administrator
> - Navigation model: Side nav with hub-and-spoke structure"

Then ask only about what you genuinely cannot determine from the files. Do not ask a fixed set of questions — generate only the gaps. Typical unknowns include:

- Current design stage (exploration / active detailed design / pre-handoff)
- Brand tier or product line
- Existing user research (ask if any exists and if the designer can share it)
- Technical constraints or non-negotiables

Where possible, offer structured choices rather than open fields.

Items the designer cannot answer yet do not block onboarding. Log them as open gaps in `onboarding-status.md`.

---

## Step 6 — Output Generation

Notify the designer before beginning generation:

> "Onboarding complete. Here's what I'm building now:
> - Product context file
> - Component manifest
> - Screen references summary
> - Information architecture file
> - [X] layout templates for the [X] distinct page types found in your screens
> - [X] coded HTML/CSS layout files
> - [X] override component specs and coded components
> This may take a few minutes."

Then generate and write the following to `BOO/core-products/[product-name]/`:

**Context files**
- `product-context.md` — product description, user type, platform, design stage, brand tier, constraints, and any user research notes
- `component-manifest.md` — full inventory of components: what exists, what's from Unity, what's custom or overridden
- `screen-references.md` — summary of existing screens and design patterns derived from Figma files
- `information-architecture.md` — navigation model, section hierarchy, key entry points, primary user paths, and confidence level if derived rather than sourced from an artifact
- `onboarding-status.md` — what's complete, what's flagged for correction, open gaps to return to

**Layouts** (`layouts/`)
- One `[page-type]-layout.md` per distinct page type found in the screen files — layout spec and structural reasoning
- One `[page-type]-layout.html` per page type — coded HTML/CSS layout template

**System overrides** (`system-overrides/`)
- `overrides-summary.md` — index of all intentional overrides with rationale, for quick agent reference
- `components/[component-name].md` per override — what changed from the Unity baseline and why
- `coded-components/[component-name].html` per override — HTML/CSS implementation for use in agent-built interfaces

On completion, confirm what was built, note any open gaps, and remind the designer:

> "You can run a refresh at any time if your product context changes — design system updates, scope shifts, or new screen files. Just say 'refresh [product name]'."

---

## Refresh Behavior

When the designer runs a refresh command:

1. Ask what has changed — design system, screens, scope, or something else
2. Re-ingest only the relevant files
3. Re-run override classification for any new discrepancies
4. Update affected files in the product folder
5. Confirm what was updated and flag anything that may now be outdated

---

## Rules

- Do not begin design work before onboarding is complete for a new product
- Do not auto-document discrepancies as overrides — designer classification is required
- Do not treat inferred context as confirmed — surface it and ask
- Do not ask questions the files already answered
- Gaps and unknowns do not block onboarding — log them and proceed
- Always default to existing library components before designing anything new
