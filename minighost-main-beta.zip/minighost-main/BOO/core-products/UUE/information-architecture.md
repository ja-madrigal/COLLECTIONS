# UUE — Information Architecture

## Source

FigJam: UUE-Information-Architecture (`onxJxD7hMuLKf0Qd0C9keo`)
Section reviewed: `IA Consumer` (node `4401:8913`)
Confidence: **Confirmed** — sourced directly from IA artifact

---

## Top-Level Structure

The app is divided into four top-level sections, displayed as the app's navigation system:

```
UUE
├── Onboarding          (isolated flow — no app nav during this state)
├── Title Bar           (persistent app navigation — displayed in masthead)
│   ├── My Account
│   ├── Support
│   ├── About
│   └── Search
└── Main                (primary content area — navigated from Home)
    └── Home
        ├── Display
        ├── Battery
        └── Presence Detection
```

---

## Section Detail

### Onboarding
- **Trigger:** First launch / new device
- **Steps confirmed:**
  1. Onboarding flow (welcome / setup)
  2. Setup / explore basic settings
- **Nav rule:** No persistent app navigation during onboarding (constitution §3)
- **Confidence:** Confirmed from IA

---

### Title Bar (App Navigation)

Persistent navigation displayed in the app masthead. Four items:

#### My Account
- **Preferences**
  - Notifications
  - Telemetry Consent
- **Applications**
  - Purchased Applications
  - Pre-installed Applications

#### Support
- Helpful links
  - Chat
  - Give Feedback (survey)
  - Link to User Guide
  - Scan PC
  - Launch Support Assist

#### About
- App Version
- Important Links (license agreement, privacy, etc.)

#### Search
- Global search (no sub-items in IA)

---

### Main (Content Area — accessed from Home)

Home is the default landing page of the Main section. From Home, users navigate into feature areas.

#### Home
- **Device Info**
  - Register my device
  - Warranty Info
  - Link to support
- **Links to settings** (shortcuts)
  - Display
  - Power & Battery
  - Presence Detection
- **Essentials Section** (featured cards)

#### Display
- Dolby Vision
- Color Profiles
- Application Color

#### Battery
- Battery Details
  - Thermal Management
    - Dynamic Charge
    - Intelligent Battery Extender

#### Presence Detection
- Onlooker Detection
- Look Away Dim
- Walk Away Lock
- Wake on Approach

---

## Navigation Model

- **App navigation type:** Title Bar — 4 horizontal top-level items in masthead
- **Content navigation type:** Hub-and-spoke — Home is the hub; Display, Battery, and Presence Detection are spokes
- **Depth:** Maximum 4 levels (e.g., Main → Home → Battery → Battery Details → Thermal Management → Dynamic Charge)
- **Return path:** Back navigation expected at every depth below Home
- **Onboarding:** Isolated — exits to Home on completion

---

## Key User Paths

1. **First-time setup:** Launch → Onboarding flow → Setup basic settings → Home
2. **Battery check:** Home → Battery card → Battery Details → Thermal Management or Dynamic Charge
3. **Display adjustment:** Home → Display card → Dolby Vision / Color Profiles
4. **Privacy feature:** Home → Presence Detection → Onlooker Detection / Walk Away Lock
5. **Support:** Title Bar → Support → Chat or Scan PC or Launch Support Assist
6. **Device info / warranty:** Home → Device Info → Warranty Info or Register my device
7. **App management:** Title Bar → My Account → Applications → Purchased / Pre-installed

---

## IA Legend (from FigJam)

| Color | Meaning |
|---|---|
| Blue (filled) | Top-level Category |
| Light blue / white | Sub-category |
| Gray / white | Current DO/Titan feature |
| Light gray | Upcoming DO/Titan feature |
| Purple-tinted | Titan-only feature |

Note: "DO" and "Titan" are internal platform/configuration names. Current screens appear to represent the "DO" (Dell Optimizer?) baseline. Titan-only features are not yet in scope for active design.

---

## Open Questions

- Is "Main" the name for the content area or an internal IA label only?
- Are Display, Battery, and Presence Detection also accessible from the Title Bar, or only from Home?
- What is the relationship between "Links to settings" shortcuts on Home and the full feature pages?
- Are there additional top-level sections planned beyond the 4 Title Bar items?
