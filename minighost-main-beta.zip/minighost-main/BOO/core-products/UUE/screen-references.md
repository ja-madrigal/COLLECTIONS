# UUE — Screen References

## Source

Figma file: UUE-Main (`aCnyUf72lFV79Mi8D4n6DE`)
Page reviewed: `✅Home Page 4/2` (node `11:6`)
Section: `MyDell and DO Home Page Designs` (node `19:4131`)

---

## Screens Inventoried

### 1. Home Page — MyDell V2 (node `19:1155`)

**Frame size:** 1920×1080 (full-bleed desktop)
**Framework match:** `hero_feature_rail_homepage` — device identity left, capability cards right
**Mode:** Light

**Layout structure:**
- Full-bleed Windows 11 background image as atmospheric backdrop
- App window at ~1132×782px centered on screen, with atmospheric elliptical gradient overlays inside
- Custom masthead / title bar: 64px height, contains search bar (icon + "Search" placeholder + Alexa icon), notification icon button, window controls (maximize, minimize, close)
- **Left column** (~400px): Device identity block — "Welcome to your" / "XPS 15" (large hero heading) / Service Tag / Primary button / Secondary button + device image placeholder
- **Right column** (~640px):
  - Top row: 2 feature destination cards side-by-side (287×109px each) — Applications card (grid icon + "Applications" label + pop-up-arrow) and My Device card (laptop icon + label + chevron)
  - Second row: 1 feature destination card (287×109px) — Power card (power cord icon + label + chevron)
  - "Explore" section label below
  - Explore tile grid: 2 vertical capability cards (187×186px each, round icon container + title + description + CTA + chevron)
  - Explore tiles confirmed: Rate/Recommend (thumb-up icon), My Device specs (laptop icon)

**Key patterns:**
- Feature destination cards use a rounded-rectangle surface with `border-radius: 13px` (card_special token), light fill, icon + label + chevron layout
- Explore cards use a circular icon background (46×46px, 50% radius) with a filled colored circle, 24px icon inside
- Ghost/tertiary CTA inside explore cards is paired with a chevron-right icon to the right
- Masthead search bar is inline — not a separate overlay or modal
- Window chrome controls are custom (not native Windows) — right-aligned in masthead

---

### 2. Home Page — Variant B (node `28344:70701` area)

**Frame size:** 1132×782px (windowed, no full-bleed)
**Framework match:** `hero_feature_rail_homepage`
**Mode:** Light

**Differences from MyDell V2:**
- No Windows 11 background — app is the full surface
- Left column: device image placeholder is larger and more prominent (342×228px rectangle)
- Has both Primary and Secondary buttons side-by-side below device identity
- Feature destination cards: only 2 cards (My Device + Battery/Power) — 2-up layout, not 3
- Essentials section replaces "Explore" — "Essentials" label + 2 vertical cards (187×216px, slightly taller than V2)
  - Essentials card 1: battery-charge icon, "Battery" title, description text, "Learn more" button + chevron
  - Essentials card 2: device-laptop icon, "My Device" title, description text, "Learn more" button + chevron

**Key differences from V2:**
- Essentials cards are taller (216px vs 186px) and include a description text row between title and CTA
- Only 2 destination cards in the top row (not 3)
- Essentials section feels more informational (description + CTA) vs V2 Explore tiles (icon-only + title + CTA)

---

## Confirmed Design Patterns

### Pattern: Feature Destination Card
- **Size:** 287×109px
- **Radius:** 13px (card_special)
- **Content:** 24px icon (left) + label text (body) + 16px chevron-right (right), left-padded ~20px
- **Background:** Light fill (white or near-white), rounded rectangle surface
- **Use:** Quick navigation from Home to a major feature section (Battery, My Device, Applications)
- **Chevron variant:** Uses `dds2_pop-up-arrow-corner` when the destination opens externally, `dds2_chevron-right` for internal nav

### Pattern: Explore / Essentials Card (Vertical Capability Tile)
- **Size:** 187×186–216px
- **Radius:** 13px (card_special)
- **Content:** 46×46px circular icon container (50% radius, brand-tinted fill) + 24px icon inside → title text → (optional description) → ghost/tertiary CTA button + 11px chevron
- **Background:** Rounded rectangle, light fill
- **Use:** Capability discovery or feature entry on Home

### Pattern: Circular Icon Container
- **Size:** 46×46px, border-radius 50%
- **Fill:** Brand-tinted (appears to be `background-container-accent-base` or similar blue)
- **Icon:** 22–24px DDS2 icon, white (`foreground-on-fill`)
- **Use:** Explore/Essentials cards only — not used in destination cards or nav

### Pattern: App Masthead
- **Height:** 64px
- **Left zone:** App logo area (not confirmed — may be logo or empty)
- **Center zone:** Search bar with search icon + placeholder text + Alexa icon (360px wide container)
- **Right zone:** Notification icon button + window controls (restore/maximize, minimize, close)
- **Bottom border:** 1px divider line (`border-divider`)
- **Window controls:** Custom non-native icons (DDS1 naming — flagged)

### Pattern: Device Identity Block
- **Content stack:** "Welcome to your" (body/subtitle) → Device model name (large hero heading, 40–48px, weight 300) → Service Tag (caption/body_3) → Primary button + Secondary button
- **Alignment:** Left-aligned, ~100–110px from left edge of app window

---

## Screens Not Yet Designed (per IA, absent from file)

- Onboarding flow (Step 1 and Step 2)
- My Account > Preferences (Notifications, Telemetry Consent)
- My Account > Applications (Purchased, Pre-installed)
- Support (all sub-pages)
- About
- Display settings (all sub-pages)
- Battery settings (all sub-pages)
- Presence Detection settings (all sub-pages)
- Device Info
- Search results

---

## Confidence Summary

| Element | Confidence |
|---|---|
| Home page layout | Confirmed |
| Feature destination card pattern | Confirmed |
| Explore/Essentials card pattern | Confirmed |
| App masthead height and zone structure | Confirmed |
| Device identity block pattern | Confirmed |
| Frame size (windowed: 1132×782px) | Confirmed |
| Light mode as primary | Confirmed |
| Dark mode existence | Inferred — unconfirmed |
| All other page types | Unknown — not yet designed |
