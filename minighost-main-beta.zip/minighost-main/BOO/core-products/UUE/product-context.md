# UUE — Product Context

## Product Description

**Full name:** Unified User Experience (UUE)
**Short name:** UUE
**Working title in file:** "MyDell" (legacy naming visible in screen frames)

UUE is a Dell first-party desktop application for consumer and commercial laptop users. It is the primary owner/management software shipped with Dell devices — the digital companion to the physical product. It surfaces device identity, system status, key features (battery, display, presence detection), and entry points to Dell support services.

---

## User Type

- **Primary:** Individual end-user of a Dell laptop (consumer or SMB)
- **Context:** User did not open this software to spend time with it — they arrive with a specific intent (check battery, find warranty info, configure a feature, contact support)
- **Technical level:** General consumer to moderately technical; not an IT administrator
- **Device context:** Single device (the user's own machine), not fleet management

---

## Platform and Surface Constraints

- **Platform:** Windows desktop application (Electron or native Windows)
- **Frame size:** 1132×782px windowed app (confirmed from screen frames); also designed at 1920×1080 full-bleed
- **Surface:** Desktop app within a Windows 11 environment — Windows 11 BG visible as the backdrop layer
- **Rendering:** App runs inside a windowed chrome with custom window controls (minimize, maximize/restore, close)
- **Confidence:** Confirmed

---

## Design Stage

- **Status:** In Progress (confirmed on cover page)
- **Stage:** Active detailed design — screens exist and are being refined, not pre-handoff
- **Confidence:** Confirmed

---

## Brand Tier / Product Line

- Dell consumer / prosumer (XPS referenced as example device)
- Unity design system, as-is, no product-specific overrides declared

---

## Key Workflows and User Journeys

Derived from IA artifact and screen files:

1. **First-run onboarding** — device setup, explore basic settings (2 steps minimum)
2. **Home / landing** — welcome by device name + service tag, quick-access essentials cards (Battery, My Device), explore capability tiles
3. **Account management (Title Bar)** — My Account dropdown with Preferences and Applications sub-sections
4. **Support access (Title Bar)** — Helpful links, Chat, Give Feedback, Link to User Guide, Scan PC, Launch Support Assist
5. **About (Title Bar)** — App Version, Important Links (license, privacy)
6. **Search (Title Bar)** — global search
7. **Feature deep-dives (Main):**
   - Display → Dolby Vision → Color Profiles → Application Color
   - Battery → Battery Details → Thermal Management → Dynamic Charge → Intelligent Battery Extender
   - Presence Detection → Onlooker Detection → Look Away Dim → Walk Away Lock → Wake on Approach

---

## Navigation Model

- **App-level navigation:** Title bar with 4 top-level items — My Account, Support, About, Search — presented as a horizontal bar inside the app masthead
- **Main content navigation:** Hub-and-spoke from Home — users tap feature cards (Display, Battery, Presence Detection) to drill into settings
- **Home** also contains: Device Info, Links to settings (shortcuts), Essentials Section
- **Onboarding** is a separate, isolated flow — no persistent app nav present during onboarding
- **Confidence:** Confirmed from IA

---

## Constraints and Non-Negotiables

- Windows 11 desktop environment — windowed app
- Custom window chrome (minimize, maximize, close) — not native OS controls
- Unity design system as-is
- Alexa integration present in masthead search bar
- Both light and dark modes implied (screens show light mode; dark not yet confirmed in screens)

---

## User Research Notes

- Researcher: Brenda Berkelaar (named on cover)
- No research files shared during onboarding — existence confirmed, content not available
- Open gap: research findings not yet incorporated into context

---

## Open Gaps

- No dark mode screens provided — dark mode assumed but unconfirmed
- Research findings not reviewed
- Exact app frame sizes across all page types not confirmed (1132×782 seen on home; other pages may differ)
- Technical stack (Electron vs native Windows) not confirmed
