# UUE Override — Masthead Icon Set (D-UUE-01)

## Override ID
D-UUE-01

## Classification
**Intentional** — confirmed by designer 2026-07-02

## What Changed from Unity Baseline

The Unity baseline specifies DDS2 icon names throughout (`dds2_*` prefix). UUE's masthead uses four DDS1 icon names instead. These are locked in the product's icon delivery pipeline and will not be migrated.

| Role | UUE Icon Name (use this) | Unity Baseline Equivalent | Size in Masthead |
|---|---|---|---|
| Notification bell | `dds_alarm-bell` | `dds2_alarm-bell` (or equivalent) | 12×12px |
| Window minimize | `dds_minus-minimize` | `dds2_minus-minimize` (or equivalent) | 12×12px |
| Window close | `dds_close-x` | `dds2_close-x` (or equivalent) | 10×10px |
| Window maximize/restore | `arrow_Right_Rest` | `dds2_arrow-right` or `dds2_maximize` | 16×16px |

## Scope

This override applies **only to the masthead** — specifically:
- The notification icon button (bell + badge dot)
- The three window chrome control buttons (minimize, maximize/restore, close)

All other icon usage in UUE screens must use DDS2 names (`dds2_*`).

## Agent Rule

When generating UUE masthead code or referencing masthead icons:
- Use the DDS1 names above
- Do NOT substitute DDS2 equivalents for these four icons
- All other icons in the product use `dds2_*` naming

## Rationale

These icon names are tied to the existing icon sprite delivery for UUE and cannot be changed without a broader pipeline migration. This is a deliberate product-specific hold — not a gap or error.

## Impact on Future Screens

- All future masthead implementations carry these four icon references
- This does not affect any other icon in the product
- If the pipeline migrates to DDS2 in future, remove this override and update icon names to `dds2_*` equivalents
