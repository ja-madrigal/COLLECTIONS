# UUE — System Overrides Summary

## Status
Classification complete — 2026-07-02.
1 intentional override confirmed. 2 design errors flagged for correction. 1 canonical frame confirmed.

---

## Classification Results

| ID | Item | Classification | Action |
|---|---|---|---|
| D-UUE-01 | Legacy DDS1 icons in masthead | **Intentional override** | Documented below — use DDS1 icon names for masthead window chrome and notification bell |
| D-UUE-02 | Chevron at 11px in essentials card CTAs | **Design error** | Correct to 16px (`icon_size.sm`) in all future screens and any screen revisions |
| D-UUE-03 | Custom window chrome controls | **Design error** | Use Unity window chrome component in future screens |
| D-UUE-04 | Dual frame sizes | **Canonical frame: 1132×782px** | All future screens target 1132×782px. The 1920×1080 variant is a legacy/exploration frame — do not use going forward |

---

## Confirmed Overrides

| ID | Component | File | What Changed | Rationale |
|---|---|---|---|---|
| D-UUE-01 | Masthead icon set | `components/masthead-icons.md` | DDS1 icon names used for bell, minimize, close, maximize — not DDS2 equivalents | Intentional — these icon names are locked in the product's icon pipeline and will not be migrated at this time |
