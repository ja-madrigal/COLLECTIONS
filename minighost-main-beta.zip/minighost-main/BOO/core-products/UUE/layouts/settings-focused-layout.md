# UUE — Settings (Focused) Layout Spec

## Framework
`settings_focused`

## Purpose
Single feature area settings — Battery, Display, or Presence Detection. User drills into one feature from Home and configures related controls.

## Frame
1132×782px (windowed app — canonical size)

---

## Grid Model
`settings_focused` — large back/title heading + stacked expandable sections. No category rail (category is already chosen).

| Region | Width | Notes |
|---|---|---|
| Content area | Full width minus 16px inset each side | 1100px usable |
| Back + title zone | Full width | 64px masthead + back arrow + page title |
| Settings surface | Full width minus 32px (16px each side) | Stacked content-layer panels |

---

## Layer Structure (Max 3)

| Layer | Role | Token |
|---|---|---|
| App background | Atmospheric tinted backdrop | `--background-app` + radial gradient |
| Layer 1 — Settings panel | Primary settings surface | `--background-container-accent-subtle`, `radius.surface_primary` (16px) |
| Layer 2 — Feature group | Groups related controls | `--background-container-accent-base`, `radius.surface_secondary` (8px) |
| Layer 3 — Control row | Individual toggle/dropdown row | `--background-surface`, `radius.button_compact` (2px) |

---

## Zones

### Masthead (64px)
Same as Home — search, notification, window controls.
Bottom: 1px `--border-divider`.

### Page Header
- Back arrow (`dds2_arrow-left`, 16px, `icon_size.sm`) — `spacing.relationship.closely_coupled` (8px) to page title
- Page title: feature name (e.g., "Battery") — `--type-header_1` (48px, weight 300), `--foreground-default`
- Gap below header to first panel: `spacing.relationship.major_transition` (24px)

### Content Surface
- One or more stacked Layer 1 panels (`--background-container-accent-subtle`, radius 16px, `--card-shadow`)
- Internal panel padding: `spacing.relationship.standard` (16px) all sides
- Gap between panels: `spacing.relationship.major_transition` (24px)

### Feature Group (Layer 2, inside a panel)
- Group heading: `--type-header_5` (20px), `--foreground-default`
- Gap heading to controls: `spacing.relationship.closely_coupled` (8px)
- Background: `--background-container-accent-base`, radius 8px
- Padding: `spacing.relationship.standard` (16px)

### Control Row (Layer 3)
- Toggle row: icon (24px) + label (`--type-subtitle_2`) + secondary text (`--type-body_3`) + toggle control, right-aligned
- Dropdown row: icon + label + dropdown, right-aligned
- Row height: 56–64px
- Gap between rows: `spacing.relationship.closely_coupled` (8px)
- Separator between rows: 1px `--border-divider`

---

## Spacing Summary

| Relationship | Token | Value |
|---|---|---|
| Back arrow to page title | `closely_coupled` | 8px |
| Page title to first panel | `major_transition` | 24px |
| Panel internal padding | `standard` | 16px |
| Between rows inside panel | `closely_coupled` | 8px |
| Between panels | `major_transition` | 24px |
| Group heading to controls | `closely_coupled` | 8px |
| Icon to label in row | `closely_coupled` | 8px |

---

## Typography on This Screen

| Element | Token | Size | Weight |
|---|---|---|---|
| Page title | `--type-header_1` | 48px | 300 |
| Group/section heading | `--type-header_5` | 20px | 400 |
| Control label | `--type-subtitle_2` | 16px | 500 |
| Control description | `--type-body_3` | 14px | 400 |
| Button labels | `--type-button_2` | 14px | 500 |

Type tiers: `header_1`, `header_5`, `subtitle_2`/`body_3`, `button_2` — within budget.

---

## Components Used

- Masthead (composed)
- Back navigation (icon + title)
- Content Layer / Expandable (stacked panels)
- Toggle (on/off settings)
- Dropdown (mode selection)
- Slider (live adjustment — if present in Display)
- Alert (status messages — battery health, warranty)
- Primary / Secondary Button (where applicable)

---

## Structural Reasoning

Settings pages follow `settings_focused` because:
1. Only one feature area is active at a time (Battery OR Display OR Presence Detection)
2. Controls are grouped under a single named heading — not multi-category
3. No category rail needed — category was chosen on Home
4. Constitution: "Single feature settings with related grouped controls"
5. Not `settings_global` (which requires a persistent category rail for multi-category)
