# UUE — Home Page Layout Spec

## Framework
`hero_feature_rail_homepage`

## Purpose
Device identity + entry point to feature areas. User lands here after onboarding or on every return visit.

## Frame
1132×782px (windowed app — canonical size)

---

## Grid Model
`homepage_derived` — two primary regions, not a forced 3-column grid.

| Region | Width | Notes |
|---|---|---|
| Left column (identity) | ~420px | Device image + welcome text + service tag + actions |
| Right column (features) | ~648px | Feature destination cards (top) + Essentials/Explore cards (below) |
| Horizontal gap between columns | ~24px (`major_transition`) | Section boundary |
| Content inset from app edge | 62–110px left, 16px right | Derived from screens |

---

## Layer Structure (Max 3)

| Layer | Role | Token |
|---|---|---|
| App background | Atmospheric tinted backdrop | `--background-app` + radial gradient overlays |
| Layer 1 — App window | Windowed chrome surface | `--background-container-accent-subtle` at 60% with backdrop blur |
| Layer 2 — Feature cards | Destination and explore cards | `--background-surface` (white, rounded) |
| Layer 3 — Icon containers | Circular icon bg on explore tiles | `--background-container-accent-base` |

---

## Zones

### Masthead (64px)
- Left: Logo or app identity (to confirm)
- Center: Search bar (search icon + placeholder + Alexa icon) — 360px wide
- Right: Notification icon button + window controls (restore, minimize, close)
- Bottom: 1px `--border-divider`

### Left Column — Device Identity
- Top: "Welcome to your" — `--type-body_2`, `--foreground-neutral`
- Hero: Device model name — `--type-header_2` (40px, weight 300), `--foreground-default`
- Sub: Service tag — `--type-caption`, `--foreground-neutral-subtle`
- Device image: placeholder rectangle, centered in column
- Actions: Primary button + Secondary button, left-aligned, `spacing.relationship.action_group` (10px) between

### Right Column — Feature Destination Cards
- 2-column grid of 287×109px cards
- Gap between cards: `spacing.relationship.closely_coupled` (8px)
- Each card: icon (24px, `--foreground-default`) + label (`--type-subtitle_2`) + chevron-right (16px) — all left-padded 20px

### Right Column — Essentials Section
- Section label: "Essentials" — `--type-header_5` (20px), `--foreground-default`
- Below label: `spacing.relationship.closely_coupled` (8px) to card grid
- 2–3 vertical capability cards (187×186–216px)
- Card gap: 12–16px horizontal
- Each card: 46px circular icon container + title (`--type-subtitle_2`) + description (`--type-body_3`) + ghost/tertiary CTA + chevron (11px — flagged; should be 16px per icon rules)

---

## Spacing Summary

| Relationship | Token | Value |
|---|---|---|
| Masthead height | fixed | 64px |
| Masthead bottom border | `--border-divider` | 1px |
| Column-to-column gap | `major_transition` | 24px |
| Content top inset (below masthead) | `standard` | 16px |
| Card-to-card (destination cards) | `closely_coupled` | 8px |
| Section label to card grid | `closely_coupled` | 8px |
| Section-to-section (destination to essentials) | `major_transition` | 24px |
| Card internal padding | `standard` | 16–20px |
| Icon to label gap | `closely_coupled` | 8px |

---

## Typography on This Screen

| Element | Token | Size | Weight |
|---|---|---|---|
| Device model (hero) | `--type-header_2` | 40px | 300 |
| Welcome text | `--type-body_2` | 16px | 400 |
| Service tag | `--type-caption` | 12px | 400 |
| Section label ("Essentials") | `--type-header_5` | 20px | 400 |
| Card item name | `--type-subtitle_2` | 16px | 500 |
| Card description | `--type-body_3` | 14px | 400 |
| Button labels | `--type-button_2` | 14px | 500 |

Type tiers used: `header_2`, `header_5`, `body_2`/`subtitle_2`, `body_3`, `caption`, `button_2` — within budget (hero + section + body).

---

## Components Used

- Primary Button (1 per screen, left column)
- Secondary Button (1, left column, beside primary)
- Tertiary/Ghost Button (inside essentials cards)
- Feature Destination Card (2–3, composed from Unity primitives)
- Essentials Card / Explore Tile (2–3, composed)
- Masthead (composed)
- Window chrome controls (custom)

---

## Structural Reasoning

Home follows `hero_feature_rail_homepage` because:
1. There is one central subject (the user's specific device)
2. From that subject, the user navigates into multiple feature areas
3. The left column anchors device identity; the right provides direct feature access
4. This is not a multi-device status scan (→ not `status_dashboard`)
5. This is not onboarding (→ not `onboarding`)
6. This is not a single-feature settings page (→ not `settings_focused`)
