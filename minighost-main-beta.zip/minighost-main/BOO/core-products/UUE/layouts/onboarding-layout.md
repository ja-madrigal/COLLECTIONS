# UUE — Onboarding Layout Spec

## Framework
`onboarding`

## Purpose
Guided first-run experience. Two confirmed steps: (1) Onboarding flow / welcome, (2) Setup / explore basic settings.

## Frame
1132×782px (windowed app)

---

## Grid Model
`onboarding` — two columns, left narrative + right contextual visual. No persistent app nav.

| Region | Width | Notes |
|---|---|---|
| Left column (narrative) | ~476px | Progress + eyebrow + heading + paragraph + actions |
| Right column (visual) | ~580px | Contextual illustration or device image |
| Left alignment inset | 76px | `guided_narrative` spacing token |
| Frame | 1132×782px | |

---

## Layer Structure (Max 2 — onboarding rule)

| Layer | Role | Token |
|---|---|---|
| Background | Atmospheric backdrop | `--background-app` + radial gradient |
| Layer 1 — Content surface | Onboarding card or full-bleed left panel | `--background-container-accent-subtle` or transparent over backdrop |

No nav rail. No masthead app navigation. Window chrome controls (close/minimize only — no maximize during onboarding) may be present.

---

## Zones

### Progress Indicator
- Top: ~124px from frame top
- Step dots or progress bar — position: left column, aligned to 76px left inset
- Gap below progress to narrative: `spacing.relationship.guided_narrative` (76px)

### Left Column — Narrative
- Eyebrow (optional): `--type-overline` (11px, uppercase, 0.08em tracking), `--foreground-neutral-subtle`
- Heading: `--type-header_1` or `--type-display_2` (48–64px, weight 300), `--foreground-default`
- Body paragraph: `--type-body_2` (16px, weight 400), `--foreground-neutral`, max-width ~380px
- Gap eyebrow to heading: `spacing.relationship.closely_coupled` (8px)
- Gap heading to paragraph: `spacing.relationship.standard` (16px)

### Action Row (left column, anchored to bottom or below body)
- Primary button: "Next" or "Get started"
- Secondary/tertiary: "Skip"
- Gap within action group: `spacing.relationship.action_group` (10px)
- Left alignment: 76px from left edge (same as narrative)
- Back arrow (after step 1 only): `dds2_arrow-left` (16px), positioned left of actions or as a separate row above

### Right Column — Visual
- Contextual device image, illustration, or feature preview
- Whitespace-heavy — do not crowd
- No interactive elements in right column

---

## Spacing Summary

| Relationship | Token | Value |
|---|---|---|
| Left inset | `guided_narrative` | 76px |
| Progress to narrative | `guided_narrative` | 76px |
| Eyebrow to heading | `closely_coupled` | 8px |
| Heading to paragraph | `standard` | 16px |
| Paragraph to actions | `major_transition` | 24px |
| Between action buttons | `action_group` | 10px |

---

## Typography on This Screen

| Element | Token | Size | Weight |
|---|---|---|---|
| Eyebrow (optional) | `--type-overline` | 11px | 500, uppercase |
| Step heading | `--type-header_1` | 48px | 300 |
| Body paragraph | `--type-body_2` | 16px | 400 |
| Button labels | `--type-button_2` | 14px | 500 |

Type tiers: `header_1`, `body_2`, `button_2` — within budget.

---

## Components Used

- Progress indicator (dots or bar — compose from Unity primitives)
- Primary Button ("Next" / "Get started")
- Secondary/Tertiary Button ("Skip")
- Back arrow icon (step 2+)
- Device image / illustration placeholder

---

## Structural Reasoning

Onboarding follows `onboarding` framework because:
1. User advances step-by-step — this is a linear guided progression
2. No persistent app navigation (constitution hard rule for onboarding)
3. Content is low-density and editorial — `guided_narrative` spacing applies
4. Constitution: "Two columns. Left: progress + heading + paragraph + actions. Right: large contextual visual."
5. Max 2 layers (onboarding rule — no nested card surfaces)
