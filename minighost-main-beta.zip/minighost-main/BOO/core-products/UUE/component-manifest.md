# UUE — Component Manifest

## Source Files Reviewed

- Unity Component Library: `ti10RX3jGJ7pw0cfpDEVt8`
- UUE Main: `aCnyUf72lFV79Mi8D4n6DE`

---

## Components Identified in UUE Screens

### From Unity (confirmed instances in screen files)

| Component | Unity Name | Instance Location | Variant / State | Notes |
|---|---|---|---|---|
| Primary Button | `Primary Button` | Home — "Explore" CTA | Default | 150×40px |
| Secondary Button | `Secondary Button (Light)` | Home — secondary action | Light variant | 138×40px |
| Ghost / Tertiary Button | `Button` | Essentials cards — "Learn more" style | Default small | 79–96×32px, paired with chevron-right icon |
| Icon — chevron right | `dds2_chevron-right` | Feature cards, essentials cards | 16×16px and 11×11px | Two sizes used — check against icon size rules |
| Icon — device laptop | `dds2_device-laptop` | My Device card, essentials card | 24×24px | ✅ Correct size per icon rules |
| Icon — battery charge | `dds2_battery-charge` | Battery card, essentials card | 24×24px | ✅ Correct size |
| Icon — power supply cord | `dds2_power-supply-cord` | Power card | 24×24px | ✅ Correct size |
| Icon — view grid alt | `dds2_view-grid-alt` | Applications card in Title Bar | 24×24px | ✅ Correct size |
| Icon — pop-up arrow corner | `dds2_pop-up-arrow-corner` | Applications card | 16×16px | External link indicator |
| Icon — thumb up | `dds2_thumb-up` | Explore card (Rate/Recommend) | 22×22px in 46×46px container | Round icon container pattern |
| Icon — alarm bell | `dds_alarm-bell` (DDS1) | Masthead notification button | 12×12px | ✅ Intentional override — DDS1 names locked for masthead icons |
| Icon — minimize | `dds_minus-minimize` (DDS1) | Window chrome | 12×12px | ✅ Intentional override |
| Icon — close | `dds_close-x` (DDS1) | Window chrome | 10×10px | ✅ Intentional override |
| Icon — arrow right rest | `arrow_Right_Rest` (DDS1) | Window chrome maximize | 16×16px | ✅ Intentional override |
| Icon — Alexa | `Alexa` | Masthead search bar | 16×16px | Third-party integration |
| Windows 11 BG | `Windows 11 BG` | Full bleed behind app window | 1920×1080 | Backdrop only — not a Unity component |

---

## Custom / Composed Organisms (not Unity components — built from Unity primitives)

| Organism | Description | Components Used |
|---|---|---|
| **App Masthead / Title Bar** | 64px header with search, notification button, window controls | Custom frame composed from icon buttons, search field elements |
| **Feature Destination Card** | 287×109px horizontal card — icon + label + chevron | Rounded rectangle surface + icon + text + chevron |
| **Essentials Card (explore tile)** | 187×186–216px vertical card — circular icon container + title + description + CTA button + chevron | Rounded rectangle + circle icon bg + text stack + ghost button + chevron |
| **Quick-link shortcut row** | Compact row for Home's "Links to settings" section | Custom row with icon + label + chevron |
| **Device identity block** | "Welcome to your / [Device Name]" + service tag + primary + secondary action | Custom text stack + button group |

---

## Unity Components NOT Yet Seen in Screens (but in IA scope — likely needed)

| Component | Where Needed |
|---|---|
| Toggle | Display settings (Dolby Vision on/off), Presence Detection (enable/disable) |
| Expandable / Content Layer | Battery details, Display sub-settings drill-downs |
| Dropdown | Thermal Management mode selection |
| Slider | Display brightness (if present) |
| Alert (warning/info) | Warranty status, battery health alerts |
| Toast | Action confirmations (settings saved) |
| Textbox | Search (if full search page exists) |
| Checkbox | Telemetry Consent (confirmed in IA My Account > Preferences) |
| Radio / Choice Tiles | Color profile selection (Bright / Dark / Vivid pattern) |
| Busy Indicator | Loading states for Scan PC, Support Assist launch |

---

## Icon Discrepancies (Unity Baseline vs UUE Screens)

| Icon in Screen | Status | Resolution |
|---|---|---|
| `dds_alarm-bell` | ✅ Intentional override (D-UUE-01) | Use as-is in masthead |
| `dds_minus-minimize` | ✅ Intentional override (D-UUE-01) | Use as-is in masthead |
| `dds_close-x` | ✅ Intentional override (D-UUE-01) | Use as-is in masthead |
| `arrow_Right_Rest` | ✅ Intentional override (D-UUE-01) | Use as-is in masthead |

---

## Component Override Classification (Step 4)

**D-UUE-01 — Intentional:** DDS1 masthead icon names are locked in the product icon pipeline. Use `dds_alarm-bell`, `dds_minus-minimize`, `dds_close-x`, `arrow_Right_Rest` in all masthead implementations.

**D-UUE-02 — Design error:** `dds2_chevron-right` at 11px is incorrect. All chevron instances must be 16px (`icon_size.sm`) or 24px (`icon_size.lg`). Correct in any future screens.

**D-UUE-03 — Design error:** Custom window chrome is incorrect. Apply Unity window chrome component going forward.

**D-UUE-04 — Resolved:** Canonical frame is **1132×782px**.

---

## Notes

- `chevron-right` at 11px in essentials card CTAs is a **confirmed design error** (D-UUE-02). All future screens use 16px for this icon. Existing screens should be corrected on next revision.
- Circular icon containers (46×46px) on the Essentials explore tiles follow the `radius.icon_container` = 50% rule correctly.
- The round icon container background color on explore tiles appears to use a brand-tinted fill — needs token verification against `background-container-accent-base`.
