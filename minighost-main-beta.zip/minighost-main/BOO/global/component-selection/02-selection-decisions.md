# Selection Decisions — Unity Design System

> **Purpose:** Resolve component choice when `01-task-ontology.md` returns 2+ candidates.
> **Core principle:** Questions ask about user context, not visual preference.

## Decision Table Index

| Task | Candidates | Table |
|---|---|---|
| INPUT / binary state | toggle / checkbox | §1.1 |
| INPUT / single select | radio / dropdown | §1.2 |
| TRIGGER / secondary path | button_secondary / hyperlink | §2.1 |
| TRIGGER / primary with async | button_primary / progress_button | §2.2 |
| TRIGGER / async feedback | busy_indicator / progress_button | §2.3 |
| DISPLAY / notification | alert / toast / osd | §3.1 |
| DISPLAY / alert variant | warning / note / congratulation / critical | §3.2 |
| CONTAIN / card type | card_main / card_explore | §4.1 |

---

## §1.1 · Binary State: toggle vs checkbox

| Question | toggle | checkbox |
|---|---|---|
| Does the change apply immediately (no submit button)? | **Yes** | No |
| Is the control inside a form with a submit action? | No | **Yes** |
| Must the control always have a default value? | **Yes** | Not required |
| Typical use | Dark mode, notifications on/off, auto-update | "I agree to terms", opt-in email |

**Decision:** Change takes effect immediately → **toggle**. Change waits for a submit action → **checkbox**.

**Counterexample:** A dark mode preference inside a Settings form that has a "Save" button at the bottom. Use **toggle** anyway — the dark mode change should be live, even if other settings wait for Save. Do not make toggle depend on submit.

---

## §1.2 · Single Select: radio vs dropdown

| Question | radio | dropdown |
|---|---|---|
| Number of options | 2–4 | 5 or more |
| Must users compare all options simultaneously? | **Yes** | No |
| Is layout space constrained? | No | **Yes** |
| Default value required? | Yes (always pre-select one) | Placeholder allowed |

**Decision:**
1. 5+ options → **dropdown**.
2. 2–4 options that should all be visible and comparable → **radio**.
3. Do not use radio for 5+ options to "show them all" — it breaks visual hierarchy.

**Note:** Unity has no ComboBox or MultiSelect component. If the user needs to search or select multiple values, the interaction pattern must be designed with textbox + custom overlay or deferred to a future component.

---

## §2.1 · Secondary Path: button_secondary vs hyperlink

| Question | button_secondary | hyperlink |
|---|---|---|
| Is this action a standalone button (not embedded in text)? | **Yes** | No |
| Does it sit in a button row alongside button_primary? | **Yes** | No |
| Is it embedded inline within a sentence or paragraph? | No | **Yes** |
| Does it navigate to a URL or external resource? | No | **Yes** |
| Visual weight required | Medium (outlined, 40px height) | Low (text only) |

**Decision:**
- Cancel, Back, or Skip sitting next to a primary button → **button_secondary**.
- "Forgot password?", "Create account", or a link inside a sentence → **hyperlink**.
- Do not use hyperlink as a button — it must have a navigation destination, not trigger a form action.

**Counterexample:** "Create an account" sitting below a Sign In form. If it navigates to the registration screen → **hyperlink**. If it opens an inline panel on the same screen → **button_tertiary** or **button_secondary** depending on visual weight.

---

## §2.2 · Primary Action with Async State: button_primary vs progress_button

| Question | button_primary | progress_button |
|---|---|---|
| Does clicking the button trigger a download or install? | No | **Yes** |
| Does the button need to show in-progress and completion states? | No | **Yes** |
| Is the action synchronous or immediately confirmed? | **Yes** | No |
| Is this the primary CTA for a decision (not a workflow step)? | **Yes** | No |

**Decision:**
- Submit, Sign In, Apply, Confirm → **button_primary**.
- Download, Install, Update (with downloading/installing states) → **progress_button**.

**Note:** progress_button has a known accessibility issue: downloading and installing states are color-only without an icon. Always include the state icon (dds2_arrow-down for downloading, dds2_alarm-clock for installing) to satisfy criterion 4.4.

---

## §2.3 · Async Feedback: busy_indicator vs progress_button

| Question | busy_indicator | progress_button |
|---|---|---|
| Is the async operation triggered by a button the user clicked? | Not necessarily | **Yes** |
| Does the triggering button itself need to show state (downloading, installing)? | No | **Yes** |
| Is the wait time indeterminate and unrelated to a specific user action? | **Yes** | No |
| Does the operation have discrete named states (idle → downloading → installing → done)? | No | **Yes** |
| Is this a full-area or background loading state? | **Yes** | No |

**Decision:**
- Page load, data fetch, background processing with no button origin → **busy_indicator**.
- Download, Install, Update where the button itself changes state through the workflow → **progress_button**.

**Key distinction:** `progress_button` owns the async workflow at the button level — the button IS the status. `busy_indicator` is a passive observer — it shows the system is busy, but is not connected to a specific triggering control.

**Note:** Never use both simultaneously for the same operation. If using `progress_button`, do not also place a `busy_indicator` over the same area — it creates duplicate feedback.

---

## §3.1 · Notification Type: alert vs toast vs osd

| Question | alert | toast | osd |
|---|---|---|---|
| Does the user need to see this before continuing? | **Yes** | No | No |
| Does it persist until the user resolves it? | **Yes** | No | No |
| Does it disappear automatically? | No | **Yes** | **Yes** |
| Is it triggered by a system event outside the app (volume, brightness)? | No | No | **Yes** |
| Is it triggered by an app-level event? | **Yes** | **Yes** | No |

**Decision:**
- Message the user must read and act on (error, warning, info in context) → **alert**.
- Short confirmation of a completed action (auto-dismiss, non-critical) → **toast**.
- System-level transient feedback above the app → **osd**.

**Hard rules:**
- Never use toast for error states — use alert (critical) instead.
- osd always renders in dark regardless of app color mode. Do not try to theme it.
- alert must always pair color with icon and text — never color alone (a11y criterion 4.4).

---

## §3.2 · Alert Variant: warning / note / congratulation / critical

| Situation | Variant | Icon |
|---|---|---|
| The action may fail or has a risk the user should know | warning | dds2_alert-notice |
| Informational context, tip, or neutral notice | note | dds2_alert-info-cir |
| Successful outcome, task complete, positive feedback | congratulation | dds2_alert-check-cir |
| Blocking error, failure, or action required | critical | dds2_alert-error |

**Decision:** Match the semantic tone — do not use "note" for errors to make the message feel softer. Match severity to variant.

---

## §4.1 · Card Type: card_main vs card_explore

| Question | card_main | card_explore |
|---|---|---|
| Is the entire card a navigation destination (click to go somewhere)? | **Yes** | No (link is internal) |
| Is the layout horizontal (icon left, text right)? | **Yes** | No (vertical) |
| Does the card represent a navigable list item? | **Yes** | No |
| Does the card present a capability or feature with a CTA link? | No | **Yes** |
| Is the card part of a vertical list? | **Yes** | No |
| Is the card part of a horizontal or grid layout? | No | **Yes** |

**Decision:**
- Horizontal row with icon and label, entire card is clickable → **card_main**.
- Vertical tile with icon, description, and an internal link → **card_explore**.

Do not use card_explore as a navigation row or card_main as a feature tile.
