# Task Ontology — Unity Design System

> **Purpose:** Map user tasks to Unity components. Always enter from here, never from vocabulary matching.
> **Readers:** AI agents (generation step 7a), reviewers (validation step).
> **Core principle:** Start from what the user is doing, not from words in the prompt.

## Layer Relationship

- Layer 1 = this file — task semantics → candidate Unity components
- Layer 2 = `02-selection-decisions.md` — resolve cases with 2+ candidates
- Layer 3 = `03-components-manifest.yaml` — usage rules, anti-patterns, accessibility per component
- Layer 4 = `04-patterns-manifest.yaml` — screen-level or section-level recipes; **check this first**
- Rendering = `component-quick-ref.yaml` — exact dimensions, colors, states (read after selection)

## Agent Process

1. Extract the **task** from the prompt (verb + context — not a component name).
2. **Check Layer 4 first** — if the screen or section matches a named pattern, record it and fill its `key_decisions`. The pattern does not replace component selection; it pre-fills decisions.
3. Walk the tree below to reach one or more candidate components.
4. If 2+ candidates, go to Layer 2.
5. With the component confirmed, read `component-quick-ref.yaml` for visual rendering specs.
6. Read Layer 3 for anti-patterns and accessibility requirements.

---

## Task Tree

```
INPUT · The user is entering or selecting data
│
├── Free-form text entry
│   ├── Any single-line text, numeric, or password field → textbox
│   │   └── Password: textbox with show/hide toggle (eye icon: dds2_eye-view-on / dds2_eye-view-off)
│   └── No multiline variant exists in Unity — use textbox for all text input
│
├── Binary state
│   ├── Change takes effect immediately (setting, mode, preference) → toggle
│   └── Change deferred until form submit (agreement, opt-in) → checkbox
│
├── Select one option from a list
│   ├── 2–4 options, all must be visible and comparable → radio (group)
│   └── 5+ options, or space is constrained → dropdown
│
└── Select multiple options
    └── checkbox group (multiple checkboxes) — no MultiSelect component in Unity


TRIGGER · The user is initiating an action
│
├── Decisive commitment (submit, apply, confirm, sign in) → button_primary
│   └── ≤ 1 per view. If the action has async states (download, install) → progress_button instead
│
├── Secondary path (cancel, go back, skip, alternate) → button_secondary
│   └── If it is a text-only inline link within a paragraph → hyperlink
│
├── Tertiary inline action (less visual weight than secondary) → button_tertiary
│
├── Destructive action (delete, remove, wipe) → button_destructive
│   └── Always pair with a Confirmation pattern (alert + confirmation or modal pattern)
│
└── Action with async/progress state (download, install, update) → progress_button
    └── If the action is primary and has no async state → button_primary


NAVIGATE · The user is moving to a different context
│
├── External URL or secondary path within same screen → hyperlink
│   └── Never use hyperlink as a button (without an href or equivalent)
│
├── Back navigation (window-level) → masthead chevron (not a standalone component; built into masthead)
│
└── Cross-screen routing → handled at framework level; use card_main as the clickable row entry point


DISPLAY · The user needs to perceive status or information
│
├── Persistent in-page message
│   ├── Warning (may fail, user should know) → alert variant: warning
│   ├── Informational note (context, tip) → alert variant: note
│   ├── Success / congratulation → alert variant: congratulation
│   └── Critical error (blocking, must resolve) → alert variant: critical
│
├── Short auto-dismiss system message → toast
│   └── ⚠ Never use toast for critical or error states — use alert instead
│
├── System-level transient overlay (above the app, e.g., volume, brightness) → osd
│   └── osd always renders dark regardless of app color mode
│
├── Loading / processing in progress
│   └── Full-area or inline loading → busy_indicator (7-dot animation)
│       └── ⚠ Unity does not use a spinner or ProgressBar component
│
└── Hover / contextual explanation
    └── Short tooltip on hover → tooltip


CONTAIN · A screen section or item needs a visual container
│
├── Navigation list row (one tappable destination per row) → card_main
│
├── Capability tile (icon + description + link, vertical layout) → card_explore
│
└── Collapsible content section (accordion-style body) → content_layer


STRUCTURE · App chrome and layout skeleton
│
├── Outermost app frame (always rendered once) → window_chrome
│
├── Title bar with window controls → masthead
│   └── Always inside window_chrome; always transparent
│
└── Initial app load screen → splash_screen
```

---

## Vocabulary → Task Path (reverse index)

| Prompt word or phrase | True task | Unity candidate |
|---|---|---|
| input, text field, form field | INPUT / free-form text | textbox |
| password | INPUT / free-form text | textbox (+ show/hide) |
| search field | INPUT / free-form text | textbox (with dds2_search icon) |
| toggle, switch, on/off | INPUT / binary state / immediate | toggle |
| checkbox, agree, opt in | INPUT / binary state / deferred | checkbox |
| radio, pick one, single select | INPUT / select one | radio |
| dropdown, select, picker | INPUT / select one | dropdown |
| button, submit, sign in, apply | TRIGGER / primary | button_primary |
| cancel, back, skip | TRIGGER / secondary | button_secondary |
| link, hyperlink | TRIGGER / secondary path | hyperlink |
| delete, remove, destroy | TRIGGER / destructive | button_destructive |
| download, install, update | TRIGGER / async progress | progress_button |
| warning, caution | DISPLAY / persistent | alert (warning) |
| info, note, tip | DISPLAY / persistent | alert (note) |
| success, complete, done | DISPLAY / persistent | alert (congratulation) |
| error, failed, blocked | DISPLAY / persistent | alert (critical) |
| toast, snackbar, notification | DISPLAY / auto-dismiss | toast (use with caution) |
| loading, spinner, busy | DISPLAY / progress | busy_indicator |
| tooltip, hint, help text | DISPLAY / hover | tooltip |
| card, list item, row | CONTAIN / navigation | card_main |
| tile, capability, feature card | CONTAIN / capability | card_explore |
| accordion, section, collapse | CONTAIN / collapsible | content_layer |
| app window, frame, chrome | STRUCTURE | window_chrome |
| title bar, toolbar, window controls | STRUCTURE | masthead |
| splash, loading screen | STRUCTURE | splash_screen |

**Note:** This index is a reverse lookup, not a direct mapping. Always follow the task path to confirm the candidate before proceeding.

---

## When the task cannot be mapped

If the user intent cannot be walked to a leaf node, return `@clarify` to the prompt author.

Example: prompt says "let the user flag a device." "Flag" could be:
- Status display → alert (note) or a tag (no Unity tag component yet)
- Toggle state → checkbox or toggle
- Trigger a downstream action → button_tertiary with icon

Do not guess. Ask the prompt to clarify what the user does and what the system does in response.
