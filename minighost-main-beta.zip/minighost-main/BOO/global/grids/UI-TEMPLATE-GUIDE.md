# UI Layout Template Guide

> **For LLMs:** Open the template file for the layer you need. Copy its entire contents into a new file. Fill in only the `<!-- REPLACE: ... -->` markers. Touch nothing else.

---

## Step 1 — Pick a template

| Layer | When to use | Template file to open |
|-------|-------------|----------------------|
| **Layer 1** | Top-level page of a section | `layout-template.html` |
| **Layer 2** | Navigating into a section from Layer 1 | `layout-template-subpage.html` |
| **Layer 3** | Navigating deeper from Layer 2 | `layout-template-thirdlayer.html` |

Max depth is 3 layers. Never go deeper.

---

## Step 2 — Copy the template file

Open the template file. Copy its **entire contents** into a new `.html` file. Do not modify anything yet.

---

## About the left rail nav

> **The nav is global.** The left rail nav items are identical across all layers — they represent the top-level sections of your app. The **only** thing that changes per page is which item has `class="active" aria-current="page"`. Never add or remove nav items on Layer 2 or 3.

---

## Step 3 — Fill in the REPLACE markers

### Layer 1 — `layout-template.html`

| Marker | What to put |
|--------|-------------|
| `<!-- REPLACE: Page Title -->` in `<title>` | The page name |
| `<!-- REPLACE: Page Title -->` in `.breadcrumb-current` | Same page name |
| `<!-- REPLACE: paste nav items here ... -->` | Define all top-level nav buttons here. This is the canonical nav set. |
| `<!-- REPLACE: paste content components here ... -->` | Page content |

### Layer 2 — `layout-template-subpage.html`

| Marker | What to put |
|--------|-------------|
| `<!-- REPLACE: Page Title -->` in `<title>` | The subpage name |
| `<!-- REPLACE: Page Title -->` in `<h1>` | Same subpage name |
| `<!-- REPLACE: paste the SAME nav items as Layer 1 here ... -->` | Copy the exact same nav buttons from Layer 1. Add `class="active" aria-current="page"` only to the item this page belongs to. |
| `<!-- REPLACE: paste content components here ... -->` | Page content |

### Layer 3 — `layout-template-thirdlayer.html`

| Marker | What to put |
|--------|-------------|
| `<!-- REPLACE: Page Title -->` in `<title>` | This page's name |
| `<!-- REPLACE: href to layer 2 page -->` | Filename of the Layer 2 page, e.g. `my-subpage.html` |
| `<!-- REPLACE: Layer 2 Page Title -->` | Name of the Layer 2 page (clickable breadcrumb) |
| `<!-- REPLACE: This Page Title -->` | This page's name |
| `<!-- REPLACE: paste the SAME nav items as Layer 1 here ... -->` | Copy the exact same nav buttons from Layer 1. Add `class="active" aria-current="page"` only to the item this page belongs to. |
| `<!-- REPLACE: paste content components here ... -->` | Page content |

---

## Hard Rules

1. Copy the template file in full. Never write HTML from scratch.
2. Only touch `<!-- REPLACE: ... -->` markers. Do not modify CSS or structure.
3. Max 3 layers. Never add a 4th.
4. Use only icons that exist in `BOO/icons/dds2/`. Never invent names.
5. Use only Unity tokens (`var(--...)`). No raw hex or px.
6. One color mode per file. Set `data-theme="light"` or `data-theme="dark"` on `<html>`.


