# Unity Design Rules

## Reading Order

The AI must read and apply this document from broad decisions to detailed construction. Do not start by assembling controls.

| Order | Chapter | Why it is read at this stage |
| ---: | --- | --- |
| 1 | [Spacing Hierarchy](#spacing-hierarchy) | Establishes the semantic spacing ladder and structural relationship rules before any layout is applied. |
| 2 | [Container Layer Rules](#container-layer-rules) | Defines the maximum surface depth and nesting rules before panels or cards are constructed. |
| 3 | [Icon Size Rules](#icon-size-rules) | Locks icon sizes and gap rules before controls are assembled. |
| 4 | [Colors](#colors) | Establishes the surface depth model, atmospheric background, and all color token rules before any styling is applied. |
| 5 | [Typography](#typography) | Defines the type tier budget, weight rules, and token usage before text elements are placed. |

## Spacing Hierarchy

Spacing encodes semantic distance. Every step up in relationship distance
uses the next rung of the ladder — never skip rungs, never apply a larger
gap to a tighter relationship.

#### The Gap Ladder

| Token | Namespace | Semantic role |
| --- | --- | --- |
| `closely_coupled` | `spacing.relationship.closely_coupled` | Elements that belong to the **same object** |
| `standard` | `spacing.relationship.standard` | Elements in the **same section** |
| `major_transition` | `spacing.relationship.major_transition` | **Different sections** on the same page |
| `guided_narrative` | `spacing.relationship.guided_narrative` | Full editorial / onboarding narrative inset only |

The `action_group` token (`spacing.relationship.action_group`) exists but
is narrow-use only (checkbox + label, paired progression buttons). For
general layout rhythm the operative ladder is
**`closely_coupled` → `standard` → `major_transition`**.

#### Structural Relationships

**Same object — `closely_coupled`**
Elements that are part of the same logical unit; they describe or modify
each other.
- Page title ↔ subtitle
- Icon ↔ label within a row
- Header ↔ its immediately following content
- Toggle row sub-elements
- Items in a stacked list within one card

**Same section — `standard`**
Distinct elements that share a parent container or conceptual group.
- Content padding inside any card or panel
- Gap between sibling rows in a settings panel
- Label ↔ its control (toggle, dropdown, slider)
- Back arrow ↔ page title
- Column gap between the nav strip and the content area

**Different sections — `major_transition`**
Two independent feature blocks or named sections on the same screen.
- Section A title block ↔ Section B title block
- Gap between named groups inside a scrollable panel
- Masthead paddingX (separates app chrome from content)

**Editorial / narrative — `guided_narrative`**
Only for onboarding or guided walkthrough screens. Never in utility UI.
- Left inset of all text content
- Gap between progress bar and hero headline
- Navigation button anchor matches this same inset

#### Card Auto-Layout Rule

```
Container padding : standard        — all sides
Gap between rows  : closely_coupled — within same card
Gap between cards : major_transition— between distinct cards/sections
```

If a card contains **named sub-sections**, the gap between them inside
the card is `standard`, not `closely_coupled` — because they are
conceptually separate even though physically inside the same container.

#### The One Invariant

Structural depth = spacing token.

| Hierarchy level | Token |
| --- | --- |
| Same atom | `closely_coupled` |
| Same molecule | `standard` |
| Same organism | `major_transition` |
| Page inset | `guided_narrative` |

Never use a larger token for a tighter relationship. Never use a smaller
token across a section boundary.

## Container Layer Rules

Derived from analysis of all 32 Figma frames. Maximum 3 design layers per screen.

| Layer | Role | Background token | Radius token |
| --- | --- | --- | --- |
| **1 — Panel or nav pill** | Primary surface — settings panel or nav rail | `semantic.color.light/dark.background.container-accent-subtle` | `radius.surface_primary` (16px) for panels; `radius.pill` (100%) for pills |
| **2 — Feature group** | Groups related controls under a heading | `semantic.color.light/dark.background.container-accent-base` | `radius.surface_secondary` (8px) |
| **3 — Feature row / atom** | Individual control row, toggle, or selector | `semantic.color.light/dark.background.surface` | `radius.button_compact` (2px) |

**Invariants**

- Never exceed 3 design layers
- **3 layers is a maximum, not a requirement** — use only as many layers as your content actually needs
- Nav pills and the content panel are **sibling Layer 1 elements** — nav pills are never nested inside the content panel
- Each deeper layer uses a visually distinct background token — never the same token at two consecutive layers
- Radius strictly decreases with depth: `surface_primary` → `surface_secondary` → `button_compact`
- Onboarding screens use max 2 layers and have no nav rail

## Icon Size Rules

Derived from analysis of 32 Figma frames. Two intentional sizes only.

| Context | Token | Value |
| --- | --- | --- |
| Nav pills, feature rows, primary buttons with icon | `icon_size.lg` | 24px |
| Back arrow, firmware alert, connection type tag, undo/redo toolbar | `icon_size.sm` | 16px |

**One Decision Rule**

> If the icon sits inside a nav pill, feature row, or button — use `icon_size.lg`.
> If the icon sits inline with text in a header row — use `icon_size.sm`.

**Invariants**

- Icon-to-label gap: always `spacing.relationship.closely_coupled` (8px)
- State is expressed by the container (background, border, gradient) — never by icon size
- Icon size never changes between default, hover, and selected states
- Never use any size other than `icon_size.lg` or `icon_size.sm`

## Colors

All values reference `BOO/design-systems/unity/components/tokens.yaml` as the single source of truth.

> For full contrast requirements (4.5:1 for body text, 3:1 for UI components and large text), see `BOO/global/accessibility-guides.md` §1.1.

---

#### The Core Model: 3 Surface Depths + 1 Action Layer

Every screen resolves to exactly this structure — no more, no less:

| Depth | Token / Variable | Light | Dark | Role |
|---|---|---|---|---|
| **App / window** | `--background-app` | `primitives.color.white_transparent.95` | `primitives.color.slate_transparent.900-95` | Window root, masthead, nav rail. Never a panel color. |
| **Content surface** | `--background-container-accent-subtle` | `primitives.color.white_transparent.60` | `primitives.color.blue_ue_transparent.500-60` | Major cards, settings panels. Semi-transparent over backdrop blur. ⚠️ Token name suggests accent use but resolves to correct values for content surface. |
| **Accent surface** | `--background-container-accent-base` | `primitives.color.white` + white border | `primitives.color.blue_ue.500` + `blue_ue.500` border | Feature cards, icon containers. |
| **Action / option tile** | `--tertiary-bg` + `--tertiary-storke` | `var(--background-surface)` + `var(--background-track-base)` border | `var(--background-surface-action)` + `var(--border-container-accent)` border | Setting option tiles (Bright / Dark / Vivid pattern). Declare both variables per theme. |
| **Nav rail tile** | `--navigation/main-nav/default-background` | `var(--background-surface)` + `var(--background-track-base)` border | `var(--background-surface-action)` + `var(--border-container-accent)` border | Category nav items in the left rail. Same token values as action tile. |

**Budget: 3 surface depths per screen maximum. A 4th is a structural error.**

#### Atmospheric Body Background

Every screen sits on a tinted atmospheric backdrop — never a flat solid color. Declare on `body` per theme:

```css
/* Light */
body {
  background-color: #e8eef4;
  background-image: radial-gradient(ellipse at 20% 30%, rgba(6,114,203,0.12) 0%, transparent 60%),
                    radial-gradient(ellipse at 80% 70%, rgba(110,105,207,0.08) 0%, transparent 50%);
}
/* Dark */
[data-theme="dark"] body {
  background-color: #07111e;
  background-image: radial-gradient(ellipse at 20% 30%, rgba(6,114,203,0.18) 0%, transparent 60%),
                    radial-gradient(ellipse at 80% 70%, rgba(0,185,255,0.08) 0%, transparent 50%);
}
```

These values are not in `BOO/design-systems/unity/components/tokens.yaml`. They are screen-level atmosphere — not a surface token.

#### Card Shadow

Content panels use a per-theme `--card-shadow` variable. Declare alongside `--tertiary-bg` / `--tertiary-storke`:

```css
:root, [data-theme="light"] {
  /* color from var(--shadow-chrome-content-elevated) — exact match */
  --card-shadow: 0px 4px 60px 12px rgba(6,114,203,0.1);
}
[data-theme="dark"] {
  /* color from var(--background-drop-shadow) — closest match */
  --card-shadow: 0px 4px 157px 0px rgba(0,0,0,0.25);
}
```

Apply with `box-shadow: var(--card-shadow)` on Layer 1 panels. Spread values are screen-specific; shadow colors reference `--shadow-chrome-content-elevated` (light) and `--background-drop-shadow` (dark).

#### Tertiary Background & Stroke (Action Tiles)

Setting option tiles use `--tertiary-bg` and `--tertiary-storke`. Map to nearest semantic tokens:

```css
:root, [data-theme="light"] {
  --tertiary-bg: var(--background-surface);       /* #FFFFFF — exact match */
  --tertiary-storke: var(--background-track-base); /* #C5D4E3 — closest match */
}
[data-theme="dark"] {
  --tertiary-bg: var(--background-surface-action);  /* #081A33 — closest match */
  --tertiary-storke: var(--border-container-accent); /* #193962 — closest match */
}
```

Apply to action tiles and nav rail items.

#### 4 Rules That Cannot Be Broken

**1 — Brand blue is for action and selection only.**

| Use | Token | Light → primitive | Dark → primitive |
|---|---|---|---|
| Primary button, toggle on, nav accent bar | `--background-brand-base` | `blue.600` | `blue.600` |
| Hover / emphasis | `--background-brand-emphasis` | `blue.700` | `blue.700` |
| Active nav item fill | `--background-neutral-emphasis` | `blue.100` | `slate.600` |
| Selection / active tile | `gradient.button_selected` | `linear-gradient(120.33deg, #0672cb 0.46%, #0078d4 0.46%, #6e69cf 118.31%)` | ← same |

Never flood a surface, panel, or background with `--background-brand-base`. Never use the gradient outside of a selected tile.

---

**2 — Dividers are always brand-tinted whisper, never solid gray.**

| Token | Light → primitive | Dark → primitive |
|---|---|---|
| `--border-divider` | `light_blue_transparent.600-20` | `light_blue_transparent.100-20` |

One pixel. Every horizontal separator — masthead bottom, card rows, section breaks — uses this token. Never use `gray.300` or `gray.600` as a divider.

---

**3 — Dark mode has exactly three text colors. Never use a single white for all.**

| Role | Token | Light → primitive | Dark → primitive | Notes |
|---|---|---|---|---|
| All primary text, headings, card titles | `--foreground-default` | `gray.900` | `gray.100` | |
| Secondary metadata, descriptions | `--foreground-neutral` | `gray.800` | `gray.400` | |
| Tertiary helper, captions | `--foreground-neutral-subtle` | `gray.600` | `gray.500` | |
| Links / text actions | `--foreground-interactive-base` | `blue.700` | `blue.400` | |
| Text actions on filled accent cards | `--foreground-interactive-contrast` | `light_blue.200` | `light_blue.200` | |
| Brand-tinted subtitle | `--foreground-brand-accent` | `blue.700` | `gray.100` | Section subtitles, model numbers. ⚠️ `--foreground-brand-subtle` does not exist in yaml — use `--foreground-brand-accent`. |
| Text on any filled surface | `--foreground-on-fill` | `gray.100` | `gray.100` | |

Using `white` or `--foreground-default` for metadata and descriptions is the most common AI error in this system.

> Light mode secondary text is `gray.800`. Dark mode secondary is `gray.400`. Never use a single white for all dark mode text.

---

**4 — Every element must explicitly declare its color token.**

Never rely on color inheritance. Every surface, text, border, and icon must include an explicit token:

```
background: var(--background-...);  ← explicit, never inherited
color: var(--foreground-...);        ← explicit, never inherited
border-color: var(--border-...);     ← explicit, never inherited
```

Inheritance breaks the token-based system and causes dark mode inconsistencies.

---

#### Quick Decision

```
What surface is this element sitting on?
  → Window root / masthead / nav rail  →  --background-app
  → Major card or settings panel       →  --background-container-accent-subtle
  → Brand-tinted feature card          →  --background-container-accent-base
  → Setting option tile (Bright/Dark/Vivid)  →  --tertiary-bg / --tertiary-storke
  → Clickable tile inside a panel            →  --background-surface-action

What is this text doing?
  → Primary heading or label           →  --foreground-default
  → Description or metadata            →  --foreground-neutral
  → Caption or helper                  →  --foreground-neutral-subtle
  → On a filled (blue) surface         →  --foreground-on-fill
  → A link or text action              →  --foreground-interactive-base

Is this a border?
  → Panel outline                      →  --border-container-neutral
  → Option tile (light mode)           →  --tertiary-storke (#d0e4eb)
  → Option tile (dark mode)            →  --tertiary-storke (#1e3f6c)
  → Row separator / masthead bottom    →  --border-divider
  → Button (light mode)                →  --border-brand-base
  → Button (dark mode)                 →  --border-brand-inverse-base
  → Focus ring                         →  --border-focus-default  (purple.500, 2px)
```

## Typography

Use `Roboto` throughout. All values below reference `BOO/design-systems/unity/components/tokens.yaml` as the single source of truth.

---

#### The Core Model: 3 Tiers + 1 Interactive Layer

Every screen resolves to exactly this structure — no more, no less:

| Tier | Token | Size | Line Height | Weight | Tracking | Role |
|---|---|---|---|---|---|---|
| **Structural** | `--type-header_1` | `var(--type-header_1-size)` | `var(--type-header_1-line-height)` | `var(--type-header_1-weight)` | `var(--type-header_1-tracking)` | Where the user is (page/module title) |
| **Structural (homepage)** | `--type-header_2` | `var(--type-header_2-size)` | `var(--type-header_2-line-height)` | `var(--type-header_2-weight)` | `var(--type-header_2-tracking)` | Homepage identity |
| **Content — section** | `--type-header_5` | `var(--type-header_5-size)` | `var(--type-header_5-line-height)` | `var(--type-header_5-weight)` | `var(--type-header_5-tracking)` | What a section is (card/expander title) |
| **Content — body** | `--type-body_2` | `var(--type-body_2-size)` | `var(--type-body_2-line-height)` | `var(--type-body_2-weight)` | `var(--type-body_2-tracking)` | What it does (description, label, body) |
| **Support** | `--type-caption` | `var(--type-caption-size)` | `var(--type-caption-line-height)` | `var(--type-caption-weight)` | `var(--type-caption-tracking)` | Meta, captions, eyebrows |
| **Interactive** *(outside budget)* | `--type-button_2` | `var(--type-button_2-size)` | `var(--type-button_2-line-height)` | `var(--type-button_2-weight)` | `var(--type-button_2-tracking)` | Every button label, every time |

**Budget: 3 reading tiers per screen maximum. A 4th is a structural error.**

#### Additional Tokens (Not in Budget — Specialist Use Only)

These tokens exist in `BOO/design-systems/unity/components/tokens.yaml` but are **not counted** against the 3-tier budget. Use only for the specific component contexts listed.

| Token | Size | Weight | Tracking | When to use |
|---|---|---|---|---|
| `--type-subtitle_2` | `var(--type-subtitle_2-size)` | `var(--type-subtitle_2-weight)` | `var(--type-subtitle_2-tracking)` | Label emphasis — item names in lists, selected nav labels. **Never** use `body_2 + font-weight:500`; use this instead. |
| `--type-header_6` | `var(--type-header_6-size)` | `var(--type-header_6-weight)` | `var(--type-header_6-tracking)` | Small section heading when header_5 (20px) is too large — e.g. compact sidebars, dense settings rails. |
| `--type-body_3` | `var(--type-body_3-size)` | `var(--type-body_3-weight)` | `var(--type-body_3-tracking)` | Dense data, alert text, form helper text. Same size as `button_2` but weight 400 — never mix them. |
| `--type-label` | `var(--type-label-size)` | `var(--type-label-weight)` | `var(--type-label-tracking)` | Form field labels only. Not for body copy or card content. |
| `--type-overline` | `var(--type-overline-size)` | `var(--type-overline-weight)` | `var(--type-overline-tracking)` + uppercase | Eyebrow / category label only. Exactly two allowed places (see Rule 4). |

---

#### 5 Rules That Cannot Be Broken

**1 — Weight signals role, not importance.**

| Weight | Token reference | Allowed on |
|---|---|---|
| `300` | `--type-header_1-weight` · `--type-header_2-weight` | Structural title only |
| `400` | `--type-header_5-weight` · `--type-body_2-weight` · `--type-body_3-weight` · `--type-caption-weight` | All informational, non-interactive text |
| `500` | `--type-button_2-weight` · `--type-subtitle_2-weight` · `--type-header_6-weight` · `--type-label-weight` | Everything clickable / activatable; label emphasis; form labels |
| `600` | *(no token — ad-hoc)* | Selected state in option tile group **only** |
| `700–900` | *(no token — hero numerics only)* | Single hero numeral when it is the screen's sole purpose |

Never raise weight on a heading to make it "feel stronger." Never use `600+` on body or headings.

⚠️ **Common trap:** `body_2` (16px / 400) and `subtitle_2` (16px / 500) are the same pixel size. Never write `font-size: var(--type-body_2-size); font-weight: 500` — that contradicts `body_2`'s own weight token. Use `--type-subtitle_2` instead.

---

**2 — Tracking by token.**

| Token | Value | Applied to |
|---|---|---|
| `--type-header_1-tracking` | `0em` | Page titles ≥ 32px |
| `--type-header_2-tracking` | `0em` | |
| `--type-header_5-tracking` | `0em` | |
| `--type-body_2-tracking` | `0.005em` | Body, labels, descriptions |
| `--type-button_2-tracking` | `0.005em` | All button labels |
| `--type-caption-tracking` | `0.005em` | Meta, captions |
| `--type-overline-tracking` | `0.08em` | Uppercase eyebrow only |

Do not invent new tracking values. The `0.005em` body correction is a rendering-level constant.

---

**3 — Dark mode text has three tiers. Never use a single white for all.**

| Role | Token | Resolved value |
|---|---|---|
| Titles / headings | `--foreground-default` | `primitives.color.gray.100` |
| Card body / content | `--foreground-default` | `primitives.color.gray.100` |
| Expander / meta / descriptions | `--foreground-neutral-contrast` | `primitives.color.slate.200` |
| Links / ghost buttons | `--foreground-interactive` | `primitives.color.light_blue.200` |
| Text on filled surface | `--foreground-on-fill` | `primitives.color.gray.100` |

Using `white` or `--foreground-default` for expander body and meta text is the most common AI error in this system.

---

**4 — Uppercase is allowed in exactly two places.**

| Use | Size token | Tracking token | `text-transform` |
|---|---|---|---|
| Toggle label ("ON") | `--type-body_2-size` | `0.8px` *(component-specific)* | `uppercase` |
| Stat eyebrow | `--type-caption-size` | `--type-overline-tracking` (`0.08em`) | `var(--type-overline-transform)` |

Nowhere else. Not headings, not card titles, not buttons, not body.

---

**5 — Every text element must explicitly declare its color token.**

Never rely on color inheritance. Every text element must include an explicit `color` property using the appropriate foreground token:

```
font-size: var(--type-...-size);
font-weight: var(--type-...-weight);
color: var(--foreground-...);  ← explicit, never inherited
```

This includes buttons, labels, captions, and all interactive elements. Inheritance breaks the token-based system and causes dark mode inconsistencies.

---

#### Quick Decision

```
What does the user DO with this text?

  Orient / navigate    →  --type-header_1   (48px / 300 / 0em)
  Understand section   →  --type-header_5   (20px / 400 / 0em)
  Read description     →  --type-body_2     (16px / 400 / 0.005em)
  Emphasise item name  →  --type-subtitle_2 (16px / 500 / 0.005em)  ← not body_2+500
  Dense / helper text  →  --type-body_3     (14px / 400 / 0.005em)
  Click / activate     →  --type-button_2   (14px / 500 / 0.005em)
  Reference meta       →  --type-caption    (12px / 400 / 0.005em)
  Form field label     →  --type-label      (13px / 500 / 0.005em)

Is this the 4th reading size on this screen?
  → Stop. Reclassify into an existing tier.

Is weight above 500 on non-selected, non-hero text?
  → Stop. Drop to 400.

Is this dark mode meta/description text showing as white?
  → Change to --foreground-neutral-contrast.
```

