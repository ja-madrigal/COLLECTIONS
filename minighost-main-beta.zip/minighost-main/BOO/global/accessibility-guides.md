# Accessibility & Microsoft Customer Experience Requirements

Design reference for native Windows apps shipped on Dell PCs. Intended to be used as agent context when designing app screens and components.

> **Orientation note:** This document is the authoritative rationale reference for accessibility and Microsoft/Dell requirements. The agent's runtime acceptance checklist lives in `01-constitution.yaml §13` — run that check before returning any output.

This document covers two compliance surfaces:

1. **Accessibility — WCAG 2.1 / 2.2 Level AA (design-only criteria).** Only visually observable criteria (color, contrast, type, layout, focus, motion, target size, icons, etc.) are included. Screen-reader, programmatic-name, and other non-visual conformance items are out of scope.
2. **Microsoft Customer Experience & Dell Windows App UI requirements**, sourced from the *Windows Apps Behavioral and Performance Checklist (A12)* and Microsoft Learn guidance for native Windows apps.

Items are cross-referenced so that overlapping requirements appear once, in the section where they are most authoritative.

**Conformance levels:**

- **MUST** — required for release sign-off. A single failure blocks release.
- **MUST NOT** — prohibited. A single occurrence blocks release.
- **SHOULD** — strongly recommended; deviations require documented justification and Dell approval.
- **SHOULD NOT** — strongly discouraged; deviations require documented justification.

---

## Quick Reference: Hard Numbers

Use this table as a fast lookup when making design decisions. Full rationale is in the sections below.

| Requirement | Value | Notes |
|---|---|---|
| Body / UI text contrast | **4.5:1 min** | Text and images of text vs. background |
| Large text contrast | **3:1 min** | ≥ 18 pt regular or ≥ 14 pt bold (≥ 24 px / ≥ 18.66 px bold) |
| UI component contrast (buttons, inputs, icons) | **3:1 min** | Against adjacent colors, in every interactive state |
| Minimum body text size | **14 px** | |
| Text scaling support | **Up to 200 %** | No loss of content or function at max scale |
| Minimum pointer target size | **24 × 24 px** | Or offset spacing so targets don't overlap |
| Recommended touch / pen target | **40 × 40 px** | Preferred for touch/pen-primary surfaces |
| Minimum icon size | **16 × 16 px** | 20–24 px preferred for body/toolbar contexts |
| Focus ring color | **#A95ADC** | Dell app standard |
| Focus ring thickness | **2 px** | |
| Focus ring border radius | **2 px** | |
| Flash threshold | **≤ 3 flashes/sec** | Or below general/red flash thresholds |
| Auto-playing content | **Pause/stop required if > 5 sec** | When displayed alongside other content |

---

## 1. Accessibility — WCAG 2.1 / 2.2 Level AA (Design)

Target conformance: **WCAG 2.2 Level AA** (which is a superset of 2.1 AA and the current ADA-aligned reference for software UI). Only visually observable / design-time criteria are included.

### 1.1 Color & Contrast

- **1.4.3 Contrast (Minimum) — AA.** Normal body text and images of text **MUST** maintain a contrast ratio of at least **4.5:1** against their background.
- **1.4.3 Contrast (Minimum) — AA.** Large text (≥ 18 pt, or ≥ 14 pt bold — roughly ≥ 24 px / ≥ 18.66 px bold) **MUST** maintain a contrast ratio of at least **3:1**.
- **1.4.11 Non-text Contrast — AA.** Interactive UI components (buttons, inputs, toggles, focus rings, etc.) and meaningful graphical objects (icons that convey state, chart elements, etc.) **MUST** maintain at least **3:1** contrast against adjacent colors, in every state (rest, hover, focus, pressed, selected, disabled-when-it-still-conveys-info).
- **1.4.1 Use of Color — A.** Color **MUST NOT** be the only visual means of conveying information, indicating an action, prompting a response, or distinguishing a visual element. Pair color with an icon, text label, underline, pattern, or shape.
- **1.3.3 Sensory Characteristics — A.** Instructions and labels **MUST NOT** rely solely on sensory characteristics — shape, color, size, visual location, or orientation — to communicate meaning. For example: do not instruct users to "click the green button" or "use the control on the left" without also providing a text label or other identifier. Error and status messages must pair color with text and/or an icon.
- Disabled controls **SHOULD** still be visually distinguishable from the background; WCAG exempts inactive controls from 1.4.11 but Dell UX expects ≥ 3:1 contrast to the background for clarity.

### 1.2 Typography & Text Scaling

- **1.4.4 Resize Text — AA.** UI text **MUST** remain readable and functional when the user scales text up to **200 %** (via Windows *Settings → Accessibility → Text size* or display DPI), without loss of content or functionality.
- **1.4.12 Text Spacing — AA.** No loss of content or functionality when users apply: line height ≥ 1.5× font size; paragraph spacing ≥ 2× font size; letter spacing ≥ 0.12× font size; word spacing ≥ 0.16× font size.
- **1.4.10 Reflow — AA (adapted for native Windows).** Layouts **MUST** adapt to window resizing and high-DPI display scaling without requiring horizontal scrolling or causing content to overflow or clip. Every layout region must reflow gracefully as window width decreases, except for content that inherently requires a fixed 2-D layout (data tables, map views, complex charts).
- Body text **SHOULD** default to ≥ **14 px**. Windows platform guidance treats 14 px as the minimum readable default for native app body copy.
- Text **SHOULD NOT** be rendered as images of text where live text can be used (per WCAG 1.4.5 AA — *Images of Text*: avoid rasterizing text into bitmaps for UI labels, buttons, or headings).

### 1.3 Focus, Input & Pointer

- **2.4.7 Focus Visible — AA.** Every keyboard-operable UI element **MUST** show a visible focus indicator when focused.
- **2.4.11 Focus Not Obscured (Minimum) — AA (WCAG 2.2).** When an element receives focus, it **MUST NOT** be entirely hidden by author-created content (sticky headers, overlays, toasts, etc.).
- **Focus ring style (Dell standard).** All focus indicators **MUST** use: color **#A95ADC**, thickness **2 px**, border-radius **2 px**. The focus ring must also satisfy ≥ 3:1 contrast against both the focused element's surface and the surrounding background.
- **2.5.8 Target Size (Minimum) — AA (WCAG 2.2).** Pointer targets **MUST** be at least **24 × 24 px**, *or* have sufficient offset spacing so that a 24 px diameter circle centered on the target does not intersect another target. Exceptions: inline links within a sentence, native OS controls, content the designer cannot modify, or targets where the exact location is essential.
- Touch / pen-first targets in Dell apps **SHOULD** be at least **40 × 40 px**.
- **2.5.7 Dragging Movements — AA (WCAG 2.2).** Any functionality operated by a dragging gesture **MUST** also be operable by a single-pointer activation (tap/click) — e.g., reorderable lists must also expose up/down buttons; sliders must also accept direct value entry.
- **Icon sizing.** Icons **MUST** be at least **16 × 16 px**. **20–24 px** is preferred for body and toolbar contexts. Icons that communicate status or action must also meet the 3:1 non-text contrast requirement (§1.1).

### 1.4 Motion, Animation & Time-Based Media

- **2.3.1 Three Flashes or Below Threshold — A (kept; design-only).** Content **MUST NOT** flash more than **three times in any one-second period**, or the flash **MUST** be below the general / red flash thresholds.
- **2.3.3 Animation from Interactions — AAA (referenced).** Motion triggered by interaction **SHOULD** be disabled or reduced when the user has set Windows *Settings → Accessibility → Visual effects → Animation effects* to **Off**, or the platform `prefers-reduced-motion` signal is set.
- **2.2.2 Pause, Stop, Hide — A (kept; design-only).** Auto-playing, auto-updating, scrolling, or blinking content that runs longer than **5 seconds** and is presented alongside other content **MUST** provide a mechanism to pause, stop, or hide it.

### 1.5 Layout, Orientation & Visual Structure

- **1.3.4 Orientation — AA.** Layout **MUST NOT** restrict the app to a single display orientation (portrait or landscape) unless that orientation is essential.
- **1.4.13 Content on Hover or Focus — AA.** Tooltips/popovers triggered on hover or focus **MUST** be: dismissible without moving pointer/focus; hoverable (the pointer can move onto the popover without it disappearing); and persistent until dismissed, the trigger loses focus/hover, or the information is no longer valid.
- Visual hierarchy (headings, groupings, spacing) **SHOULD** clearly reflect the logical reading order so sighted keyboard users can predict navigation.

### 1.6 Forms, Errors & Status

- **3.3.1 Error Identification — A (design-only).** Form errors **MUST** be identified visually in a way that does not rely on color alone (icon + text + color).
- **3.3.3 Error Suggestion — AA.** When an input error is detected and suggestions are known, suggestions **MUST** be presented to the user (e.g., "Date must be in MM/DD/YYYY format") in the UI.
- **3.3.4 Error Prevention (Legal, Financial, Data) — AA.** For pages that commit legal/financial transactions, modify user data, or submit test responses, the submission **MUST** be reversible, checked, or confirmed. (Applies to Dell apps with purchase, warranty registration, or destructive settings flows.)
- **3.2.4 Consistent Identification — AA.** Components with the same functionality across the app **MUST** be identified consistently (same icon, same label, same placement).
- **3.2.3 Consistent Navigation — AA.** Navigation that is repeated across screens **MUST** appear in the same relative order each time.

### 1.7 Windows-Specific Visual Design Requirements

Sourced from *Microsoft Learn — Accessibility overview for Windows apps* (Windows App SDK / WinUI / XAML).

- The app **MUST** honor Windows **High Contrast themes**. Do not hard-code colors or use explicit styles that block theme-resource lookup; use theme resource dictionaries so controls automatically resolve high-contrast values when a user enables a high-contrast mode.
- The app **MUST** respect the user's **system text scaling** setting (Windows *Settings → Accessibility → Text size*) and **display scaling / DPI** without truncation, clipping, or overlap.
- The app **SHOULD** combine multiple visual cues when communicating critical information (e.g., icon + color + text for status), to support users with color-vision deficiencies.
- The app **SHOULD** provide an alternative simplified UI where complex visuals or animations would otherwise impede comprehension (per the *Design for alternative UI* guidance on Microsoft Learn).

---

## 2. Microsoft Customer Experience & Dell Windows App Requirements

Sourced from the *Windows Apps Behavioral and Performance Checklist (A12)* and Microsoft Learn guidance for native Windows apps.

### 2.1 UI, Display & Scaling

- The application UI **MUST** scale correctly up to **8K** resolution without truncation, clipping, blurred bitmaps, or layout breakage.
- The application UI **MUST** render correctly across the full range of Windows display-scaling settings (typically 100 %–400 % DPI) used on Dell SKUs.
- All content and UI controls **MUST** be keyboard accessible — every interactive element must be reachable and operable via keyboard alone (tab order, Enter/Space activation, arrow-key navigation where appropriate). *Authoritative Microsoft / Dell requirement; WCAG 2.1.1 (Keyboard — all functionality operable via keyboard without requiring specific timing) is satisfied by meeting this.*

---

## 3. Cross-Reference: Where Requirements Overlap

The following requirements appear in both WCAG AA and the Dell/Microsoft checklist. They are documented **once** in the section noted as authoritative; the other column is provided for traceability.

| Topic | WCAG AA reference (criterion + plain English) | MS / Dell checklist reference | Authoritative section |
|---|---|---|---|
| Keyboard operability | **2.1.1 Keyboard** — All functionality must be operable via keyboard alone, with no specific timing required | Dell A12: "All content and UI control MUST be keyboard accessible" | §2.1 |
| System text-size / DPI scaling | **1.4.4 Resize Text** — Text must scale to 200% without loss of content; **1.4.10 Reflow** — Layout must adapt without overflow or clipping | MS Learn — *Accessible text* | §1.2 |
| High-contrast theme support | **1.4.3 Contrast** — Minimum contrast ratios underpin correct high-contrast theme rendering | MS Learn — *Supporting high-contrast themes* | §1.7 |
| Color as the only indicator | **1.4.1 Use of Color** — Color alone must not convey meaning; **1.3.3 Sensory Characteristics** — Instructions must not rely on color, shape, or location alone | MS Learn — *Design for alternative UI* | §1.1 |
| Visible focus indicators | **2.4.7 Focus Visible** — Focus must be visually apparent on every interactive element; **2.4.11 Focus Not Obscured** — Focused element must not be fully hidden by overlaid content | MS Learn — *Keyboard support* | §1.3 |

---

## 4. References

- **WCAG 2.2** — W3C Recommendation, 2023. <https://www.w3.org/TR/WCAG22/>
- **WCAG 2.1** — W3C Recommendation. <https://www.w3.org/TR/WCAG21/>
- **Microsoft Learn — Accessibility overview for Windows apps.** <https://learn.microsoft.com/en-us/windows/apps/design/accessibility/accessibility-overview>
- **Microsoft Learn — Accessible text requirements.** <https://learn.microsoft.com/en-us/windows/apps/design/accessibility/accessible-text-requirements>
- **Microsoft Learn — High-contrast themes.** <https://learn.microsoft.com/en-us/windows/apps/design/accessibility/high-contrast-themes>
- **Microsoft Learn — Keyboard accessibility.** <https://learn.microsoft.com/en-us/windows/apps/design/accessibility/keyboard-accessibility>
- **Windows Apps Behavioral and Performance Checklist (A12)** — Dell internal acceptance checklist (`Windows_Apps_Behavioral_and_Perfromance_Checklist_A12.xlsx`).

---

## 5. Change Log

| Date | Author | Change |
|---|---|---|
| 2026-05-21 | Initial draft | Consolidated WCAG 2.2 AA design criteria, MS Learn accessibility overview, and Dell A12 checklist into a single reference. PDF sources (ISV Guidance Win11 23H2; EEAP App Assessment) not yet incorporated. |
| 2026-05-21 | Revision 1 | Removed non-design / non-agent-actionable sections (factory install, services, power, telemetry, security). Rewrote 1.4.10 Reflow for native Windows context. Added plain English descriptions to WCAG IDs in cross-reference table. Added Quick Reference cheat sheet. Added WCAG 1.3.3 Sensory Characteristics. Added icon sizing guidance. Added Dell focus ring standard (#A95ADC, 2 px, 2 px radius). |
