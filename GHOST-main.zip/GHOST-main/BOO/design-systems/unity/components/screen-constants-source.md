# Screen-Level Constants — Manual Additions to tokens.css

These CSS variable groups are **manually maintained** in `tokens.css` and are **not generated** from Figma exports via `build-tokens.py`.

They define screen-level atmosphere and shadow patterns that apply globally across all screens, independent of component tokens.

---

## 1. Atmospheric Body Background

**Variables:**
- `--atmospheric-bg-color` — base background color for the browser/OS viewport behind the app window
- `--gradient-window-full` — full two-layer window background (mirrors Figma Window component layer structure)

**`--atmospheric-bg-color`** (light/dark):
```css
--atmospheric-bg-color: #e8eef4; /* light */
--atmospheric-bg-color: #07111e; /* dark */
```

**`--gradient-window-full`** (single declaration, self-resolves per theme):
```css
--gradient-window-full:
  var(--gradient-window),          /* Layer 1: color tint — Figma “Window Gradient” style */
  linear-gradient(90deg, var(--background-app) 0%, var(--background-app) 100%); /* Layer 2: theme-aware app base */
```

No dark mode override needed — `--background-app` already resolves per theme (white-95% light, dark-slate-75% dark).

**Usage:**
```css
.app-window {
  background-color: var(--windows-background);   /* = --background-app, base fallback */
  background-image: var(--gradient-window-full); /* two-layer composition */
}
```

**Source:** `BOO/global/design-rules.md` — "Atmospheric Body Background" section; `html/Window.html` — canonical component

---

## 2. Card Shadow

**Variables:**
- `--card-shadow` — multi-layer shadow for elevated content panels

**Purpose:** Content panels (Layer 1 surfaces) use a per-theme shadow that conveys elevation without stacking multiple shadow tokens.

**Light mode:**
```css
--card-shadow: 0px 4px 60px 12px rgba(6, 114, 203, 0.1);
```

**Dark mode:**
```css
--card-shadow: 0px 4px 157px 0px rgba(0, 0, 0, 0.25);
```

**Usage on panels:**
```css
.panel {
  box-shadow: var(--card-shadow);
}
```

**Source:** `BOO/global/design-rules.md` — "Card Shadow" section

---

## 3. Tertiary Background & Stroke

**Variables:**
- `--tertiary-bg` — background color for action tiles and nav rail items
- `--tertiary-stroke` — border/stroke color for action tiles and nav rail items

**Purpose:** Setting option tiles (Bright / Dark / Vivid pattern) and nav rail category items use these paired variables for consistent styling across themes.

**Light mode:**
```css
--tertiary-bg: var(--background-surface);       /* #FFFFFF */
--tertiary-stroke: var(--background-track-base); /* #C5D4E3 */
```

**Dark mode:**
```css
--tertiary-bg: var(--background-surface-action);  /* #081A33 */
--tertiary-stroke: var(--border-container-accent); /* #193962 */
```

**Usage on tiles:**
```css
.action-tile {
  background: var(--tertiary-bg);
  border: 1px solid var(--tertiary-stroke);
}
```

**Source:** `BOO/global/design-rules.md` — "Tertiary Background & Stroke" section

---

## Preservation During Token Rebuilds

When `scripts/build-tokens.py` runs and regenerates `tokens.css` from Figma exports:

1. **Option A (recommended):** Update the build script to preserve the Screen-Level Constants section. Add logic to detect the section marker and re-insert it after generation.

2. **Option B:** Manually re-add this section after each rebuild. This file serves as the source of truth for the values.

Choose the approach that fits your workflow. Either way, this file documents what needs to be preserved.

---

## When to Update

Update these values only if:
- Design system changes the atmospheric gradient strategy
- Card shadow elevation rules change
- Tertiary tile styling changes across themes

All changes should be reflected in `BOO/global/design-rules.md` first, then updated here and in `tokens.css`.
