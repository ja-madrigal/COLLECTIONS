# Unity.WinUI3 Integration Plan for GHOST

**Date:** August 14, 2026  
**Status:** Planning Phase  
**Kit Version:** Unity.WinUI 0.1.0-preview.4

---

## Executive Summary

The Unity.WinUI AI Kit provides a complete, production-ready XAML component library and AI consumption layer for building WinUI3 applications. This document outlines how to integrate this kit into the GHOST workflow, enabling agents to design and build complete WinUI3 applications using the Unity design system.

---

## Current State

### What We Have
1. **GHOST Framework** — A constrained AI system for generating UI screens using the Unity design system
2. **Unity Design System (BOO)** — Complete design tokens, components, and patterns in YAML/markdown
3. **Unity.WinUI AI Kit** — XAML components, catalog, recipes, and AI guidance for WinUI3
4. **new-winui3-project Skill** — Automated project scaffolding

### What's Missing
1. **WinUI3-specific orchestrator** — The 9-step generation sequence adapted for XAML/C#
2. **Component mapping** — How Unity design components map to WinUI3 XAML controls
3. **XAML generation guidance** — AI-friendly rules for producing valid XAML
4. **Integration with new-winui3-project skill** — Kit setup during project creation
5. **WinUI3 reference documentation** — Accessible to agents during generation

---

## Integration Architecture

```
GHOST Session
    ↓
Session Start Flow (.windsurfrules)
    ↓
Option 4: Create New WinUI3 Project
    ↓
new-winui3-project Skill
    ├─ Verify WinUI3 template
    ├─ Collect location & name
    ├─ Create project
    └─ [NEW] Copy kit resources → project
    ↓
WinUI3 Project Created
    ├─ Unity.WinUI NuGet package
    ├─ AGENTS.md (kit instructions)
    ├─ ai/ (catalog, recipes, prompts)
    └─ PackageConsumer.WinUI (sample)
    ↓
Agent Begins Design Work
    ↓
WinUI3-Specific Orchestrator
    ├─ Step 1-6: Design (same as web/HTML)
    ├─ Step 7: Apply visual values (same)
    ├─ Step 8: Run acceptance checklist (same)
    ├─ Step 9a: Statement of Work (same)
    ├─ Step 9b: [NEW] Generate XAML
    │   ├─ Read unity-winui.catalog.json
    │   ├─ Select native WinUI controls
    │   ├─ Apply style keys from catalog
    │   ├─ Use UNITY_XAML_RECIPES.md
    │   └─ Generate MainWindow.xaml
    └─ Step 9c: [NEW] Validate & Build
        ├─ Verify XAML syntax
        ├─ Check style key references
        ├─ Build project (if on Windows)
        └─ Report results

```

---

## Phase 1: Skill Enhancement

### Update: new-winui3-project Skill

**New Step 6a — Copy Kit Resources**

After project creation succeeds, copy kit resources into the new project:

```powershell
# Source: Kit location
$kitPath = "C:\Users\Jorge_Madrigal1\GHOST\BOO\design-systems\unity\components\Unity.WinUI-AI-Kit-0.1.0-preview.4\Unity.WinUI-AI-Kit-0.1.0-preview.4"

# Target: New project root
$projectRoot = "<FullProjectPath>"

# Copy kit resources
Copy-Item "$kitPath\AGENTS.md" -Destination "$projectRoot\AGENTS.md" -Force
Copy-Item "$kitPath\ai" -Destination "$projectRoot\ai" -Recurse -Force
Copy-Item "$kitPath\.github" -Destination "$projectRoot\.github" -Recurse -Force
Copy-Item "$kitPath\packages" -Destination "$projectRoot\packages" -Recurse -Force
```

**New Step 6b — Configure NuGet**

Ensure the project can find the local package:

```powershell
# Verify NuGet.config exists in project
$nugetConfig = "$projectRoot\PackageConsumer.WinUI\NuGet.config"
if (Test-Path $nugetConfig) {
    Write-Host "NuGet.config already configured"
} else {
    Copy-Item "$kitPath\ai\templates\NuGet.config" -Destination $nugetConfig
}
```

**New Step 6c — Update Guidance**

Add WinUI3-specific next steps:

> "Your WinUI3 project is ready with the Unity.WinUI design system!
>
> Kit resources installed:
> - `AGENTS.md` — AI agent instructions
> - `ai/unity-winui.catalog.json` — Control catalog and style keys
> - `ai/UNITY_XAML_RECIPES.md` — Copy-paste XAML patterns
> - `ai/UNITY_WINUI_AI_GUIDE.md` — AI workflow guidance
> - `packages/` — Local NuGet package
>
> Next steps:
> 1. Open the project in Visual Studio: `[FullProjectPath]\[ProjectName].sln`
> 2. Build to restore NuGet packages
> 3. Run (F5) to verify the app launches
> 4. Begin designing screens using GHOST
>
> When designing, the agent will:
> - Read `ai/unity-winui.catalog.json` for available controls
> - Use exact style keys from the catalog
> - Generate XAML using recipes from `ai/UNITY_XAML_RECIPES.md`
> - Build and validate on Windows"

---

## Phase 2: WinUI3-Specific Orchestrator

### New File: `BOO/design-systems/unity/canonical/00-orchestrator-winui3.yaml`

This is a parallel orchestrator for WinUI3 projects. It reuses Steps 1-8 from the main orchestrator but adds WinUI3-specific guidance for Step 9 (XAML generation).

**Key additions:**

1. **Load directives for WinUI3:**
   - At Step 6: Load `unity-winui.catalog.json` before selecting components
   - At Step 7: Load XAML recipes before applying visual values
   - At Step 9: Load AGENTS.md instructions before generating code

2. **Component selection order (WinUI3):**
   - Native WinUI controls (Button, ComboBox, InfoBar, etc.) with style keys
   - Custom controls (UnityToast, UnityMasthead) from `DesignSystem.WinUI.Controls`
   - Composed controls (BasicTile, CardMain) using native controls + style keys

3. **XAML generation rules:**
   - Use `Style="{StaticResource DesignSystemXxxStyle}"` for all styled controls
   - Use `xmlns:unity="using:DesignSystem.WinUI.Controls"` for custom controls
   - Never hardcode colors; use ThemeResource
   - Preserve native WinUI keyboard, focus, and accessibility behavior
   - Keep UnityToast inside the application window
   - Support Light and Dark themes

4. **Validation checklist (WinUI3-specific):**
   - All style keys exist in `unity-winui.catalog.json`
   - Custom controls use correct namespace
   - No hardcoded colors or recreated templates
   - XAML syntax is valid
   - Build succeeds (if on Windows)
   - Light and Dark themes render correctly

---

## Phase 3: Reference Documentation

### New Files to Create

#### 1. `BOO/design-systems/unity/winui3/01-component-mapping.md`

Maps Unity design components to WinUI3 XAML controls:

```markdown
# Unity → WinUI3 Component Mapping

| Unity Component | WinUI3 Control | Style Key | Notes |
|---|---|---|---|
| Button (Primary) | Button | DesignSystemPrimaryButtonStyle | Use Small/Large variants as needed |
| Button (Secondary) | Button | DesignSystemSecondaryButtonStyle | |
| Alert (Info) | InfoBar | DesignSystemAlertInfoStyle | Pair with dds2_alert-info-cir.svg |
| Toast | UnityToast | N/A (custom control) | Must stay inside app window |
| Masthead | UnityMasthead | N/A (custom control) | For title bar integration |
| ... | ... | ... | ... |
```

#### 2. `BOO/design-systems/unity/winui3/02-xaml-generation-guide.md`

Rules for generating valid, design-system-compliant XAML:

```markdown
# XAML Generation Guide

## Style Key Lookup
Before generating any control, look up its style key in `ai/unity-winui.catalog.json`.

## Color Handling
- Never use hex colors
- Use ThemeResource for theme-aware colors
- Example: `Foreground="{ThemeResource TextOnInteractive}"`

## Custom Controls
- UnityToast: `xmlns:unity="using:DesignSystem.WinUI.Controls"`
- UnityMasthead: Same namespace

## Accessibility
- Set AutomationProperties.Name on all interactive elements
- Use LiveSetting="Polite" for status updates
- Preserve native WinUI focus behavior

## Recipes
Copy exact patterns from `ai/UNITY_XAML_RECIPES.md` for:
- Buttons
- Alerts
- Dropdowns
- Tiles
- Cards
- Toasts
- Mastheads
```

#### 3. `BOO/design-systems/unity/winui3/03-kit-resources-index.md`

Quick reference to kit files and their purpose:

```markdown
# Unity.WinUI Kit Resources Index

## Authoritative Sources (in order of priority)
1. `ai/unity-winui.catalog.json` — Control catalog, style keys, public APIs
2. `ai/UNITY_XAML_RECIPES.md` — Copy-paste XAML patterns
3. `PackageConsumer.WinUI/MainWindow.xaml` — Working example
4. `ControlSpecs.WinUI/MainWindow.xaml` — Complete visual harness
5. `controls/` — Design intent and specifications

## AI Guidance
- `ai/UNITY_WINUI_AI_GUIDE.md` — Workflow for AI coding tools
- `AGENTS.md` — Repository-root instructions for Devin
- `.github/copilot-instructions.md` — Visual Studio Copilot integration

## Package & Build
- `packages/Unity.WinUI.0.1.0-preview.4.nupkg` — Local NuGet package
- `ai/templates/NuGet.config` — Package source configuration
- `UNITY_WINUI_PREVIEW_TESTING.md` — Build and validation steps

## Validation
- Light and Dark theme rendering
- Keyboard navigation and focus
- Pointer states (hover, pressed, disabled)
- Accessibility (UI Automation, screen readers)
- DPI scaling (96, 120, 144, 192 DPI)
```

---

## Phase 4: Agent Instructions Update

### Update: `BOO/global/skills/new-winui3-project/skill.md`

Add new steps for kit integration (see Phase 1 above).

### New: `BOO/design-systems/unity/winui3/DEVIN_WINUI3_PROMPT.md`

A starter prompt for Devin when working on WinUI3 projects:

```markdown
# Devin WinUI3 Starter Prompt

You are building a WinUI3 application using the Unity design system.

## Before you start
1. Read `AGENTS.md` in the repository root
2. Read `ai/UNITY_WINUI_AI_GUIDE.md`
3. Read `ai/unity-winui.catalog.json` to see available controls
4. Read `ai/UNITY_XAML_RECIPES.md` for copy-paste XAML patterns

## Your task
[DESIGNER FILLS IN: Describe the feature or screen to build]

## Workflow
1. Design the screen using GHOST and the Unity design system
2. Generate XAML using the catalog and recipes
3. Build the project: `dotnet build .\[ProjectName].csproj -c Debug -p:Platform=x64`
4. Launch the app and validate Light/Dark themes
5. Report what you built and any validation results

## Do not
- Hardcode colors or recreate UNITY templates
- Use WPF, UWP, or other UI frameworks
- Claim visual validation from a non-Windows environment
- Use UnityToast as a Windows system notification
```

---

## Phase 5: Integration Checklist

- [ ] Update `new-winui3-project` skill with kit resource copying
- [ ] Create `00-orchestrator-winui3.yaml`
- [ ] Create `01-component-mapping.md`
- [ ] Create `02-xaml-generation-guide.md`
- [ ] Create `03-kit-resources-index.md`
- [ ] Create `DEVIN_WINUI3_PROMPT.md`
- [ ] Update `.windsurfrules` to reference WinUI3 orchestrator
- [ ] Test: Create a new WinUI3 project and verify kit resources are copied
- [ ] Test: Build and run the sample project
- [ ] Document in `AGENTS.md` (repository root) how to use GHOST with WinUI3

---

## Success Criteria

1. **Skill works:** `new-winui3-project` creates a project with all kit resources
2. **Kit is accessible:** Agent can read catalog, recipes, and guidance from project
3. **XAML generation works:** Agent can produce valid, design-system-compliant XAML
4. **Build succeeds:** Project builds and runs on Windows without errors
5. **Themes work:** Light and Dark modes render correctly
6. **Accessibility passes:** Keyboard navigation, focus, and UI Automation work

---

## Next Steps

1. Implement Phase 1 (skill enhancement)
2. Create Phase 2 (WinUI3 orchestrator)
3. Create Phase 3 (reference docs)
4. Update Phase 4 (agent instructions)
5. Execute Phase 5 (integration checklist)
6. Test end-to-end workflow

---

## Questions & Notes

- Should the orchestrator be a separate file or merged into the main orchestrator?
  - **Decision:** Separate file for clarity, with clear load directives
- How should agents choose between HTML/web and XAML/WinUI3?
  - **Decision:** Session start flow (Option 4) routes to WinUI3 skill
- Should we version the kit resources in the project or link to BOO?
  - **Decision:** Copy into project (per kit README) so project is self-contained
