---
name: "new-winui3-project"
description: "Automates the setup of a new WinUI3 project with template verification and project creation."
trigger: "on_user_request"
execution: "interactive"
scope: "Runs when user requests a new WinUI3 project. Guides user through location and naming, verifies WinUI3 template, and creates the project."
---

# New WinUI3 Project Skill

**Purpose:** Automate the creation of a new WinUI3 project by verifying the WinUI3 template is installed, collecting user preferences for location and project name, and scaffolding the project.

**Execution:** Interactive — requires user input for project location and name. Handles template installation if needed.

---

## Trigger Condition

This skill fires when the user explicitly requests a new WinUI3 project setup.

---

## Step 1 — Verify WinUI3 Template

Check if the WinUI3 template is already installed:

```powershell
dotnet new list
```

Search the output for `winui3` or `WinUI Blank App` template.

**If template is found:**
- Confirm to the user: "WinUI3 template is already installed. Ready to create your project."
- Proceed to Step 2.

**If template is not found:**
- Inform the user: "WinUI3 template not found. Installing Microsoft.WindowsAppSDK.WinUI.CSharp.Templates..."
- Run:
  ```powershell
  dotnet new install Microsoft.WindowsAppSDK.WinUI.CSharp.Templates
  ```
- Verify installation succeeded by checking for success message in output
- If installation fails, report the error and ask the user to check their .NET SDK installation
- If successful, proceed to Step 2

---

## Step 2 — Collect Project Location

Ask the user where they want to create the project:

> "Where would you like to create your WinUI3 project?
> 
> I suggest: `C:\Users\[YourUsername]\Projects\`
> 
> Please provide the full path (or press Enter to use the suggested location):"

**Validation:**
- If user provides a path, verify it exists or is creatable
- If path doesn't exist, offer to create it
- If user presses Enter, use `C:\Users\[CurrentUsername]\Projects\` as default
- Confirm the chosen location with the user before proceeding

---

## Step 3 — Collect Project Name

Ask the user for the project name:

> "What should the new WinUI3 project be named?
> 
> (This will be used as the folder name and project identifier. Use PascalCase, e.g., 'MyAwesomeApp'):"

**Validation:**
- Ensure the name is not empty
- Warn if the name contains spaces or special characters (suggest PascalCase)
- Check if a folder with that name already exists in the chosen location
- If it exists, ask if the user wants to use a different name or overwrite
- Confirm the project name with the user before proceeding

---

## Step 4 — Create the Project

Once location and name are confirmed, create the project:

```powershell
dotnet new winui3 --name <ProjectName> --publisher-dn <PublisherDN>
```

Where:
- `<ProjectName>` is the name provided by the user
- `<PublisherDN>` is the X.500 distinguished name format (see below)

**Publisher DN Format (IMPORTANT):**
The `--publisher-dn` parameter must be in X.500 distinguished name format for MSIX package validation.

**Format:** `CN=<FirstName> <LastName>`

**Examples:**
- ✅ `CN=Jorge Madrigal`
- ✅ `CN=John Smith`
- ❌ `Jorge_Madrigal1` (invalid — underscores and numbers not allowed)
- ❌ `jmadrigal` (invalid — must use full name)

**How to extract from username:**
- If username is `Jorge_Madrigal1`, use `CN=Jorge Madrigal`
- If username is `john.smith`, use `CN=John Smith`
- Ask the user for their full name if unclear

**During creation:**
- Display progress to the user
- If creation succeeds, confirm: "WinUI3 project '[ProjectName]' created successfully at [FullPath]"
- If creation fails, report the error and suggest troubleshooting steps

---

## Step 5 — Verify Project Structure

After creation, verify the project structure:

```powershell
Get-ChildItem "<FullProjectPath>" -Recurse -Depth 2
```

Confirm the presence of:
- `.csproj` file
- `App.xaml` and `App.xaml.cs`
- `MainWindow.xaml` and `MainWindow.xaml.cs`
- `Properties/` folder
- `bin/` and `obj/` folders

If all expected files are present, report success.

---

## Step 6 — Select and Configure Design System Kit

WinUI3 projects can use different design system kits. Each kit provides XAML components, control catalogs, recipes, and AI guidance.

**Ask the user:**

> "Which design system kit would you like to use?
>
> 1. **Unity.WinUI** (default) — Recommended
>    - Location: `BOO/design-systems/unity/components/Unity.WinUI-AI-Kit-0.1.0-preview.4/`
>    - Status: Preview (0.1.0-preview.4)
>    - Includes: BasicTile, Button, Alert, Card, and more
>
> 2. **Custom NuGet Package** — Provide your own
>    - Specify the NuGet package ID and version
>    - Must include AGENTS.md, ai/, .github/, and packages/ folders
>
> 3. **Skip kit setup** — No kit resources
>    - Project will be created without design system resources
>    - You can add a kit manually later
>
> Please select 1, 2, or 3:"

**If user selects Option 1 (Unity.WinUI):**

Copy the default kit resources:

```powershell
$kitPath = "C:\Users\[CurrentUsername]\GHOST\BOO\design-systems\unity\components\Unity.WinUI-AI-Kit-0.1.0-preview.4\Unity.WinUI-AI-Kit-0.1.0-preview.4"
$projectRoot = "<FullProjectPath>"

# Copy AGENTS.md (AI agent instructions)
Copy-Item "$kitPath\AGENTS.md" -Destination "$projectRoot\AGENTS.md" -Force

# Copy ai/ folder (catalog, recipes, guidance)
Copy-Item "$kitPath\ai" -Destination "$projectRoot\ai" -Recurse -Force

# Copy .github/ folder (Copilot instructions)
Copy-Item "$kitPath\.github" -Destination "$projectRoot\.github" -Recurse -Force

# Copy packages/ folder (local NuGet package)
Copy-Item "$kitPath\packages" -Destination "$projectRoot\packages" -Recurse -Force
```

**Verify copy succeeded:**
- `$projectRoot\AGENTS.md` exists
- `$projectRoot\ai\unity-winui.catalog.json` exists
- `$projectRoot\packages\Unity.WinUI.0.1.0-preview.4.nupkg` exists

If any copy fails, report the error and ask the user to verify the kit path exists.

**If user selects Option 2 (Custom NuGet Package):**

Ask for:
- Package ID (e.g., `MyCompany.WinUI.DesignKit`)
- Package version (e.g., `1.0.0`)
- Package source (NuGet.org or custom feed)

Then:
1. Add the package reference to `.csproj`:
   ```xml
   <PackageReference Include="[PackageID]" Version="[Version]" />
   ```
2. Run `dotnet restore` to download the package
3. Ask the user to provide the kit resources (AGENTS.md, ai/, .github/, packages/) manually or from the package

**If user selects Option 3 (Skip kit setup):**

- Skip all kit resource copying
- Confirm: "Project created without design system kit. You can add one later."
- Proceed to Step 7

---

## Step 7 — Configure NuGet Package Source

Ensure the project can find the local Unity.WinUI package:

**Check if NuGet.config exists:**

```powershell
$nugetConfig = "$projectRoot\NuGet.config"
if (Test-Path $nugetConfig) {
    Write-Host "NuGet.config found. Verifying local package source..."
    # Check if 'packages' folder is listed as a source
    $content = Get-Content $nugetConfig
    if ($content -match "packages") {
        Write-Host "Local package source already configured."
    } else {
        Write-Host "WARNING: Local package source not found in NuGet.config. Manual configuration may be needed."
    }
} else {
    Write-Host "Creating NuGet.config with local package source..."
    Copy-Item "$kitPath\ai\templates\NuGet.config" -Destination $nugetConfig -Force
}
```

**CRITICAL: Verify the NuGet.config path is correct:**

The NuGet.config must use **relative path** `./packages` (not `../packages`):

```xml
<add key="UnityPreview" value="./packages" />
```

**Why:** The packages folder is at the same level as the .csproj file. Relative paths must be:
- ✅ `./packages` — correct (current directory)
- ❌ `../packages` — incorrect (parent directory)

**If the path is wrong:**
1. Open `$projectRoot\NuGet.config`
2. Find the line with `<add key="UnityPreview" value="..."`
3. Change the value to `./packages`
4. Save the file
5. Run `dotnet restore` again

---

## Step 8 — Verify MSIX Deployment Configuration

WinUI3 apps require MSIX packaging for debugging. Verify the deployment is configured:

**In Visual Studio:**
1. Open **Build > Configuration Manager**
2. Find your project in the list
3. For **Debug x64** configuration:
   - ✅ **Build** checkbox should be checked
   - ✅ **Deploy** checkbox should be checked
4. Click **Close**

**If Deploy is not checked:**
- Check the Deploy checkbox for Debug x64
- This enables MSIX packaging for debugging
- Required for F5 (Start Debugging) to work

**Why this matters:**
- WinUI3 apps use MSIX packaging
- Visual Studio needs Deploy enabled to package the app for debugging
- Without it, you'll get: "The project needs to be deployed before we can debug"

**Troubleshooting:**
- If you see deployment errors, check the **Package.appxmanifest** file
- Verify the Publisher field is in X.500 format: `CN=FirstName LastName`
- Invalid publisher format will cause manifest validation errors

---

## Step 9 — Next Steps Guidance

Provide the user with next steps:

> "Your WinUI3 project is ready with the Unity design system!
>
> **Kit resources installed:**
> - `AGENTS.md` — AI agent instructions for building with Unity.WinUI
> - `ai/unity-winui.catalog.json` — Control catalog with style keys and public APIs
> - `ai/UNITY_XAML_RECIPES.md` — Copy-paste XAML patterns for common controls
> - `ai/UNITY_WINUI_AI_GUIDE.md` — Workflow guidance for AI tools
> - `packages/` — Local NuGet package (Unity.WinUI 0.1.0-preview.4)
>
> **Next steps:**
> 1. Open the project in Visual Studio: `[FullProjectPath]\[ProjectName].sln`
> 2. Build the project to restore NuGet packages: `Ctrl+Shift+B`
> 3. Verify Deploy is enabled: Build > Configuration Manager > Check Deploy for Debug x64
> 4. Run the project (F5) to verify it launches correctly
> 5. Verify Light and Dark themes render correctly
>
> **Note on warnings:**
> - You may see a DEP0840 warning about Windows App SDK runtime packages
> - This is normal and expected for WinUI3 apps
> - The packages will be installed automatically on first run
> - No action needed — the app will run fine
>
> **Begin designing:**
> - The agent will read `ai/unity-winui.catalog.json` for available controls
> - Use exact style keys from the catalog when generating XAML
> - Copy XAML patterns from `ai/UNITY_XAML_RECIPES.md`
> - Build and validate on Windows after each change
>
> You can now begin designing your UI using GHOST and the Unity design system!"

---

## Troubleshooting

### Issue: "The project needs to be deployed before we can debug"

**Cause:** Deploy is not enabled in Configuration Manager

**Fix:**
1. Go to **Build > Configuration Manager**
2. Check the **Deploy** checkbox for your project (Debug x64)
3. Click **Close**
4. Press F5 again

### Issue: "App manifest validation error" with publisher name

**Cause:** Publisher name is not in X.500 distinguished name format

**Fix:**
1. Open `Package.appxmanifest`
2. Find the `<Identity>` element
3. Change `Publisher="invalid_name"` to `Publisher="CN=FirstName LastName"`
4. Save the file
5. Rebuild and run

**Example:**
```xml
<!-- Before (invalid) -->
<Identity Publisher="Jorge_Madrigal1" ... />

<!-- After (valid) -->
<Identity Publisher="CN=Jorge Madrigal" ... />
```

### Issue: NuGet restore fails with "local source doesn't exist"

**Cause:** NuGet.config has incorrect path to packages folder

**Fix:**
1. Open `NuGet.config`
2. Find the line: `<add key="UnityPreview" value="..."`
3. Change to: `<add key="UnityPreview" value="./packages"`
4. Save the file
5. Run `dotnet restore` again

### Warning: "Project requires packages 'MicrosoftCorporationII.WinAppRuntime...'"

**Message:** DEP0840: Project requires packages with version >= '2.4.0.0'. These packages should be installed on first run.

**What this means:**
- This is a **warning, not an error**
- The Windows App SDK runtime packages need to be installed on the target machine
- This is normal for WinUI3 apps
- The packages will be installed automatically on first run

**Why it happens:**
- WinUI3 apps depend on Windows App SDK runtime packages
- These are system-level packages that must be installed separately
- They're not included in the app package itself

**What to do:**
- ✅ This is normal and expected
- ✅ The app will still run
- ✅ Windows will install the packages automatically on first run
- ✅ No action needed from the developer

**If packages don't install automatically:**
- Visit: http://go.microsoft.com/fwlink/?linkid=2222757
- Download and install the Windows App SDK runtime
- This is a one-time installation per machine

---

## Rules

- Do not create the project until both location and name are confirmed by the user
- Always verify the WinUI3 template before attempting project creation
- **Publisher DN must be in X.500 format:** `CN=FirstName LastName` (not username)
- **Kit selection is flexible:** User can choose Unity.WinUI (default), custom NuGet package, or skip kit setup
- If using Unity.WinUI kit: Copy all kit resources (AGENTS.md, ai/, .github/, packages/) into the project root
- If using custom NuGet package: Add PackageReference to .csproj and run dotnet restore
- If skipping kit: Confirm with user and proceed without kit resources
- **NuGet.config path must be relative:** `./packages` (not `../packages`) when using local package source
- Verify NuGet.config includes the local package source (if applicable)
- Verify Deploy is enabled in Configuration Manager for Debug x64
- Provide clear error messages if any step fails
- Do not proceed past a failed step — ask the user to resolve the issue first
- Confirm all user inputs before taking action
- If kit resources cannot be copied, provide the kit path so the user can copy manually
- Always inform the user about the Deploy configuration requirement
