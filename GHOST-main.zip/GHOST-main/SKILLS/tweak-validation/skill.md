---
name: "tweak-validation"
description: "Lightweight post-tweak check that fires when the agent detects a revision request. Runs the 6 highest-risk rules and outputs an inline pass/fail summary. Does not save a report."
trigger: "after_tweak"
execution: "automatic"
scope: "revision requests only — not full generation"
---

# Tweak Validation Skill

**Purpose:** Run a fixed set of high-risk checks immediately after a targeted revision, before returning the updated artifact to the user.

**Scope:** Fires on revision requests only. Does not replace the `technical-validation` skill or the Step 8 acceptance checklist.

---

## Trigger Classification

Before acting on any request, classify it as one of two modes and state it internally.

**Tweak** — the prompt signals a revision to an existing artifact. Trigger keywords:
`change`, `update`, `swap`, `replace`, `adjust`, `fix`, `move`, `rename`, `remove`, `make it`, `instead of`

**Full generation** — the prompt introduces a new screen, a new framework, or a new navigation model.

Internal statement (required): `"Mode: tweak"` or `"Mode: full generation"`

If mode is `full generation`, skip this skill entirely. The 9-step sequence and `technical-validation` apply.

---

## Tweak Category

After classifying the mode as `tweak`, classify the tweak category and state it internally.

| Category | Examples | T3 applies? |
|---|---|---|
| **Structural** | Swap a component, add or remove a component, change a variant, change a state, modify HTML structure | YES |
| **Surface** | Change a token value, adjust spacing, swap an icon, update text content | NO — T3 is SKIP |

Internal statement (required): `"Tweak category: structural"` or `"Tweak category: surface"`

---

## The 6 Checks

Run every applicable check against the revised artifact.

| ID | Check | Rule |
|---|---|---|
| T1 | Token fidelity | No raw hex, rgba, or px values in the output. Every visual value must be `var(--token-name)`. |
| T2 | Component authority | Every component in the revised output comes from BOO. No invented or approximated components. |
| T3 | Source fidelity | **Structural tweaks only.** For every component touched by the tweak, `html/{Component}.html` was opened and its `<style>` block and HTML structure were copied verbatim. Mark SKIP for surface tweaks. |
| T4 | Focus state | Every interactive element in the revised output has a focus ring: `#A95ADC`, 2px solid, 2px radius. |
| T5 | Contrast | Body text ≥ 4.5:1. UI components ≥ 3:1 in all states. |
| T6 | Color-not-alone | No state change in the revised output communicates via color only. Each is paired with an icon, label, or shape change. |

**Note:** Structural checks (framework selection, grid model, primary action count) are not re-evaluated per tweak. They are inherited from the original generation.

---

## Execution Order

1. Apply the requested change.
2. Run T1 – T6 against the full revised artifact (not just the changed section).
3. On any FAIL: state which check failed, what was found, and what the fix is — then apply the fix before returning the artifact.
4. Append the check summary inline to the response, after the revised artifact.

---

## Output Format

Appended inline, after the revised artifact. No HTML report. No saved file.

```
Tweak check
T1 Token fidelity      PASS
T2 Component authority PASS
T3 Source fidelity     PASS   ← or SKIP for surface tweaks
T4 Focus state         PASS
T5 Contrast            PASS
T6 Color-not-alone     PASS
```

On FAIL, before the artifact:

```
T1 FAIL — Found raw hex `#0672CB` on `.action-button`. Fix: replace with `var(--background-brand-base)`.
```

Then apply the fix and return the corrected artifact with the updated check summary.
