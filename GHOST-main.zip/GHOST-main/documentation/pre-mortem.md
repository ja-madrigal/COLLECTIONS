# Pre-Mortem: GHOST — Six Months Out

**Date written:** 2026-08-19
**Exercise:** Imagine the project failed six months from now. Why did it fail, and what could have prevented it?

---

## The Primary Cause: Fighting the Nature of the Tool

The deepest structural problem is that GHOST is trying to make a **probabilistic system behave deterministically**. Every design decision in the BOO — every STOP instruction, every fidelity mandate, every source file requirement — is written as if the AI will comply reliably. But `model-profile.md` already proves it doesn't. Haiku ignores the source fidelity mandate. Sonnet skips step 9. Both invent spacing values. These aren't bugs to be patched — they're the base behavior of the models.

Six months in, more rules were added to compensate for every failure mode. The BOO grew 40% larger. Agents began hitting context limits and started summarizing instead of reading. The careful, precise output from month two became progressively looser. More STOP instructions were added. The context problem got worse. This is the core loop that kills the project.

**Prevention:** Design for graceful degradation rather than full compliance. The most durable rules are the ones an agent can follow even when skimming — short, concrete, mechanical. The least durable require an agent to hold a large prior context while executing a complex task. Audit the BOO for instructions that require the agent to do two things at once and simplify them.

---

## The Maintenance Trap

The BOO is manually synchronized with the Unity Figma file. There is no automated link between them. Unity is a living design system — tokens change, components update, new patterns emerge. At the six-month mark, the BOO was last fully synchronized in July 2026. Generated output became subtly wrong in ways not obvious until a real designer reviewed it. Trust eroded. Designers started treating GHOST output as a starting point rather than a compliant artifact. The value proposition collapsed.

This audit already found stale file paths, wrong spacing values, and outdated glossary definitions — and the repo is less than a year old. The drift rate will not slow down on its own.

**Prevention:** Every BOO file needs a `source_version` field recording which Unity Figma version it was derived from. When Unity updates, the mismatch is immediately visible. Better: `tokens.css` should be generated from Figma tokens via the existing `build-tokens.py` script — not hand-edited. The rest of the BOO should follow the same principle: machine-readable sources where possible, human-maintained files as the exception.

---

## The Solo Project Vulnerability

The patterns journal has one contributor. The model profile has one contributor. The entire architecture was designed, implemented, and validated by one person. Six months in, that person is reassigned, goes on leave, or simply gets too busy to maintain the BOO alongside real design work.

No one else knows:
- Why a specific rule exists
- Which BOO file is authoritative when two files conflict
- What the actual test for "is GHOST working" looks like
- How to update the kit when Unity.WinUI ships a new version

The system has extensive documentation of *what* the rules are, but almost no documentation of *how to maintain the system itself*. There is no contributor guide, no "how to update the BOO" procedure, no checklist for what to do when Unity releases a new token.

**Prevention:** Write a maintenance guide before you need one. It should cover: how to update BOO files when Unity changes, how to run the canonical test suite, how to validate that an agent is following the rules, and what the minimum viable BOO is (which files are load-bearing versus nice-to-have). Get a second person onboarded on the system now, before you actually need them.

---

## The Self-Validation Problem

The technical validation skill is run by the same agent that generated the output. It will tend to find its own work valid. The model-profile already notes that Haiku "reads the mandate but does not follow it" — an agent that ignores a mandate during generation will also report compliance during validation of the same output.

There is no independent check. Dimension 1 (Visual Fidelity) is supposed to be a human gate, but if no one is doing structured human review on a regular cadence, it becomes a formality. The validation framework exists but the validation habit does not.

**Prevention:** The most durable validation is a fixed test suite — canonical prompts from `documentation/test-prompts/`, run on a schedule, with output reviewed by a human. This already exists as a concept. The missing piece is committing to running it regularly and treating failures as blockers. A CI job that runs the test prompts after every BOO change and flags significant output drift would catch most regression before it compounds.

---

## The WinUI3 Preview Problem

The WinUI3 kit is at `0.1.0-preview.4`. Preview software changes. Style keys get renamed. Controls get deprecated. The control catalog (`unity-winui.catalog.json`) and XAML recipes are pinned to this preview version. Six months from now, Unity.WinUI has shipped a stable 1.0 with breaking changes. Every style key in the orchestrator is wrong. Every recipe in `UNITY_XAML_RECIPES.md` is wrong. The GHOST system instructs agents to use `DesignSystemPrimaryButtonStyle` — but that style no longer exists.

There is no version check in the skill, no warning that the kit is a preview, and no documented procedure for what to do when the kit updates.

**Prevention:** The `new-winui3-project` skill should warn explicitly that the kit is a preview and document the upgrade path. The orchestrator already pins the kit version in the manifest template — that is good. The missing piece is a procedure: "When Unity.WinUI releases a new version, do these things in this order."

---

## The Adoption Failure Mode

The session start ritual requires the user to answer a 4-option question before doing anything. If they prompt directly, the agent pauses and asks the question anyway. This is friction that feels justified from a systems perspective but is annoying in practice.

Six months in, designers who are in a hurry skip GHOST entirely and prompt the AI directly. They get output that is good enough, faster. The cases where GHOST output is clearly better are also the cases that require careful review anyway — and careful review takes time people do not have.

GHOST is solving a real problem, but the value has to be obvious at every session, not just in principle. If the output still needs manual token correction and still invents components, the cost/benefit tips negative.

**Prevention:** Run a structured comparison. Take five real design prompts. Run them with GHOST. Run them without. Score both against the pass criteria rubric. If GHOST wins clearly, you have evidence. If it does not, you know what to fix. This must be done honestly, not to confirm the hypothesis.

---

## What Would Have Prevented It

In order of impact:

1. **Automated Figma → BOO token sync.** The drift problem is the most certain failure mode. Even a simple script that alerts when Figma tokens change would force a review cadence.

2. **A second maintainer.** One person knowing the system is a single point of failure. Two people knowing it means it survives a quarter of disruption.

3. **A regular validation run.** The test prompts exist. Running them monthly against the current BOO and reviewing output drift would catch regression early.

4. **Simpler, more mechanical rules.** The BOO rules that work are concrete and checkable. "Do not use hex values" is checkable. "Follow the spacing hierarchy" is not — it requires judgment. Rules that require judgment compound with context pressure. Favor the former.

5. **Explicit upgrade procedures.** For the Unity kit version, for the Unity design system itself, for new model releases. Every versioned dependency needs a "when this changes, do this" note.

6. **Honest measurement from day one.** Track pass rate per test prompt, per model, over time. If it is improving, you know what is working. If it is declining, you know before it becomes critical. Right now there are no longitudinal metrics — only a few one-off validation notes.

---

## The Honest Summary

GHOST is a well-designed system for a genuinely hard problem. The thinking behind it — ground truth in a BOO, deterministic 9-step sequence, source fidelity mandates — is sound. The failure would not come from bad design. It would come from the system being more fragile than it appears: one maintainer, no automated sync with the source of truth, a validation loop that cannot fully trust itself, and a dependency on preview software.

The bugs from the August 2026 audit are fixable in a day. The structural vulnerabilities above are the ones that compound quietly over six months and then feel sudden.

---

*Written as a planning exercise on 2026-08-19, following the full repo audit.*
