```sh
GHOST/                                      # Project root
├── AGENTS.md                               # Single source of truth for all AI agent behavior
├── ghost.cmd                               # Windows CLI wrapper
├── ghost.js                                # CLI entry point (--project, --enable, --disable, etc.)
├── install.sh                              # Installer script (curl | bash)
├── package.json                            # Package metadata and version
├── README.md                               # Project overview and quick-start
├── setup.js                                # One-time setup script for local environment
├── .devin/                                 # Devin AI agent configuration
│   ├── config.json                         # Project settings, skills registry, design system ref
│   └── README.md                           # Devin configuration notes
├── .gitignore
└── .vscode/
    └── settings.json

├── BOO/                                    # Knowledge layer — design systems and global rules
│   ├── global/                             # LAYER 1 — Universal constraints (all systems)
│   │   ├── accessibility-guides.md         # Hard limits: WCAG 2.2 AA + Microsoft Learn
│   │   ├── design-philosophy.md            # Design principles and rationale
│   │   ├── design-rules.md                 # Cross-system design rules
│   │   ├── principles-quick-check.yaml     # Quick validation checklist
│   │   ├── principles-quick-ref.yaml       # Quick reference for design principles
│   │   ├── assets/
│   │   │   ├── icons-dds2/                 # Shared icon library (DDS2)
│   │   │   │   ├── 03-icon-map.yaml        # Icon vocabulary: name → SVG path
│   │   │   │   └── dds2_*.svg              # ~430 individual icon files
│   │   │   └── logos/
│   │   │       └── dell-logo.svg
│   │   ├── component-selection/            # Universal component selection methodology
│   │   │   ├── 01-task-ontology.md         # Task tree — enter here when no pattern matches
│   │   │   └── 02-selection-decisions.md   # Decision tables for resolving candidates
│   │   └── grids/                          # Grid layout templates and UI guide
│   │       ├── UI-TEMPLATE-GUIDE.md
│   │       ├── layout-template.html
│   │       ├── layout-template-subpage.html
│   │       └── layout-template-thirdlayer.html
│   │
│   └── design-systems/                     # LAYER 2 — Design systems
│       └── unity/                          # Dell Unity Component Library
│           ├── WINUI3_INTEGRATION_PLAN.md  # WinUI3 integration planning notes
│           ├── canonical/                  # Authoritative agent-facing files
│           │   ├── 00-orchestrator.yaml         # Generation sequence — HTML/React
│           │   ├── 00-orchestrator-winui3.yaml  # Generation sequence — WinUI3
│           │   └── 01-constitution.yaml         # Design rules and page frameworks
│           ├── components/                 # Unity component reference
│           │   ├── components.md               # Component usage rules (authoritative)
│           │   ├── components-manifest.yaml    # Semantic usage rules per component
│           │   ├── patterns-manifest.yaml      # Named screen/section recipes
│           │   ├── 05-component-quick-ref.yaml # Historical reference only
│           │   ├── tokens.css                  # Canonical CSS tokens (light + dark mode)
│           │   ├── tokens-primitives.yaml      # Raw primitive token values
│           │   ├── screen-constants-source.md  # Screen dimension constants
│           │   ├── figma-nodes.yaml            # Figma node mappings
│           │   ├── _ARCHIVED-tokens-consolidated.css  # Archived — do not use
│           │   ├── _ARCHIVED-tokens.yaml              # Archived — do not use
│           │   ├── html/                       # HTML component reference implementations
│           │   │   └── *.html                  # One file per component (Alert, Button, etc.)
│           │   ├── tsx/                        # TSX component reference implementations
│           │   │   └── *.tsx                   # One file per component
│           │   └── Unity.WinUI-AI-Kit-0.1.0-preview.4/   # WinUI3 AI Kit (source)
│           │       └── Unity.WinUI-AI-Kit-0.1.0-preview.4/
│           │           ├── AGENTS.md                    # Kit-level agent instructions
│           │           ├── README.md
│           │           ├── UNITY_WINUI_PREVIEW_TESTING.md
│           │           ├── .github/                     # GitHub Copilot instructions
│           │           ├── ai/                          # AI guidance files (copied to projects by skill)
│           │           │   ├── unity-winui.catalog.json
│           │           │   ├── UNITY_XAML_RECIPES.md
│           │           │   └── UNITY_WINUI_AI_GUIDE.md
│           │           ├── packages/                    # NuGet package (Unity.WinUI 0.1.0-preview.4)
│           │           └── PackageConsumer.WinUI/       # Sample consumer project
│           └── layout-contract/            # Screen-specific layout contracts
│               ├── downstream-dacc.yaml
│               └── main-dacc.yaml
│
├── SKILLS/                                 # Executable agent skill procedures
│   ├── new-winui3-project/
│   │   └── skill.md                        # Automated WinUI3 project creation and setup
│   ├── product-onboarding/
│   │   └── skill.md                        # New product onboarding flow (reserved for future)
│   ├── technical-validation/
│   │   └── skill.md                        # Self-validation — Dimensions 2, 3, 4
│   └── tweak-validation/
│       └── skill.md                        # Lightweight post-tweak quality checks
│
├── scripts/
│   ├── build-tokens.py                     # Compiles token sources → tokens.css
│   ├── build-icon-map.py                   # Regenerates 03-icon-map.yaml from icons-dds2/
│   ├── install.js                          # Dead code — redirect stub (see Fix 13)
│   ├── uninstall.js                        # Dead code — redirect stub (see Fix 13)
│   ├── sync-enterprise.sh                  # Syncs changes to enterprise remote
│   └── installer/                          # Active installer utilities
│       ├── common.js                       # Shared functions (injectRules, removeRules, etc.)
│       ├── install.js                      # Postinstall rule injection
│       └── uninstall.js                    # Pre-uninstall rule removal
│
├── documentation/
│   ├── fix-plan.md                         # Active fix plan (2026-08-19 audit)
│   ├── folder-structure.md                 # This file
│   ├── glossary.md                         # Term definitions
│   ├── How-to-use-GHOST.md                 # Usage guide
│   ├── model-profile.md                    # Observed AI model behavior notes
│   ├── pass-criteria.md                    # Validation pass/fail criteria rubric
│   ├── patterns-journal.md                 # Design pattern failure entries (MG-NNN)
│   ├── pre-mortem.md                       # Pre-mortem risk assessment
│   ├── WINUI3_*.md                         # WinUI3 implementation docs (6 files)
│   ├── deprecated/                         # Archived files no longer in active use
│   │   ├── boo-restructure.md              # Architecture notes (historical)
│   │   ├── ghost-onboarding.md             # Superseded by SKILLS/product-onboarding
│   │   └── core-products-test/             # Archived test product — moved from repo root
│   │       └── UUE/
│   └── test-prompts/                       # Canonical prompts for reference screens
│       ├── README.md
│       ├── 01-login-form.md
│       ├── 02-peripheral-manager-home.md
│       ├── 03-fleet-dashboard.md
│       ├── 04-dacc-home.md
│       └── 05-setting-adjustment-flow.md
│
└── validation/                             # Generated screens and validation results
    ├── generated-screens/                  # AI-generated HTML prototype outputs
    │   └── 01-login-form.html
    └── screen-validation-results/          # Scored validation result files
        └── validation-results-template.html
```

---

*Last updated: 2026-08-19. Reflects post-August-2026 refactor state.*

*Note: `CLAUDE.md` and `.windsurfrules` are not repo files. They are generated into project directories by `ghost --project` and `ghost --enable`. Do not expect them at the repo root.*
