# Model Profile 
Models: Claude Sonnet 4.6, Haiku 4.5 & SWE 1.6

Notes on how the AI models we are using behave when generating Unity screens with GHOST. Built by observation, and from the results of the validation pass. Unverified against first-principles model documentation.

**Purpose:** Rule-writing and debugging should lean on these patterns. If you see behavior that contradicts a note, add a counter-example with a date — do not silently remove the entry.

**How to use alongside `patterns-journal.md`:**
- This file tracks **broad behavioral tendencies** by category (layout, color, typography) — the *what*.
- `patterns-journal.md` tracks **individual failure entries** with root cause and proposed BOO fix — the *why and how*.
- When you spot a failure: log the pattern category here, then open the journal and create or update an `MG-NNN` entry with the details.

---

> All entries are pre-validation hypotheses carried over from general AI model behavior observations. Treat them as "things to watch for", not established facts. Entries move to the Observed section below once a contributor confirms them in a real session.

---

## Pre-validation hypotheses

### Layout

- **Defaults to card grids.** Given any multi-item layout prompt, AI will reach for a 3-column card grid regardless of whether the selected framework calls for it. Status dashboard is fine; settings and onboarding are not.
- **Ignores spacing hierarchy.** Uses uniform padding/gap throughout instead of the 8/16/24/76px hierarchy. Especially common in settings screens where the 8px heading-to-surface gap gets replaced with 16px.
- **Adds a category rail to everything.** If the word "settings" appears in the prompt, AI will add a left category rail even on focused single-setting screens where it's explicitly forbidden.

### Color

- **Uses raw hex instead of semantic tokens.** When uncertain which token to use, AI defaults to a hardcoded hex value. Most common failure: `#0672CB` instead of `var(--background-brand-base)`.
- **Floods brand color.** Uses the primary blue as background or decorative fill, not only for action/selection/focus.
- **Ignores mode coherence.** May mix light-surface elements (`white`) and dark-surface elements (`slate-800`) in the same screen when given an ambiguous prompt.

### Typography

- **Uses more than 3 type sizes.** Given freedom, AI will use 5-6 different sizes on a single screen. Add explicit count constraint.
- **Centers body text.** Default aesthetic impulse. Explicitly forbidden in the constitution but AI will still do it on hero/onboarding screens.
- **Writes inline font sizes.** Uses `font-size: 16px` instead of `var(--type-body-2-size)`.

### Components

- **Invents components.** When a needed pattern isn't obvious from the prompt, AI will create a custom component rather than composing from primitives or asking. Most common: custom alert variants, custom navigation items.
- **Skips focus states.** Generates interactive elements with no focus ring. The `#A95ADC` 2px focus ring is consistently omitted unless explicitly called out.
- **Ignores disabled state.** Generates buttons and controls with no disabled variant even when the screen context implies one is needed.

---

## Prompt response characteristics

*To be filled in during Phase validation.*

- Rule count threshold: expected ~3500 tokens before averaging starts (per Coherent observations — verify against BOO load size).
- Manifest block compliance: TBD.
- Re-prompt effectiveness: TBD.

---

## Observed behaviors ✓

### Icons

2026-07-15 - JM - Icons with names not in unity-icon-map.yaml - confirmed
- **Invents icon names.** When unsure, AI generates plausible-looking names like `dds2_wifi-off` or `dds2_error-circle` that don't exist in `icons/unity-icon-map.yaml`. Must be caught in the acceptance checklist.

2026-07-15 - JM - Icons being redrawn instead of the svg being used - confirmed
- **Redraws icons instead of using the svg.** When an icon is available in `icons/unity-icon-map.yaml`, AI will still redraw it instead of using the svg.

### Components

2026-07-15 - JM - Components being redrawn instead of the html code being used - confirmed
- **Redraws components instead of using the html code.** When a component is available in `components/`, AI will still redraw it instead of using the html code.

2026-07-17 - JM - Haiku 4.5 - source_fidelity_mandate ignored - confirmed
- **Writes components from memory even when source file exists.** Haiku reconstructs the `.btn` class with raw values (`font-family: 'Roboto', sans-serif`, `font-size: 14px`, etc.) instead of opening and copying from `html/Button.html`. The mandate is read but not followed.

### JavaScript

2026-07-17 - JM - Haiku 4.5 - raw hex in script blocks - confirmed
- **Token discipline does not extend to `<script>` blocks.** Haiku hardcodes hex values in JavaScript logic (e.g. `track.style.background === '#0672CB'`, `track.style.background = '#839DB4'`). Token fidelity is applied to CSS only; script logic is written from memory.

### Generation sequence

2026-07-17 - JM - Haiku 4.5 - step 9 skipped entirely - confirmed
- **Omits the statement of work.** No manifest block, no `Sources:` field, no A11y checklist produced. Step 9 is consistently skipped — output goes straight to the artifact with no declaration.

### Spacing

2026-07-17 - JM - Haiku 4.5 - spacing values outside 8/16/24/76 hierarchy - confirmed
- **Invents spacing values.** Uses values like `9px` (toggle gap) and `12px` (item margin) that sit outside the defined hierarchy. Hierarchy is not consulted — values are chosen by visual intuition.

Format:
```
YYYY-MM-DD — [contributor] — [behavior observed] — [confirmed or one-off]
```

---

## Update this file when

- You observe a systematic behavior across 2+ independent runs.
- You add a BOO rule specifically to counteract a Claude-specific pattern.
- Claude's behavior changes materially after a model version bump. Note the version.
- A validation entry in `patterns-journal.md` reveals a new systematic bias.
