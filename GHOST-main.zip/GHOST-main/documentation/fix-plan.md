# GHOST Repo Fix Plan

**Date written:** 2026-08-19
**Source:** Full repo audit conducted 2026-08-18/19
**Status:** Ready to execute — no fixes applied yet

This document is self-contained. It captures all 16 identified issues, their root cause, and the exact fix required. It is written to be handed to a fresh AI session without needing to re-read the audit.

---

## How to Use This in a New Session

1. Read this file completely before touching any files
2. Execute fixes in Wave order (1 → 2 → 3)
3. Within each wave, complete all fixes before moving to the next wave
4. Commit after each wave with a descriptive message
5. Mark fixes complete by checking the checkbox next to each item

---

## Wave 1 — Agent-Breaking Errors
*Fix first. These are file path errors an agent hits during a live session. They cause silent failures or missing context.*

---

### Fix 1 — `00-orchestrator-winui3.yaml` stale load directives
- [ ] Complete

**File:** `BOO/design-systems/unity/canonical/00-orchestrator-winui3.yaml`

**Problem:** The `preamble_winui3_addition` block (lines 40–44) tells the agent to read three files from `BOO/design-systems/unity/winui3/` at session start. That directory was intentionally deleted during the WinUI3 implementation cleanup (documented in `documentation/WINUI3_FINAL_STRUCTURE.md`, lines 110–121). The orchestrator was never updated after those files were removed.

The three deleted files were:
- `BOO/design-systems/unity/winui3/01-component-mapping.md`
- `BOO/design-systems/unity/winui3/02-xaml-generation-guide.md`
- `BOO/design-systems/unity/winui3/03-kit-resources-index.md`

Per `WINUI3_FINAL_STRUCTURE.md`, the authoritative replacements are:
- Component mapping → `ai/unity-winui.catalog.json` (copied into project by skill)
- XAML generation guide → the orchestrator itself (all rules are already in `00-orchestrator-winui3.yaml`)
- Kit resources index → the kit folder at `BOO/design-systems/unity/components/Unity.WinUI-AI-Kit-0.1.0-preview.4/`

**Fix:** Rewrite `preamble_winui3_addition` to remove references to the deleted files and point to the actual authoritative sources. The replacement text should direct the agent to read the kit catalog and AI guide files that the skill copies into the project (the `ai/` folder).

**Benefit:** The WinUI3 session start no longer fails on missing files. Agents get correct context rather than proceeding with a partial or broken load.

---

### Fix 2 — `core-products/` directory does not exist
- [ ] Complete

**Files affected:**
- `AGENTS.md` line 64
- `ghost.js` line 251
- `.devin/config.json` line 43
- `SKILLS/product-onboarding/skill.md` Step 6 (writes output here)

**Problem:** Three files reference `core-products/` as the active product directory and the skill writes its onboarding output there. The directory does not exist. The old directory was `core-products-test/` which was moved to `documentation/deprecated/core-products-test/` in the last commit. A clean `core-products/` directory was never created to replace it.

**Fix:**
1. Create `core-products/.gitkeep` to establish the directory
2. Verify all four files above reference `core-products/` consistently (they do — no path changes needed beyond creating the directory)

**Benefit:** `ghost --onboard` works. The session start Option 1 flow ("read subfolders of core-products/") returns meaningful results instead of empty or erroring. The product-onboarding skill can write its output files.

---

### Fix 3 — `01-constitution.yaml` wrong icon map filename
- [ ] Complete

**File:** `BOO/design-systems/unity/canonical/01-constitution.yaml` line 17

**Problem:** The `companion_files` block references `BOO/global/assets/icons-dds2/unity-icon-map.yaml`. This file does not exist. The correct filename is `03-icon-map.yaml`.

**Fix:** Change line 17 from:
```
- path: "BOO/global/assets/icons-dds2/unity-icon-map.yaml"
```
to:
```
- path: "BOO/global/assets/icons-dds2/03-icon-map.yaml"
```

**Benefit:** Agents loading the constitution resolve the correct icon file. Any agent following the companion_files list to validate icons will find the file rather than reporting a missing dependency.

---

### Fix 4 — `technical-validation/skill.md` two wrong paths
- [ ] Complete

**File:** `SKILLS/technical-validation/skill.md`

**Problem:**
- Criterion 3.1 (line 41): references `BOO/unity/boo/02-tokens.yaml` — this path structure does not exist anywhere in the repo. The tokens are in `BOO/design-systems/unity/components/tokens.css`
- Criterion 3.5 (line 45) and a repeated reference (line 61): references `icons/unity-icon-map.yaml` — should be `BOO/global/assets/icons-dds2/03-icon-map.yaml`

**Fix:**
- Line 41: replace `BOO/unity/boo/02-tokens.yaml` with `BOO/design-systems/unity/components/tokens.css`
- Lines 45 and 61: replace `icons/unity-icon-map.yaml` with `BOO/global/assets/icons-dds2/03-icon-map.yaml`

**Benefit:** The technical validation skill checks against files that exist. Currently criteria 3.1 and 3.5 point at nonexistent paths, meaning those checks either fail silently or get skipped entirely.

---

### Fix 5 — `pass-criteria.md` three stale paths and one wrong value
- [ ] Complete

**File:** `documentation/pass-criteria.md`

**Problems:**
1. Lines 7 and 99: `BOO/{system}/skills/technical-validation/skill.md` — Skills were moved out of BOO to the `SKILLS/` directory. Correct path: `SKILLS/technical-validation/skill.md`
2. Line 57 (criterion 3.1): `unity-tokens.yaml` — file does not exist. Should be `tokens.css`
3. Line 61 (criterion 3.5): `icons/unity-icon-map.yaml` — should be `BOO/global/assets/icons-dds2/03-icon-map.yaml`
4. Line 27 (criterion 1.4): spacing listed as `8/10/16/24/76` — the `10` value does not exist in the defined spacing hierarchy. All other references (orchestrator, AGENTS.md, commandments) define the hierarchy as `8/16/24/76`

**Fix:** Four targeted line edits as described above.

**Benefit:** The rubric is self-consistent and references real files. The wrong spacing value (`10`) could cause an agent to accept a 10px gap as valid when it is not defined in the system.

---

### Fix 6 — `patterns-journal.md` duplicate ID and stale path
- [ ] Complete

**File:** `documentation/patterns-journal.md`

**Problems:**
1. Two entries use the ID `MG-003`. The entry starting at line 94 is correctly MG-003. The entry starting at line 113 is actually MG-004 (different content, different failure mode) but has the wrong ID. The journal's own rules state "entries are ID-ascending" — the duplicate breaks that contract.
2. Line 62: references `icons/unity-icon-map.yaml` — should be `BOO/global/assets/icons-dds2/03-icon-map.yaml`

**Fix:**
- The journal is append-only by policy, so do not edit the mislabeled entry's content. Add a correction note immediately after the mislabeled entry's closing `---` that reads: `# Note: This entry was mislabeled MG-003. It is MG-004. Next entry begins at MG-005.` Then change the `id:` field in that entry header to `MG-004`.
- Fix line 62 icon path.

**Benefit:** Journal IDs are internally consistent. Future entries increment from the correct number (MG-005 onward). The stale icon path is corrected so the journal is consistent with the rest of the codebase.

---

## Wave 2 — Documentation Sync
*Fix after Wave 1. These are human-facing files that are factually wrong. No functional breakage but active misinformation.*

---

### Fix 7 — `folder-structure.md` full rewrite
- [ ] Complete

**File:** `documentation/folder-structure.md`

**Problem:** The directory tree reflects the pre-August-2026 refactor state. It is significantly wrong in multiple ways:
- Shows `CLAUDE.md` and `.windsurfrules` in the repo root (both deleted; they now only exist as generated project files)
- Shows `BOO/global/skills/` as active (moved to `SKILLS/`)
- Shows `core-products-test/UUE/` as an active product folder (moved to `documentation/deprecated/`)
- Missing entirely: `AGENTS.md`, `SKILLS/`, `ghost.cmd`, `.devin/`, `BOO/design-systems/unity/components/Unity.WinUI-AI-Kit-0.1.0-preview.4/`, `BOO/design-systems/unity/canonical/00-orchestrator-winui3.yaml`, all `documentation/WINUI3_*.md` files

**Fix:** Rewrite the tree to reflect the current actual directory structure. Run a directory listing to verify accuracy before writing.

**Benefit:** Any contributor or agent reading this file gets an accurate map of the repo. The current version actively misleads — it shows deleted files as present and present files as nonexistent.

---

### Fix 8 — `README.md` three stale sections
- [ ] Complete

**File:** `README.md`

**Problems:**
1. Lines 93, 139, 156: references `GHOST/core-products-test/{product}/` as the active product directory — should be `core-products/`
2. Lines 133–141 "Starting a Session": only shows 3 options, missing "Option 4: Create a new WinUI3 project"
3. Lines 114–118 Skills section: only lists `technical-validation`, missing `product-onboarding`, `new-winui3-project`, and `tweak-validation`

**Fix:** Three targeted section edits as described above.

**Benefit:** README matches the actual session flow. Users who read it to understand how to start a session will not be missing an entire workflow option (WinUI3), and the skills list will be complete.

---

### Fix 9 — `AGENTS.md` Mandatory Rule #4 wrong file reference
- [ ] Complete

**File:** `AGENTS.md` line 165

**Problem:** Mandatory Rule #4 states: "**Sequence:** Follow the 9-step generation sequence in the constitution."

The generation sequence was explicitly moved from the constitution to the orchestrator (`00-orchestrator.yaml`). The constitution itself documents this at lines 25–37 with a migration note. Agents following Rule #4 will open `01-constitution.yaml` looking for the sequence and find only a redirect comment.

**Fix:** Change "in the constitution" to "in the orchestrator (`BOO/design-systems/unity/canonical/00-orchestrator.yaml`)".

**Benefit:** Agents loading AGENTS.md follow Rule #4 to the correct file on the first try. This is the hardest enforcement layer in the system — its rules should be accurate.

---

### Fix 10 — `glossary.md` two stale entries
- [ ] Complete

**File:** `documentation/glossary.md`

**Problems:**
1. Line 13: describes GHOST as "GHOST Alpha." `README.md` says "Version Beta 0.2." Inconsistent.
2. Line 42: the "Atmospheric background" entry states it is "Not a design token — a screen-level atmosphere rule." This was true in an earlier architecture. The current system uses `var(--gradient-window-full)` which IS a token defined in `tokens.css`. The orchestrator commandments (line 299) explicitly instructs agents to use this token. An agent reading the glossary gets the wrong model.

**Fix:**
- Line 13: update "GHOST Alpha" to "GHOST Beta 0.2"
- Line 42: rewrite the "Atmospheric background" entry to reflect that it is now implemented as `var(--gradient-window-full)` in `tokens.css`, applied alongside `var(--windows-background)` on the app window element

**Benefit:** Shared vocabulary stays accurate. The atmospheric background entry is particularly important — if an agent reads "not a design token" it may bypass the token and write raw gradient values, which is a known failure mode.

---

### Fix 11 — `new-winui3-project/skill.md` missing Step 9
- [ ] Complete

**File:** `SKILLS/new-winui3-project/skill.md`

**Problem:** The skill jumps from "Step 8 — Verify MSIX Deployment Configuration" (line 256) directly to "Step 10 — Next Steps Guidance" (line 284). Step 9 does not exist. Based on context and the surrounding steps, this appears to be a renumbering error from a reorganization — "Step 10" should be "Step 9."

**Fix:** Renumber "Step 10" to "Step 9" in the heading and update any internal references.

**Benefit:** The skill is a precise executable procedure. A missing step number is a credibility issue and creates uncertainty about whether content is actually missing versus just mislabeled.

---

### Fix 12 — `00-orchestrator.yaml` stale entry point comment
- [ ] Complete

**File:** `BOO/design-systems/unity/canonical/00-orchestrator.yaml` line 12

**Problem:** The comment reads: "Entry points (.windsurfrules, CLAUDE.md) reference only this file."

`.windsurfrules` and `CLAUDE.md` no longer exist in the repo root. `AGENTS.md` is now the entry point. The CLI (`ghost --project`) injects `AGENTS.md` content into `.windsurfrules` and `CLAUDE.md` in project directories, but those are generated files, not the repo's entry points.

**Fix:** Update line 12 to: "Entry point: `AGENTS.md` (repo root). The CLI injects its content into `.windsurfrules` and `CLAUDE.md` in project directories."

**Benefit:** The orchestrator's own header is accurate. This is the most-read agent-facing file in the system.

---

## Wave 3 — Code Cleanup
*Fix last. Lowest risk. Code hygiene and packaging correctness.*

---

### Fix 13 — `scripts/install.js` and `scripts/uninstall.js` dead code
- [ ] Complete

**Files:** `scripts/install.js`, `scripts/uninstall.js`

**Problem:** Both files begin with a comment stating they are no longer used ("Moved to scripts/installer/…"). They then immediately define functions that reference undeclared variables (`fs`, `path`, `os` — never imported). If any tool, script, or CI job calls these files directly, they throw a `ReferenceError` on the first function call. `uninstall.js` also prints "Minighost Uninstallation" (line 110), which is old branding predating the GHOST rename.

**Fix:** Replace the body of both files with only the redirect comment — no dead function definitions. Final content should be two lines: the "moved to" comment and the correct path to run instead.

**Benefit:** No risk of broken invocation. Branding is consistent. Files are honest about what they are.

---

### Fix 14 — `package.json` stale `files` array
- [ ] Complete

**File:** `package.json`

**Problem:** The `files` array (lines 9–14) controls what gets included if the package is ever published or bundled. Current entries:
- `"systems"` — directory does not exist anywhere in the repo
- `".windsurfrules"` — file was deleted from the repo root

Missing entries that should be included:
- `"AGENTS.md"`
- `"BOO"`
- `"SKILLS"`
- `"ghost.cmd"`
- `"setup.js"`

**Fix:** Remove the two nonexistent entries and add the five missing ones.

**Benefit:** If the package is ever published or distributed, the right files are included. Currently two of four listed entries don't exist.

---

### Fix 15 — `ghost.js` undocumented `--enable` and `--disable` commands
- [ ] Complete

**File:** `ghost.js` lines 297–315 (`showHelp()`), lines 327–332 (switch cases)

**Problem:** `--enable` and `--disable` exist in the switch statement but are not listed in `showHelp()` and do not appear in the README CLI table. They operate on the global agent configs (Windsurf's `global_rules.md`, Claude's `CLAUDE.md`), which is a different scope from `--project` / `--project-off` (which operate on a project's local files). The distinction is meaningful and worth surfacing.

**Fix:** Add `--enable` and `--disable` to the `showHelp()` output with a one-line description clarifying that they operate on global (user-level) agent configs, not project files. Add the same two rows to the CLI Commands table in `README.md`.

**Benefit:** Users running `ghost --help` see all available commands. The scope distinction between global and project-level commands is documented.

---

### Fix 16 — `scripts/sync-enterprise.sh` enterprise remote appears wrong
- [ ] Complete

**File:** `scripts/sync-enterprise.sh`

**Problem:** The variable `ENTERPRISE_REMOTE` (line 8) is set to `https://githubcsg.cec.delllabs.net/CSG-EDG/minighost.git` — which is the same URL as `origin`. Line 16 runs `git push` which pushes to `origin`, not to `$ENTERPRISE_REMOTE`. The script's own instructions (lines 23–31) describe a workflow for pushing to a different Dell machine or air-gapped remote, but the variable was never updated from what appears to be a placeholder.

**Fix:** Either (a) update `ENTERPRISE_REMOTE` to the correct secondary remote URL if one exists, or (b) add a comment block at the top of the script that clearly states this is a manual workflow, explains what `ENTERPRISE_REMOTE` should be set to before running, and notes that line 16 (`git push`) pushes the bundle file to the current remote so the recipient can download it — then explicitly push to the enterprise remote from the receiving machine.

**Benefit:** The script does what it says it does, or at minimum is honest about what it requires before running.

---

## Fix Checklist Summary

| # | File | Wave | Issue |
|---|---|---|---|
| 1 | `BOO/design-systems/unity/canonical/00-orchestrator-winui3.yaml` | 1 | Stale load directives pointing to deleted `winui3/` files |
| 2 | `core-products/` + `AGENTS.md`, `ghost.js`, `.devin/config.json` | 1 | Directory does not exist |
| 3 | `BOO/design-systems/unity/canonical/01-constitution.yaml:17` | 1 | Wrong icon map filename |
| 4 | `SKILLS/technical-validation/skill.md:41,45,61` | 1 | Wrong token and icon map paths |
| 5 | `documentation/pass-criteria.md:7,27,57,61,99` | 1 | Wrong paths + wrong spacing value (10 → remove) |
| 6 | `documentation/patterns-journal.md:113,62` | 1 | Duplicate MG-003 ID + stale icon path |
| 7 | `documentation/folder-structure.md` | 2 | Full tree rewrite — pre-refactor state |
| 8 | `README.md:93,139,156,133–141,114–118` | 2 | Stale product dir, missing Option 4, incomplete skills list |
| 9 | `AGENTS.md:165` | 2 | Mandatory Rule #4 says "constitution" should say "orchestrator" |
| 10 | `documentation/glossary.md:13,42` | 2 | "Alpha" → "Beta 0.2"; stale atmospheric background definition |
| 11 | `SKILLS/new-winui3-project/skill.md` | 2 | Step 10 should be Step 9 |
| 12 | `BOO/design-systems/unity/canonical/00-orchestrator.yaml:12` | 2 | Stale entry point comment |
| 13 | `scripts/install.js`, `scripts/uninstall.js` | 3 | Dead code with broken references; old branding |
| 14 | `package.json` | 3 | Stale `files` array (nonexistent entries, missing real entries) |
| 15 | `ghost.js` + `README.md` | 3 | `--enable`/`--disable` undocumented |
| 16 | `scripts/sync-enterprise.sh` | 3 | Enterprise remote URL not set correctly |

---

## Commit Strategy

```
Wave 1: fix: correct agent-facing file paths and missing directory (fixes 1–6)
Wave 2: docs: sync documentation to current repo state (fixes 7–12)
Wave 3: chore: code cleanup and package hygiene (fixes 13–16)
```

---

*Audit conducted: 2026-08-18. Plan written: 2026-08-19. Fixes began 2026-08-19.*

---

## Post-16 Work: core-products Redesign

**Context captured 2026-08-19 during Fix 2 execution.**

The original Fix 2 called for creating `core-products/.gitkeep`. During alignment, the decision was made to remove the `core-products/` concept from the current GHOST repo instead. The session start Option 1 flow was stubbed out (graceful fallback to Option 2) rather than removed entirely, because the concept will return in a different form.

**What was removed in Fix 2:**
- `ghost --onboard` CLI command and `onboard()` function from `ghost.js`
- `products` block from `.devin/config.json`
- The `core-products/` directory was never created

**What was preserved (intentionally):**
- Option 1 in the session start flow (`AGENTS.md`) — stubbed with a "not yet available" message
- `SKILLS/product-onboarding/skill.md` — kept as-is, will evolve

**The future vision (from designer, 2026-08-19):**
GHOST will eventually help designers kickstart building actual Dell production products (those with a POR, already in production) into WinUI3, web, or Electron — supporting an effort to move from Figma to Code. "Core product" in this context means a real product with design knowledge that GHOST holds to get a designer rolling in a new framework. GHOST is not a prototyping tool in this model — it's a design knowledge and scaffolding accelerator.

**Work needed when this is revisited:**
1. Define what a "core product" folder actually contains in the new model (design knowledge, token overrides, screen inventory, etc.)
2. Decide where product folders live (repo vs. external, per-project vs. centralized)
3. Redesign the session start Option 1 flow to reflect the real product library structure
4. Revisit the `product-onboarding` skill — determine if the 6-step sequence still applies or needs a full rewrite
5. Revisit Fix 8 (`README.md`) — currently set to update `core-products-test/` references to `core-products/`, but the correct target path may change based on the new model
