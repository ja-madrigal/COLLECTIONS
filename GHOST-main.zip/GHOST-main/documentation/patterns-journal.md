# Patterns Journal

Append-only log of AI output failure patterns observed during GHOST validation runs — their root causes and the BOO rules added in response.

**Purpose:**
- Stay honest about what the BOO catches vs. what slips through.
- Make recurring failure modes visible so we don't re-derive solutions.
- Show contributors (and future-me) why a rule exists.

**Rules:**
- Entries are ID-ascending (MG-001 first). Append at the bottom — never reorder.
- Mark `status: resolved` when the BOO fix is in. Mark `status: superseded_by: MG-NNN` if a later entry replaces this one.
- Do not delete entries. The history is the point.

**How to use alongside `model-profile.md`:**
- `model-profile.md` tracks **broad behavioral tendencies** by category — the *what*.
- This file tracks **individual failure entries** with root cause and proposed BOO fix — the *why and how*.
- When you spot a failure: note the pattern in the model profile, then create or update an `MG-NNN` entry here with the specifics.

---

## Entry schema

```yaml
---
id: MG-NNN
type: bug | gap | ambiguity
confidence: hypothesis | observed | verified | established
status: active | resolved | superseded_by: MG-NNN
date: YYYY-MM-DD
contributor: [name or alias]
screen: [screen name or prompt]
fixed_in: [constitution vX.X | tokens vX.X | BOO/system-prompt | n/a]
---
```

**Confidence levels:**
- `hypothesis` — expected failure, not yet seen in validation
- `observed` — seen once in a real session
- `verified` — reproduced across 2+ independent runs
- `established` — root cause confirmed, fix verified in re-run

---

## Pre-validation hypotheses

> ⚠️ These are seeded from general AI behavior patterns as a starting point. Confidence is `hypothesis` on all entries. Do not treat them as established facts — verify and update the `confidence` and `status` fields accordingly.

---
id: MG-001
type: ambiguity
confidence: verified
status: active
date: 2026-06-09
contributor: system
screen: any
fixed_in: orchestrator.step6
---

### MG-001 — Agent invents icon names

**Expected:** Agent generates icon names that don't exist in `BOO/global/assets/icons-dds2/03-icon-map.yaml` (e.g. `dds2_wifi-off`, `dds2_error-circle`).

**Root cause (hypothesis):** The pattern isn't a validation gap — it's an upstream sourcing gap. The orchestrator says look up the component but doesn't say copy from it. So the agent reads the spec, understands it, then writes its own approximation from memory. Same with icons: it reads the map, finds the name, then draws a simplified path instead of pulling the actual file.

**Fix (proposed):** The real fix is upstream + lightweight confirmation:
In the orchestrator step 6 — rewrite the load directive to say: "At this step you MUST open and read the component .html file. Do not write CSS. Paste from source." This prevents the problem rather than catching it.
In step 9 (manifest) — add a sources block that requires the agent to explicitly list every file it opened: html/Textbox.html ✓, icons-dds2/dds2_close-x.svg ✓. A missing file = it didn't open it.
The manifest sources block is the simplest possible audit — zero extra tooling, forces acknowledgment, and makes drift visible in the output immediately

---
id: MG-002
type: ambiguity
confidence: verified
status: active
date: 2026-06-09
contributor: system
screen: any
fixed_in: orchestrator.step6
---

### MG-002 — Agent looks up components without copying  

**Expected:** Agent looks up components but doesn't copy from them.

**Root cause (hypothesis):** The pattern isn't a validation gap — it's an upstream sourcing gap. The orchestrator says look up the component but doesn't say copy from it. So the agent reads the spec, understands it, then writes its own approximation from memory. Same with icons: it reads the map, finds the name, then draws a simplified path instead of pulling the actual file.

**Fix (proposed):** The real fix is upstream + lightweight confirmation:
In the orchestrator step 6 — rewrite the load directive to say: "At this step you MUST open and read the component .html file. Do not write CSS. Paste from source." This prevents the problem rather than catching it.
In step 9 (manifest) — add a sources block that requires the agent to explicitly list every file it opened: html/Textbox.html ✓, icons-dds2/dds2_close-x.svg ✓. A missing file = it didn't open it.
The manifest sources block is the simplest possible audit — zero extra tooling, forces acknowledgment, and makes drift visible in the output immediately

---
id: MG-003  
type: bug
confidence: observed
status: active
date: 2026-06-09
contributor: system
screen: any
fixed_in: n/a
---

### MG-003 — Focus ring omitted

**Expected:** Interactive elements generated without the `#A95ADC` 2px focus ring.

**Root cause (hypothesis):** Focus states are easy to skip in a generation pass focused on layout and color. The acceptance checklist has `focus_visible` as a check but the agent may pass it without actually generating the CSS.

**Fix (proposed):** Add a focus ring utility class to `tokens.css` (`.focus-ring`) and require its use in all interactive element examples in the BOO.

---
id: MG-004
type: bug
confidence: hypothesis
status: active
date: 2026-06-18
contributor: system
screen: settings
fixed_in: n/a
---

### MG-004 — Raw hex used instead of semantic token

**Expected:** Agent writes `#0672CB` or `color: white` instead of `var(--background-brand-base)`.

**Root cause (hypothesis):** When uncertain which semantic token maps to the desired color, the agent falls back to the resolved hex value it knows from the constitution. This is technically accurate but bypasses the token system.

**Fix (proposed):** Add a STOP instruction in the system prompt: "If you know the hex but not the token name, STOP and look it up in unity-tokens.yaml." Consider adding a quick-reference color → token mapping to the BOO.

---

<!-- Note: This entry was mislabeled MG-003 in the original journal. It is MG-004. Next entry begins at MG-005. Corrected 2026-08-19. -->

## Validation entries

*No entries yet. Phase 2 validation pending.*
