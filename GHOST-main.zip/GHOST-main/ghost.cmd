@node "%~dp0ghost.js" %*
