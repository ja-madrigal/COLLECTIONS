```
░█▀▀░█░█░█▀█░█▀▀░▀█▀
░█░█░█▀█░█░█░▀▀█░░█░
░▀▀▀░▀░▀░▀▀▀░▀▀▀░░▀░
```

# GHOST — Version Beta 0.2
EDG Software AI-Assisted UI/UX Designer

GHOST is a framework of guidelines, constraints, and design principles that enables AI agents to generate complete UI experiences and application prototypes 
using Dell design languages.

The Book of Origins (BOO) serves as the authoritative source for all design system knowledge. It contains the patterns, components, foundations, tokens, interaction models, and principles required to understand and apply the design system correctly.

The goal is consistency first, creative generation second.

---

## Available on Ghost

| System | Folder | Status | Figma Link |
|---|---|---|---|
| `unity` | `BOO/design-systems/unity/` | Active — Dell Unity design system | [Figma](https://www.figma.com/design/8TipUKvce0k9JPezXvpGrP/Unity-Component-Library) |

---

## Setup

Requires **git** and **Node.js** installed. Requires git access to `githubcsg.cec.delllabs.net`.

Open Terminal and run:

```powershell
git clone https://githubcsg.cec.delllabs.net/CSG-EDG/GHOST.git $env:USERPROFILE\GHOST; cd $env:USERPROFILE\GHOST; node setup.js
```

That's it! GHOST is ready. Open your project folder in Windsurf and run `ghost --project` in the terminal — or just ask the AI agent to do it.

**Enable for a project** — navigate to your design project folder and run:
```sh
ghost --project
```

---

## CLI Commands

| Command | Description |
|---|---|
| `ghost --project` | Enable Ghost in the current project folder |
| `ghost --project-off` | Remove Ghost from the current project folder |
| `ghost --enable` | Enable Ghost globally (user-level agent configs) |
| `ghost --disable` | Disable Ghost globally (user-level agent configs) |
| `ghost --update` | Update to latest version |
| `ghost --uninstall` | Remove Ghost and uninstall |
| `ghost --status` | Show current status and version |
| `ghost --help` | Show usage |

---

## How to Enable GHOST in a Project

Navigate to your design project folder and run:

```powershell
ghost --project
```

This creates two files in the project root:
- **`.windsurfrules`** — picked up automatically by Windsurf
- **`CLAUDE.md`** — picked up automatically by Claude Code

Both files contain the full Ghost ruleset with absolute paths to the BOO files, so the AI agent can read them from this project. Ghost is only active in projects where you run this command.

To remove GHOST from a project:

```powershell
ghost --project-off
```

This cleanly removes both files. No orphaned content is left behind.

---

## Ready to generate?

See [documentation/How-to-use-GHOST.md](documentation/How-to-use-GHOST.md) for a full walkthrough — prompting, iterating, running validation, and more.

---

## The Book of Origins (BOO)

BOO is the knowledge layer. Contains principles, patterns, and design standards. Each design system has its own BOO under `BOO/design-systems/{system}/canonical/` and `BOO/design-systems/{system}/components/`. The agent consults knowledge files before generating anything.

| File | Role |
|---|---|
| `01-constitution.yaml` | **The rules.** Generation sequence, page frameworks, grid models, color usage, components, typography, shape, elevation, motion, and accessibility hard rules. |
| `tokens.css` | **The values.** Single canonical source for all design tokens — component, semantic colors (light + dark), typography, spacing, radius, elevation, motion, z-index, and layout constants. |
| `03-icon-map.yaml` | **The visual vocabulary.** Maps every icon name to its SVG path. The agent looks up icons here — it never invents names. |
| `accessibility-guides.md` | **The hard limits.** WCAG 2.2 AA + Microsoft Learn requirements. Every MUST and MUST NOT is a release blocker. |
| `components.md` | **The rendering spec.** Props, states, key tokens, and shadow/blur values per component. Agent reads the relevant entry before rendering any component. |

---

## Skills

Skills are reusable validation and quality check procedures that the AI agent can run. Skills are located in `SKILLS/{skill-name}/skill.md` with frontmatter metadata:

- `name`: skill identifier
- `description`: what the skill does
- `trigger`: when the skill runs (e.g., "after_generation")
- `execution`: how the skill runs (e.g., "automatic or user_prompt")
- `scope`: what the skill applies to

**Current Skills:**
- `new-winui3-project` — Scaffolds a new WinUI3 project with the Unity.WinUI kit (NuGet package, AI catalog, XAML recipes, and agent instructions).
- `product-onboarding` — Interactive 6-step sequence for onboarding new products (reserved for future use).
- `technical-validation` — Self-validates Unity design system output against technical criteria (Dimensions 2-4 of the validation rubric) before human visual review.
- `tweak-validation` — Lightweight post-tweak quality checks after incremental changes.

Skills run automatically after screen generation (if `trigger: "after_generation"`) or can be invoked by user prompt.

---

## Project Structure

For detailed folder structure and file descriptions, see [documentation/folder-structure.md](documentation/folder-structure.md).

---

## Starting a Session

When you open a project with GHOST enabled, the agent will ask:

> "What are you working on today?"
> 1. An existing product
> 2. A new product
> 3. Just exploring or testing
> 4. Create a new WinUI3 project

**Tip:** Start every session with a simple message like `"let's get started"` or `"hey"` rather than jumping straight into a design prompt. This lets the agent ask the question first — if you open with a full design prompt, the agent will pause and ask anyway, so starting simple saves a step.

- **Option 1** — Product library (reserved for future use). The agent will inform you no products are available yet and fall through to Option 2.
- **Option 2** — Kicks off the onboarding flow to set up a new product folder.
- **Option 3** — No product context loaded. Use this for exploration, testing, or one-off work.
- **Option 4** — Runs the `new-winui3-project` skill to scaffold a WinUI3 project with the Unity.WinUI kit.

---

## The Agent Contract

With Ghost enabled, the agent automatically:

1. Reads BOO knowledge files before generating anything.
2. Follows the 9-step generation sequence — no skipping, no reordering.
3. Uses only tokens defined in `tokens.css`. No invented values.
4. Uses only icons and names from `03-icon-map.yaml`. No invented names.
5. Consults `components.md` before rendering any component.
6. Emits a manifest block at the top of every output (screen name, framework, grid, mode, primary action, a11y status).
7. Runs the acceptance checklist before returning any artifact.
8. For new products, invokes the `product-onboarding` skill to collect product context.
