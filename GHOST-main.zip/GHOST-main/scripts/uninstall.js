// Moved to scripts/installer/uninstall.js
// This file is no longer used. Run: node scripts/installer/uninstall.js
