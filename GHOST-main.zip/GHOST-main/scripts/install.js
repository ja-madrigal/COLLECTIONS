// Moved to scripts/installer/install.js
// This file is no longer used. Run: node scripts/installer/install.js
