#!/bin/bash
# sync-enterprise.sh
#
# Creates a portable git bundle of the full repo and pushes it to origin
# so it can be downloaded by machines that cannot directly clone the repo.
#
# USE CASE: air-gapped or restricted Dell machines that can download a file
# from githubcsg.cec.delllabs.net but cannot run a full git clone.
#
# HOW TO USE:
#   1. Run this script from the repo root on a machine with git push access.
#   2. The bundle file (GHOST.bundle) is committed and pushed to origin.
#   3. On the receiving machine, download GHOST.bundle, then run:
#
#        git clone GHOST.bundle GHOST
#        cd GHOST
#
#   Note: There is no secondary enterprise remote. All syncing goes through
#   https://githubcsg.cec.delllabs.net/CSG-EDG/GHOST.git

set -e

BUNDLE_NAME="GHOST.bundle"

echo "=> Generating bundle..."
git bundle create "$BUNDLE_NAME" --all

echo "=> Committing bundle to origin..."
git add "$BUNDLE_NAME"
git commit -m "Update git bundle for distribution"
git push

echo ""
echo "========================================"
echo "  Bundle ready: $BUNDLE_NAME"
echo "========================================"
echo ""
echo "On the receiving machine:"
echo ""
echo "  1. Download $BUNDLE_NAME from:"
echo "     https://githubcsg.cec.delllabs.net/CSG-EDG/GHOST"
echo ""
echo "  2. Run:"
echo "     git clone $BUNDLE_NAME GHOST"
echo "     cd GHOST"
echo ""
echo "  3. Done. Delete the bundle file when finished."
echo ""
