# Devin Configuration for GHOST

This directory contains Devin-specific configuration for the GHOST framework.

## Quick Reference

- **Agent Instructions:** Read `AGENTS.md` (root level)
  - Session startup flow
  - Design decision process
  - Operating principles
  - Mandatory rules

- **Skills Location:** `SKILLS/` (root level)
  - `new-winui3-project` — Create WinUI3 projects
  - `product-onboarding` — Onboard new products
  - `technical-validation` — Validate technical output
  - `tweak-validation` — Quick post-tweak checks

- **Design System:** `BOO/` (Book of Origins)
  - Orchestrator: `BOO/design-systems/unity/canonical/00-orchestrator.yaml`
  - Components, tokens, patterns, guidelines

- **Products:** `core-products/` (product-specific context)

## Configuration

See `config.json` for structured configuration details.

## Getting Started

1. Read `AGENTS.md` for canonical agent instructions
2. Follow the Session Startup Order
3. Load the orchestrator before generating any design output
4. Use skills from `SKILLS/` as needed
