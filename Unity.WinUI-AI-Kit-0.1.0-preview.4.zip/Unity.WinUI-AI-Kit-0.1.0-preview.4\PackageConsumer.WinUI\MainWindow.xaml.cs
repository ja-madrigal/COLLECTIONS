using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.Graphics;

namespace PackageConsumer.WinUI;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        AppWindow.Resize(new SizeInt32(1200, 800));
        AppWindow.Move(new PointInt32(100, 100));
        ThemeRoot.RequestedTheme = ElementTheme.Light;
    }

    private void ThemeToggle_Toggled(object sender, RoutedEventArgs e)
    {
        ThemeRoot.RequestedTheme = ((ToggleSwitch)sender).IsOn
            ? ElementTheme.Dark
            : ElementTheme.Light;
    }
}
