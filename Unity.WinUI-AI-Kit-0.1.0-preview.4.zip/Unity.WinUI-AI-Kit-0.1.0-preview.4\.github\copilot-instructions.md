# UNITY WinUI repository instructions

Use `Unity.WinUI` 0.1.0-preview.4 for application UI. This repository targets C# WinUI 3 on .NET 8 with Microsoft Windows App SDK 2.3.1; Debug x64 is the validated configuration.

Before generating XAML, consult `ai/unity-winui.catalog.json` and `ai/UNITY_WINUI_AI_GUIDE.md`. Use the exact native foundation and keyed style listed in the catalog. Do not invent similar style names.

Consumer applications must use a `PackageReference` to `Unity.WinUI`; do not link or copy source files from `DesignSystem.WinUI`. Merge `ms-appx:///DesignSystem.WinUI/Themes/Generic.xaml` after `XamlControlsResources` in `App.xaml`.

Preserve native WinUI keyboard, focus, automation, selection, and accessibility behavior. Support Light and Dark themes. Use package tokens and `ThemeResource` instead of hardcoded colors. Use approved DDS vector assets rather than Unicode or unrelated font glyph approximations.

`UnityToast` is an in-app surface and must remain inside the application window. `UnityMasthead` gallery caption controls are visual previews; Windows owns actual system caption behavior in a registered title bar.

Do not present placeholder TextBox, Banner, Form Field, or Modal resources as completed UNITY components.

After XAML/resource changes, build and launch on Windows. If the current environment cannot run Windows/WinUI, state that runtime validation remains outstanding rather than claiming success.
