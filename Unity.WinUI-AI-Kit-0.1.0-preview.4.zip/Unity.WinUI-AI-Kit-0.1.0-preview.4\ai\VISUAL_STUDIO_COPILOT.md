# Visual Studio Copilot setup

1. Open the consuming WinUI solution or project in Visual Studio.
2. Confirm GitHub Copilot Chat is installed and signed in.
3. Under **Tools > Options**, search for **custom instructions** and enable loading instructions from `.github/copilot-instructions.md`.
4. Keep the repository’s `.github` directory, `AGENTS.md`, and `ai` directory available in the project workspace.
5. Confirm the local/private NuGet source containing `Unity.WinUI.0.1.0-preview.4.nupkg` is enabled.
6. Open Copilot Chat and type `/build-unity-winui-app`.
7. Describe the screen or feature to build.
8. Review the proposed style keys against `ai/unity-winui.catalog.json` before accepting large edits.
9. Build Debug x64 and launch the application.
10. Validate Light/Dark, keyboard, focus, automation, and interaction states.

If the reusable prompt does not appear, attach `.github/prompts/build-unity-winui-app.prompt.md` to Copilot Chat and paste its body manually.

The Copilot response reference list should show `.github/copilot-instructions.md`. If it does not, reopen the solution after enabling custom instructions.
