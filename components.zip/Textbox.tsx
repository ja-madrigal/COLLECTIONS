import { useState } from "react";

type TextboxState = "default" | "hover" | "active" | "invalid" | "watermark" | "selection";

interface TextboxProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  /** invalid = error/validation-failed state per Figma naming */
  invalid?: boolean;
  /** selection = text-highlight state, shown when user selects text */
  showSelection?: boolean;
}

/* ============================================
   State → visual tokens resolver.
   States in priority order:
   active (focused) > hover > invalid > watermark (empty+unfocused) > default
   selection is a special overlay state triggered by showSelection prop.
   NOTE: No disabled state — confirmed absent from Figma.
   NOTE: Active border is #0672cb in light, #f5f6f7 in dark — handled via token.
   ============================================ */
function resolveStyles(state: TextboxState): {
  background: string;
  border: string;
  color: string;
  selectionBg?: string;
} {
  switch (state) {
    case "active":
      return {
        background: "var(--textbox-active-background-active, #ffffff)",
        border: "1px solid var(--textbox-active-border-active, #0672cb)",
        color: "var(--textbox-active-text-active, #0e0e0e)",
      };
    case "hover":
      return {
        background: "var(--textbox-hover-background-hover, #ffffff)",
        border: "1px solid var(--textbox-hover-border-hover, #d2d2d2)",
        color: "var(--textbox-hover-text-hover, #0e0e0e)",
      };
    case "invalid":
      return {
        background: "var(--textbox-invalid-background-invalid, #ffffff)",
        border: "1px solid var(--textbox-invalid-border-invalid, #bb2a33)",
        color: "var(--textbox-invalid-text-invalid, #0e0e0e)",
      };
    case "watermark":
      return {
        background: "var(--textbox-watermark-background-watermark, #ffffff)",
        border: "1px solid var(--textbox-watermark-border-watermark, #e1e1e1)",
        color: "var(--textbox-watermark-text-watermark, #636363)",
      };
    case "selection":
      return {
        background: "var(--textbox-selection-background-selection, #ffffff)",
        border: "1px solid var(--textbox-selection-border-selection, #e1e1e1)",
        color: "var(--textbox-selection-text-selection, #f5f6f7)",
        selectionBg: "var(--textbox-selection-background-highlight, #0672cb)",
      };
    default:
      return {
        background: "var(--textbox-default-background-default, #ffffff)",
        border: "1px solid var(--textbox-default-border-default, #e1e1e1)",
        color: "var(--textbox-default-text-default, #0e0e0e)",
      };
  }
}

const baseTypography: React.CSSProperties = {
  fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
  /* Figma: Button 2 — DDS2 intentionally uses medium weight for input text */
  fontWeight: 500,
  fontSize: "var(--font-button-2-size, 14px)",
  lineHeight: "var(--font-button-2-line-height, 24px)",
  letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
};

export default function Textbox({
  placeholder = "Text",
  value = "",
  onChange,
  invalid = false,
  showSelection = false,
}: TextboxProps) {
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [internal, setInternal] = useState(value);

  // Derive effective state — priority: active > hover > invalid > watermark > default
  const isEmpty = internal.length === 0;
  const effectiveState: TextboxState = showSelection
    ? "selection"
    : focused
    ? "active"
    : hovered
    ? "hover"
    : invalid
    ? "invalid"
    : isEmpty && !focused
    ? "watermark"
    : "default";

  const s = resolveStyles(effectiveState);

  return (
    <div style={{ position: "relative", display: "inline-block", minWidth: 100 }}>
      {/* Selection highlight layer — rendered behind text when showSelection is true */}
      {showSelection && (
        <div
          style={{
            position: "absolute",
            inset: "8px 11px",
            background: s.selectionBg,
            borderRadius: 2,
            pointerEvents: "none",
          }}
        />
      )}
      <input
        type="text"
        value={internal}
        placeholder={placeholder}
        onChange={(e) => {
          setInternal(e.target.value);
          onChange?.(e.target.value);
        }}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          display: "block",
          width: "100%",
          minWidth: 100,
          padding: "8px 11px",
          borderRadius: 4,
          border: s.border,
          background: s.background,
          color: s.color,
          ...baseTypography,
          outline: "none",
          boxSizing: "border-box",
          transition: "border-color 0.15s ease, background 0.15s ease",
          position: "relative",
          zIndex: 1,
          /* Transparent background on input so selection overlay shows through */
          ...(showSelection && { background: "transparent" }),
        }}
      />
    </div>
  );
}
