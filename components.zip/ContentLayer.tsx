import { useState } from "react";

interface ContentLayerProps {
  title?: string;
  bodyText?: string;
  defaultExpanded?: boolean;
  showChevron?: boolean;
}

const ChevronUpIcon = ({ rotated }: { rotated: boolean }) => (
  /* Icon: dds2_chevron-up.svg */
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={{
      transform: rotated ? "rotate(180deg)" : "rotate(0deg)",
      transition: "transform 0.2s ease",
    }}
  >
    <path
      d="M1 11L8 4L15 11"
      stroke="var(--content-layer-title-label, #0e0e0e)"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export default function ContentLayer({
  title = "Title",
  bodyText = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  defaultExpanded = true,
  showChevron = true,
}: ContentLayerProps) {
  const [expanded, setExpanded] = useState(defaultExpanded);

  return (
    <div
      style={{
        minWidth: 250,
        minHeight: 57,
        width: "100%",
        borderRadius: 6,
        background: "var(--content-layer-background, #ffffff99)",
        boxShadow: "0px 4px 60px 12px var(--content-layer-drop-shadow, #0672cb1a)",
        overflow: "hidden",
        boxSizing: "border-box",
      }}
    >
      {/* Header */}
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "16px 20px",
          cursor: "pointer",
        }}
      >
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-header-4-xs-weight, 400)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-header-4-xs-size, 20px)",
            lineHeight: "var(--font-header-4-xs-line-height, 28px)",
            letterSpacing: "var(--font-header-4-xs-letter-spacing, 0px)",
            color: "var(--content-layer-title-label, #0e0e0e)",
            whiteSpace: "nowrap",
          }}
        >
          {title}
        </p>
        {/* Icon: dds2_chevron-up.svg */}
        {showChevron && <ChevronUpIcon rotated={!expanded} />}
      </div>

      {/* Divider — only shown when expanded */}
      {expanded && (
        <div
          style={{
            height: 1,
            background: "var(--content-layer-divider, #0d76b233)",
          }}
        />
      )}

      {/* Body */}
      {expanded && (
        <div style={{ padding: "16px 20px" }}>
          <p
            style={{
              margin: 0,
              fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
              fontWeight: "var(--font-body-2-weight, 400)" as React.CSSProperties["fontWeight"],
              fontSize: "var(--font-body-2-size, 16px)",
              lineHeight: "var(--font-body-2-line-height, 24px)",
              letterSpacing: "var(--font-body-2-letter-spacing, 0.08px)",
              color: "var(--content-layer-content-text, #636363)",
              wordBreak: "break-word",
            }}
          >
            {bodyText}
          </p>
        </div>
      )}
    </div>
  );
}
