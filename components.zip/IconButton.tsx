import { useState } from "react";

interface IconButtonProps {
  /** Accessible label — required since there is no visible text. */
  "aria-label": string;
  disabled?: boolean;
  onClick?: () => void;
  /**
   * Pass any ReactNode to supply the icon. The slot is exactly 20×20px.
   * The icon must accept a `color` prop (string) so the component can drive
   * its fill/stroke token through state changes.
   * Defaults to the dds2_help-cir example icon used in the Figma frame.
   */
  icon?: (color: string) => React.ReactNode;
}

/*
 * Icon: dds2_help-cir.svg
 * Real DDS2 asset inlined from /Users/jam/Projects/COMPONENTS/ICONS-dds2/dds2_help-cir.svg.
 * Original is 16×16 fill-based; scaled to 20×20 via viewBox="0 0 16 16" + width/height=20.
 * Hardcoded fill="#0E0E0E" replaced with the `color` argument so all four
 * states are driven by a single token value.
 * clipPath ID is suffixed to avoid collisions when multiple instances render
 * on the same page. Claude Code will replace this inline SVG with a proper
 * import from /Users/jam/Projects/COMPONENTS/ICONS-dds2/ at Storybook handoff.
 *
 * NOTE on disabled structure: Figma's disabled variant has two token bindings
 * (Icon-button/disabled/Icon and Icon-button/disabled/Stroke) for the inner
 * mark and the outer circle ring respectively. Both resolve to the same hex in
 * both themes (#b6b6b6 light / #636363 dark), so a single `color` value
 * applied to all paths covers both. They are kept as separate tokens in
 * tokens.css in case they ever diverge.
 */
let _iconButtonId = 0;
const HelpCircleIcon = (color: string) => {
  const id = `ib-clip-${++_iconButtonId}`;
  return (
    <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clipPath={`url(#${id})`}>
        <path d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346625 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C16 5.87827 15.1571 3.84344 13.6569 2.34315C12.1566 0.842855 10.1217 0 8 0ZM8 14.93C6.62938 14.93 5.28953 14.5236 4.1499 13.7621C3.01027 13.0006 2.12203 11.9183 1.59752 10.652C1.073 9.3857 0.935766 7.99231 1.20316 6.64802C1.47056 5.30374 2.13058 4.06893 3.09975 3.09975C4.06893 2.13057 5.30374 1.47055 6.64803 1.20316C7.99232 0.935762 9.38571 1.073 10.652 1.59751C11.9183 2.12203 13.0006 3.01027 13.7621 4.1499C14.5236 5.28953 14.93 6.62938 14.93 8C14.9274 9.83714 14.1964 11.5983 12.8973 12.8973C11.5983 14.1964 9.83714 14.9274 8 14.93Z" fill={color}/>
        <path d="M10 3.87C9.73416 3.66086 9.43262 3.50162 9.11 3.4C8.75046 3.28867 8.37638 3.23138 8 3.23C7.57712 3.22109 7.15637 3.29235 6.76 3.44C6.4255 3.55234 6.12344 3.74456 5.88 4C5.64426 4.2555 5.46683 4.55917 5.36 4.89C5.21986 5.30137 5.16209 5.73631 5.19 6.17H6.47C6.43485 5.69962 6.55044 5.23027 6.8 4.83C6.94975 4.66487 7.13677 4.53789 7.34549 4.45962C7.55421 4.38135 7.7786 4.35406 8 4.38C8.24785 4.3745 8.49479 4.41171 8.73 4.49C8.90792 4.5533 9.0712 4.65195 9.21 4.78C9.3254 4.89433 9.41121 5.03506 9.46 5.19C9.51156 5.3414 9.53856 5.50007 9.54 5.66C9.5461 5.86461 9.51213 6.06843 9.44 6.26C9.37926 6.42661 9.29141 6.58203 9.18 6.72C9.06009 6.87219 8.92617 7.01281 8.78 7.14L8.26 7.58C8.08507 7.7241 7.92127 7.88122 7.77 8.05C7.64731 8.19301 7.54316 8.35092 7.46 8.52C7.3752 8.69694 7.31787 8.88578 7.29 9.08C7.2681 9.34956 7.2681 9.62044 7.29 9.89H8.51C8.50769 9.68178 8.5278 9.47391 8.57 9.27C8.60147 9.13041 8.65915 8.99806 8.74 8.88C8.82867 8.74811 8.93273 8.62726 9.05 8.52C9.18 8.4 9.34 8.26 9.54 8.1C9.74 7.94 9.9 7.78 10.06 7.62C10.2124 7.46954 10.3467 7.30173 10.46 7.12C10.5746 6.92621 10.6621 6.71759 10.72 6.5C10.7938 6.22631 10.8275 5.94336 10.82 5.66C10.8208 5.31564 10.7492 4.97496 10.61 4.66C10.4767 4.34935 10.2668 4.07755 10 3.87Z" fill={color}/>
        <path d="M7.24 11.49H8.52V12.77H7.24V11.49Z" fill={color}/>
      </g>
      <defs>
        <clipPath id={id}>
          <rect width="16" height="16" fill="white"/>
        </clipPath>
      </defs>
    </svg>
  );
};

function resolveColor(disabled: boolean, hovered: boolean, pressed: boolean): string {
  if (disabled) return "var(--icon-button-disabled-icon, #b6b6b6)";
  if (pressed)  return "var(--icon-button-pressed-icon, #7e7e7e)";
  if (hovered)  return "var(--icon-button-hover-icon, #636363)";
  return "var(--icon-button-icon-default, #0e0e0e)";
}

export default function IconButton({
  "aria-label": ariaLabel,
  disabled = false,
  onClick,
  icon = HelpCircleIcon,
}: IconButtonProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const color = resolveColor(disabled, hovered, pressed);

  return (
    <button
      aria-label={ariaLabel}
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => !disabled && setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => !disabled && setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: 20,
        height: 20,
        padding: 0,
        margin: 0,
        background: "none",
        border: "none",
        cursor: disabled ? "not-allowed" : "pointer",
        // No outline here — rely on browser focus-visible; add a custom
        // focus ring at the application level if needed.
        flexShrink: 0,
      }}
    >
      {icon(color)}
    </button>
  );
}
