interface ProgressBarProps {
  value?: number; // 0–100
  width?: number | string;
}

export default function ProgressBar({ value = 0, width = 281 }: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, value));

  return (
    <div
      style={{
        position: "relative",
        height: 6,
        width: typeof width === "number" ? `${width}px` : width,
        background: "var(--progress-bar-background-color, #c5d4e3)",
        borderRadius: 3,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          height: "100%",
          width: `${clamped}%`,
          background: "var(--progress-bar-bar-color, #a4b8cd)",
          borderRadius: 3,
          transition: "width 0.3s ease",
        }}
      />
    </div>
  );
}
