interface BusyIndicatorProps {
  size?: number;
  variant?: "spinner" | "dots";
}

const Spinner = ({ size }: { size: number }) => (
  <>
    <style>{`
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      .busy-indicator-ring { animation: spin 0.8s linear infinite; }
    `}</style>
    <svg
      className="busy-indicator-ring"
      width={size}
      height={size}
      viewBox="0 0 26 26"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        cx="13" cy="13" r="10"
        stroke="var(--busy-indicator-spinner-background, #0063b8)"
        strokeWidth="3"
        strokeOpacity="0.2"
      />
      <path
        d="M13 3 A10 10 0 0 1 23 13"
        stroke="var(--busy-indicator-spinner-background, #0063b8)"
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  </>
);

const Dots = ({ size }: { size: number }) => {
  const dots = [
    { angle: 270, token: "--busy-indicator-loaderdots-1st", fallback: "#0e0e0e" },
    { angle: 321, token: "--busy-indicator-loaderdots-2nd", fallback: "#0e0e0ed9" },
    { angle: 12,  token: "--busy-indicator-loaderdots-3rd", fallback: "#0e0e0eb2" },
    { angle: 63,  token: "--busy-indicator-loaderdots-4th", fallback: "#0e0e0e99" },
    { angle: 114, token: "--busy-indicator-loaderdots-5th", fallback: "#0e0e0e80" },
    { angle: 165, token: "--busy-indicator-loaderdots-6th", fallback: "#0e0e0e59" },
    { angle: 216, token: "--busy-indicator-loaderdots-7th", fallback: "#0e0e0e33" },
  ];

  const r = size * 0.36;
  const cx = size / 2;
  const cy = size / 2;
  const dotR = size * 0.07;

  return (
    <>
      <style>{`
        @keyframes dots-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        .busy-indicator-dots { animation: dots-spin 1s linear infinite; }
      `}</style>
      <svg
        className="busy-indicator-dots"
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {dots.map((dot, i) => {
          const rad = (dot.angle * Math.PI) / 180;
          const x = cx + r * Math.cos(rad);
          const y = cy + r * Math.sin(rad);
          return (
            <circle
              key={i}
              cx={x}
              cy={y}
              r={dotR}
              fill={`var(${dot.token}, ${dot.fallback})`}
            />
          );
        })}
      </svg>
    </>
  );
};

export default function BusyIndicator({ size = 26, variant = "spinner" }: BusyIndicatorProps) {
  return (
    <div
      style={{
        width: size,
        height: size,
        position: "relative",
        display: "inline-block",
      }}
    >
      {variant === "spinner" ? <Spinner size={size} /> : <Dots size={size} />}
    </div>
  );
}
