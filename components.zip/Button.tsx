import { useState } from "react";

type ButtonHierarchy = "primary" | "secondary" | "tertiary" | "destructive";
type ButtonSize = "small" | "base" | "large";

interface ButtonProps {
  label?: string;
  hierarchy?: ButtonHierarchy;
  size?: ButtonSize;
  onClick?: () => void;
  /** Disabled is unavailable for the "destructive" hierarchy — Figma has no
   *  disabled state defined for Destructive buttons. The type system below
   *  prevents passing disabled=true when hierarchy="destructive". */
  disabled?: boolean;
  leadingIcon?: boolean;
  trailingIcon?: boolean;
  /** Optional overrides — pass any ReactNode to replace the default DDS2
   *  arrow icon, mirroring Figma's selectLeadingIcon / selectTrailingIcon slots. */
  leadingIconSvg?: React.ReactNode;
  trailingIconSvg?: React.ReactNode;
  /** Hides the label text — useful for icon-only buttons (still requires at
   *  least one of leadingIcon/trailingIcon to be true to render anything). */
  showLabel?: boolean;
}

/* Icon: dds2_arrow-left.svg
   Placeholder generic arrow path — replace with the real DDS2 asset from
   /Users/jam/Projects/COMPONENTS/ICONS-dds2/dds2_arrow-left.svg at Storybook handoff. */
const ArrowLeftIcon = ({ color }: { color: string }) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M13 8H3M3 8L7.5 3.5M3 8L7.5 12.5"
      stroke={color}
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* Icon: dds2_arrow-right.svg
   Placeholder generic arrow path — replace with the real DDS2 asset from
   /Users/jam/Projects/COMPONENTS/ICONS-dds2/dds2_arrow-right.svg at Storybook handoff. */
const ArrowRightIcon = ({ color }: { color: string }) => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M3 8H13M13 8L8.5 3.5M13 8L8.5 12.5"
      stroke={color}
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ============================================
   Size tokens — layout only, colors unaffected.
   Small uses Button 3 typography; Base and Large both use Button 2.
   ============================================ */
const sizeStyles: Record<
  ButtonSize,
  {
    height: string;
    padding: string;
    gap: string;
    radius: string;
    fontSize: string;
    lineHeight: string;
    letterSpacing: string;
    iconSize: number;
  }
> = {
  small: {
    height: "var(--button-size-small-height, 24px)",
    padding: "var(--button-size-small-padding, 2px 6px)",
    gap: "var(--button-size-small-gap, 4px)",
    radius: "var(--button-size-small-radius, 4px)",
    fontSize: "var(--font-button-3-size, 12px)",
    lineHeight: "var(--font-button-3-line-height, 20px)",
    letterSpacing: "var(--font-button-3-letter-spacing, 0.06px)",
    iconSize: 16,
  },
  base: {
    height: "var(--button-size-default-height, 40px)",
    padding: "var(--button-size-default-padding, 8px 12px)",
    gap: "var(--button-size-default-gap, 10px)",
    radius: "var(--button-size-default-radius, 2px)",
    fontSize: "var(--font-button-2-size, 14px)",
    lineHeight: "var(--font-button-2-line-height, 24px)",
    letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
    iconSize: 16,
  },
  large: {
    height: "var(--button-size-large-height, 48px)",
    padding: "var(--button-size-large-padding, 8px 18px)",
    gap: "var(--button-size-large-gap, 10px)",
    radius: "var(--button-size-large-radius, 2px)",
    fontSize: "var(--font-button-2-size, 14px)",
    lineHeight: "var(--font-button-2-line-height, 24px)",
    letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
    iconSize: 16,
  },
};

/* ============================================
   Hierarchy + state → background / label / border resolver.
   Hover and pressed are driven by real pointer interaction, not props.
   ============================================ */
function getVisualState(
  hierarchy: ButtonHierarchy,
  disabled: boolean,
  hovered: boolean,
  pressed: boolean
): { background: string; color: string; border: string } {
  if (disabled) {
    switch (hierarchy) {
      case "primary":
        return {
          background: "var(--button-primary-background-disabled, #b6b6b6cc)",
          color: "var(--button-primary-label-disabled, #f5f6f7cc)",
          border: "none",
        };
      case "secondary":
        return {
          background: "transparent",
          color: "var(--button-secondary-label-disabled, #b6b6b6)",
          border: "1px solid var(--button-secondary-border-disabled, #636363)",
        };
      case "tertiary":
        return {
          background: "var(--button-tertiary-background-default, #ffffff00)",
          color: "var(--button-tertiary-label-disabled, #b6b6b6)",
          border: "none",
        };
      case "destructive":
        // No disabled state exists for Destructive in Figma — falls through
        // to default visuals. The disabled prop is type-blocked for this
        // hierarchy (see ButtonProps), so this path should be unreachable
        // in normal usage.
        break;
    }
  }

  switch (hierarchy) {
    case "primary":
      return {
        background: pressed
          ? "var(--button-primary-background-pressed, #00468b)"
          : hovered
          ? "var(--button-primary-background-hover, #0063b8)"
          : "var(--button-primary-background-default, #0672cb)",
        color: "var(--button-primary-label-default, #f5f6f7)",
        border: "none",
      };
    case "secondary":
      return {
        background: pressed
          ? "var(--button-secondary-background-pressed, #94dcf7)"
          : hovered
          ? "var(--button-secondary-background-hover, #d9f5fd)"
          : "transparent",
        color: "var(--button-secondary-label-default, #0063b8)",
        border: `1px solid ${
          pressed
            ? "var(--button-secondary-border-pressed, #00468b)"
            : "var(--button-secondary-border-default, #0063b8)"
        }`,
      };
    case "tertiary":
      return {
        background: pressed
          ? "var(--button-tertiary-background-pressed, #94dcf7)"
          : hovered
          ? "var(--button-tertiary-background-hover, #d9f5fd)"
          : "var(--button-tertiary-background-default, #ffffff00)",
        color: "var(--button-tertiary-label-default, #0063b8)",
        border: "none",
      };
    case "destructive":
      return {
        background: pressed
          ? "var(--button-destructive-background-pressed, #8c161f)"
          : hovered
          ? "var(--button-destructive-background-hover, #bb2a33)"
          : "var(--button-destructive-background-default, #d0353f)",
        color: "var(--button-destructive-label, #f5f6f7)",
        border: "none",
      };
  }
}

export default function Button({
  label = "Button",
  hierarchy = "primary",
  size = "base",
  onClick,
  disabled = false,
  leadingIcon = false,
  trailingIcon = false,
  leadingIconSvg,
  trailingIconSvg,
  showLabel = true,
}: ButtonProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  // Destructive has no disabled state in Figma — never let it visually disable.
  const effectiveDisabled = hierarchy === "destructive" ? false : disabled;

  const dims = sizeStyles[size];
  const visual = getVisualState(hierarchy, effectiveDisabled, hovered, pressed);

  return (
    <button
      onClick={effectiveDisabled ? undefined : onClick}
      disabled={effectiveDisabled}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setPressed(false);
      }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: dims.gap,
        height: dims.height,
        padding: dims.padding,
        borderRadius: dims.radius,
        cursor: effectiveDisabled ? "not-allowed" : "pointer",
        fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
        // Button 2 and Button 3 weight tokens are both 500 — safe to share
        // one token here since fontFamily/fontWeight aren't size-dependent
        // the way fontSize/lineHeight/letterSpacing are (see sizeStyles).
        fontWeight: "var(--font-button-2-weight, 500)" as React.CSSProperties["fontWeight"],
        fontSize: dims.fontSize,
        lineHeight: dims.lineHeight,
        letterSpacing: dims.letterSpacing,
        whiteSpace: "nowrap",
        boxSizing: "border-box",
        background: visual.background,
        color: visual.color,
        border: visual.border,
        transition: "background-color 0.15s ease, border-color 0.15s ease",
      }}
    >
      {leadingIcon &&
        (leadingIconSvg ?? <ArrowLeftIcon color={visual.color} />)}
      {showLabel && <span>{label}</span>}
      {trailingIcon &&
        (trailingIconSvg ?? <ArrowRightIcon color={visual.color} />)}
    </button>
  );
}
