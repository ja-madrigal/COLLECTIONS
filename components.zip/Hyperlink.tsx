import { useState } from "react";

interface HyperlinkProps {
  text?: string;
  href?: string;
  /** Whether the link renders with an underline — matches Figma's
   *  "Button 2/underlined" font style variant. */
  underline?: boolean;
  disabled?: boolean;
  /** Mark as visited — intentionally renders same color as default
   *  in both light and dark mode per Figma token values. */
  visited?: boolean;
  onClick?: () => void;
}

export default function Hyperlink({
  text = "Hyperlink",
  href = "#",
  underline = false,
  disabled = false,
  visited = false,
  onClick,
}: HyperlinkProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  // Resolve color — hover and pressed share the same color per Figma;
  // underline treatment is the only visual differentiator between those two states.
  const color = disabled
    ? "var(--hyperlink-text-disabled, #0672cb66)"
    : pressed
    ? "var(--hyperlink-text-pressed, #00468b)"
    : hovered
    ? "var(--hyperlink-text-hover, #00468b)"
    : visited
    ? "var(--hyperlink-text-visited, #0063b8)"
    : "var(--hyperlink-text-default, #0063b8)";

  // Underline: always shown on hover/pressed per Figma's underlined style variant,
  // plus when the underline prop is explicitly set.
  const textDecoration =
    disabled ? "none" : underline || hovered || pressed ? "underline" : "none";

  return (
    <a
      href={disabled ? undefined : href}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => !disabled && setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => !disabled && setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
        fontWeight: 500 as React.CSSProperties["fontWeight"],
        fontSize: "var(--font-button-2-size, 14px)",
        lineHeight: "var(--font-button-2-line-height, 24px)",
        letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
        color,
        textDecoration,
        borderRadius: 2,
        cursor: disabled ? "not-allowed" : "pointer",
        whiteSpace: "nowrap",
        transition: "color 0.15s ease",
        pointerEvents: disabled ? "none" : "auto",
      }}
    >
      {text}
    </a>
  );
}
