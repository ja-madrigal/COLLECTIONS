import { useState } from "react";

interface ScaleControlProps {
  min?: number;
  max?: number;
  value?: number | null;
  onChange?: (value: number) => void;
}

type ItemState = "default" | "hover" | "selected" | "pressed";

interface ScaleItemProps {
  label: number;
  selected: boolean;
  onClick: () => void;
}

const ScaleItem = ({ label, selected, onClick }: ScaleItemProps) => {
  const [hover, setHover] = useState(false);
  const [pressed, setPressed] = useState(false);

  let background = "transparent";
  let color = "var(--scale-control-text-default, #0e0e0e)";
  let borderColor = "var(--scale-control-border-default, #40586d)";

  if (selected && pressed) {
    background = "var(--scale-control-background-pressed, #00468b)";
    color = "var(--scale-control-text-pressed, #f5f6f7)";
    borderColor = "var(--scale-control-background-pressed, #00468b)";
  } else if (selected) {
    background = "var(--scale-control-background-selected, #0672cb)";
    color = "var(--scale-control-text-selected, #f5f6f7)";
    borderColor = "var(--scale-control-background-selected, #0672cb)";
  } else if (pressed) {
    background = "var(--scale-control-background-pressed, #00468b)";
    color = "var(--scale-control-text-pressed, #f5f6f7)";
    borderColor = "var(--scale-control-background-pressed, #00468b)";
  } else if (hover) {
    color = "var(--scale-control-text-hover, #0063b8)";
    borderColor = "var(--scale-control-border-hover, #0063b8)";
  }

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        width: 28,
        height: 28,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        border: `1px solid ${borderColor}`,
        borderRadius: "50%",
        cursor: "pointer",
        boxSizing: "border-box",
        background,
        transition: "background 0.1s ease, color 0.1s ease, border-color 0.1s ease",
        flexShrink: 0,
          marginRight: -1,
      }}
    >
      <p
        style={{
          margin: 0,
          fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
          fontWeight: "var(--font-body-2-weight, 400)" as React.CSSProperties["fontWeight"],
          fontSize: "var(--font-body-2-size, 16px)",
          lineHeight: "var(--font-body-2-line-height, 24px)",
          letterSpacing: "var(--font-body-2-letter-spacing, 0.08px)",
          textAlign: "center",
          color,
          transition: "color 0.1s ease",
          userSelect: "none",
        }}
      >
        {label}
      </p>
    </div>
  );
};

export default function ScaleControl({
  min = 0,
  max = 10,
  value = null,
  onChange,
}: ScaleControlProps) {
  const [selected, setSelected] = useState<number | null>(value);

  const handleClick = (v: number) => {
    setSelected(v);
    onChange?.(v);
  };

  const steps = Array.from({ length: max - min + 1 }, (_, i) => min + i);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 0,
        marginRight: -1,
        borderRadius: "50%",
        
      }}
    >
      {steps.map((step) => (
        <ScaleItem
          key={step}
          label={step}
          selected={selected === step}
          onClick={() => handleClick(step)}
        />
      ))}
    </div>
  );
}
