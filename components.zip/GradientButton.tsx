import { useState } from "react";

interface GradientButtonProps {
  label?: string;
  /** Pass any ReactNode to replace the default brightness icon (25×25px). */
  icon?: React.ReactNode;
  selected?: boolean;
  onClick?: () => void;
}

/*
 * GRADIENT NOTES — two named Figma styles, neither tokenized via variables:
 *
 * "Gradient button" fill (selected state):
 *   linear-gradient(119deg, #0672cb 0%, #0078d4 0%, #6e69cf 100%)
 *   (Two stops at pos 0 — the first snaps immediately to the second, creating
 *    a clean blue-to-purple sweep. Verbatim from Figma's gradient stops.)
 *
 * "Gradient stroke" border (hover + selected states):
 *   linear-gradient(120deg, #55b4fd 0%, #6e69cf 100%)
 *
 * Default border (solid, tokenized):
 *   light → #e1e1e1  (--button-gradient-border)
 *   dark  → #214370  (--button-gradient-border)
 *
 * CSS GRADIENT-BORDER TECHNIQUE:
 * CSS border doesn't support gradient strokes natively. We use a single
 * background with two layers — padding-box clips the inner fill, border-box
 * exposes the border layer underneath. Applied in ALL states (including
 * default) so the border mechanism never changes and there's no layout jump.
 *
 * Stroke is 1.5px inside in Figma — border-box sizing matches this exactly.
 */

const GRADIENT_FILL   = "linear-gradient(119deg, #0672cb 0%, #0078d4 0%, #6e69cf 100%)";
const GRADIENT_STROKE = "linear-gradient(120deg, #55b4fd 0%, #6e69cf 100%)";

/* Icon: dds2_brightness.svg
   Placeholder sun/brightness path — replace with the real DDS2 asset from
   /Users/jam/Projects/COMPONENTS/ICONS-dds2/dds2_brightness.svg at Storybook handoff. */
const BrightnessIcon = ({ color }: { color: string }) => (
  <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12.5" cy="12.5" r="4" stroke={color} strokeWidth="1.5" />
    <path
      d="M12.5 3.5V5.5M12.5 19.5V21.5M3.5 12.5H5.5M19.5 12.5H21.5M6.43 6.43L7.84 7.84M17.16 17.16L18.57 18.57M18.57 6.43L17.16 7.84M7.84 17.16L6.43 18.57"
      stroke={color}
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

function resolveBackground(
  selected: boolean,
  hovered: boolean
): { background: string; iconColor: string; labelColor: string } {
  // The inner fill layer (padding-box) and border layer (border-box) are always
  // composed together. Default border uses a solid color expressed as a gradient
  // (two identical stops) so the background property shape never changes.
  if (selected) {
    return {
      background: `${GRADIENT_FILL} padding-box, ${GRADIENT_STROKE} border-box`,
      iconColor: "var(--button-gradient-label-selected, #f5f6f7)",
      labelColor: "var(--button-gradient-label-selected, #f5f6f7)",
    };
  }
  // Inner fill: the background-color token, expressed as a gradient layer
  const innerFill = "var(--button-gradient-background, #ffffff)";
  const innerFillLayer = `linear-gradient(${innerFill}, ${innerFill}) padding-box`;

  if (hovered) {
    return {
      background: `${innerFillLayer}, ${GRADIENT_STROKE} border-box`,
      iconColor: "var(--button-gradient-icon, #0063b8)",
      labelColor: "var(--button-gradient-label, #0e0e0e)",
    };
  }
  // Default — solid border expressed as a degenerate gradient so the CSS
  // background property never structurally changes between states.
  const defaultBorder = `linear-gradient(var(--button-gradient-border, #e1e1e1), var(--button-gradient-border, #e1e1e1)) border-box`;
  return {
    background: `${innerFillLayer}, ${defaultBorder}`,
    iconColor: "var(--button-gradient-icon, #0063b8)",
    labelColor: "var(--button-gradient-label, #0e0e0e)",
  };
}

export default function GradientButton({
  label = "Bright",
  icon,
  selected = false,
  onClick,
}: GradientButtonProps) {
  const [hovered, setHovered] = useState(false);
  const s = resolveBackground(selected, hovered);

  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "inline-flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 13,
        width: 324,
        height: 100,
        padding: "16px",
        borderRadius: 4,
        boxSizing: "border-box",
        overflow: "hidden",
        cursor: "pointer",
        // border must be transparent — the gradient border-box layer shows through it
        border: "1.5px solid transparent",
        background: s.background,
        transition: "background 0.2s ease",
      }}
    >
      <span style={{ width: 25, height: 25, flexShrink: 0, display: "flex" }}>
        {icon ?? <BrightnessIcon color={s.iconColor} />}
      </span>
      <span
        style={{
          fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
          fontWeight: "var(--font-button-1-weight, 500)" as React.CSSProperties["fontWeight"],
          fontSize: "var(--font-button-1-size, 16px)",
          lineHeight: "var(--font-button-1-line-height, 24px)",
          letterSpacing: "var(--font-button-1-letter-spacing, 0.08px)",
          color: s.labelColor,
          whiteSpace: "nowrap",
          textAlign: "center",
          transition: "color 0.2s ease",
        }}
      >
        {label}
      </span>
    </button>
  );
}
