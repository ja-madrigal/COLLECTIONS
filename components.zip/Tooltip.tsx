interface TooltipProps {
  title?: string;
  body?: string;
  showTitle?: boolean;
}

export default function Tooltip({
  title = "Title",
  body = "Lorem ipsum enim tristique morbi arcu non eget ut nam egestas",
  showTitle = true,
}: TooltipProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 4,
        alignItems: "flex-start",
        minWidth: 110,
        maxWidth: 450,
        width: 312,
        minHeight: 52,
        padding: "16px 12px",
        borderRadius: 4,
        border: "1px solid var(--tooltip-border, #e1e1e1)",
        background: "var(--tooltip-background, #ffffff)",
        boxShadow: "0px 2px 2px 0px rgba(0,0,0,0.14), 0px 4px 4px 0px rgba(0,0,0,0.18)",
        boxSizing: "border-box",
        wordBreak: "break-word",
      }}
    >
      {/* Title — Caption/Strong: 12px/700/20lh — no token in scale, uses --font-caption-strong-* */}
      {showTitle && (
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-caption-strong-weight, 700)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-caption-strong-size, 12px)",
            lineHeight: "var(--font-caption-strong-line-height, 20px)",
            letterSpacing: "var(--font-caption-strong-letter-spacing, 0.18px)",
            color: "var(--tooltip-text, #0e0e0e)",
            whiteSpace: "nowrap",
          }}
        >
          {title}
        </p>
      )}

      {/* Body */}
      <p
        style={{
          margin: 0,
          fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
          fontWeight: "var(--font-caption-weight, 400)" as React.CSSProperties["fontWeight"],
          fontSize: "var(--font-caption-size, 12px)",
          lineHeight: "var(--font-caption-line-height, 20px)",
          letterSpacing: "var(--font-caption-letter-spacing, 0.06px)",
          color: "var(--tooltip-text, #0e0e0e)",
        }}
      >
        {body}
      </p>
    </div>
  );
}
