# DDS2 Unity Component Library — Agent Reference

**Stack:** React TSX + plain HTML/CSS, shared `tokens.css` (`:root` light / `[data-theme="dark"]` dark)  
**Figma file:** `8TipUKvce0k9JPezXvpGrP` (Unity Component Library)  
**Icons directory:** `/Users/jam/Projects/COMPONENTS/ICONS-dds2/`  
**Typography:** All Roboto. Every font property — size, line-height, letter-spacing, weight — uses `var(--font-*-*)` tokens. Never hardcode.  
**Dark mode:** Set `data-theme="dark"` on the wrapper `<div>`. Tokens resolve automatically.

---

## Conventions

- All colors via `var(--token-name, fallback)` — never hardcode hex values
- All typography via `var(--font-*-*)` tokens — never hardcode numbers including font-weight
- SVG icons inlined, fill/stroke driven by token color prop
- Each component is a separate `.tsx` + `.html` file pair
- `tokens.css` is shared — append new tokens to `:root` (light) and `[data-theme="dark"]` (dark)

---

## Atoms

### Button
**File:** `Button.tsx` / `Button.html`  
**Props:** `hierarchy` ("primary" | "secondary" | "tertiary" | "destructive"), `size` ("small" | "base" | "large"), `disabled`, `leadingIcon`, `trailingIcon`, `label`, `onClick`  
**States:** Default, Hover, Pressed, Disabled  
**Notes:** Destructive has no disabled state (Figma mislabeled — binds to Tertiary tokens, do not use). Secondary disabled has a border. Tertiary disabled is borderless. Small uses Button 3 typography (12px), Base/Large use Button 2 (14px). Small border-radius is 4px vs 2px for Base/Large.  
**Key tokens:** `--button-primary-background-default/hover/pressed/disabled`, `--button-secondary-*`, `--button-tertiary-*`, `--button-destructive-*`, `--button-primary-label-default/disabled`

---

### ProgressButton
**File:** `ProgressButton.tsx` / `ProgressButton.html`  
**Props:** `idleLabel`, `installingLabel`, `downloadingLabel`, `progress` ("idle" | "installing" | "downloading"), `disabled`, `onClick`  
**States:** Default, Hover, Pressed, Disabled, Installing (spinner), Downloading (spinner)  
**Size:** 154px min-width × 40px height. Typography: Button 2 (14px / 500wt).  
**Notes:** Busy state wins over disabled if both are set. HTML uses `aria-disabled` (not `disabled` attribute) on busy buttons to avoid CSS specificity conflict with the disabled rule.  
**Key tokens:** `--button-progress-background`, `--button-progress-label` (plus all `--button-primary-*` tokens)

---

### RadioButton
**File:** `RadioButton.tsx` / `RadioButton.html`  
**Props:** `label`, `selected`, `name`, `value`, `onChange`  
**States:** Rest, Hover, Pressed × Unselected/Selected (6 variants). No disabled state in Figma.  
**Size:** 20×20px circle, 1.5px border on unselected, 8px inner dot on selected.  
**Key tokens:** `--radio-button-background-default-unselected`, `--radio-button-border-rest/hover/pressed-unselected`, `--radio-button-background-rest/hover/pressed-selected`, `--radio-button-fill-inner-selected`, `--radio-button-text-default`

---

### GradientButton
**File:** `GradientButton.tsx` / `GradientButton.html`  
**Props:** `label`, `icon` (ReactNode), `selected`, `onClick`  
**States:** Default, Hover, Selected  
**Size:** 324×100px. Layout: column (icon stacked above label), 13px gap between bounding boxes.  
**Notes:** Gradient fill and gradient stroke are Figma named styles — NOT tokenized. Hardcoded CSS literals in both files. Uses `border: 1.5px solid transparent` + `background padding-box/border-box` composite in ALL states to prevent layout jump. Fill: `linear-gradient(119deg, #0672cb 0%, #0078d4 0%, #6e69cf 100%)`. Border (hover+selected): `linear-gradient(120deg, #55b4fd 0%, #6e69cf 100%)`. Typography: Button 1 (16px / 500wt).  
**Key tokens:** `--button-gradient-background`, `--button-gradient-border`, `--button-gradient-icon`, `--button-gradient-label`, `--button-gradient-label-selected`

---

### IconButton
**File:** `IconButton.tsx` / `IconButton.html`  
**Props (TSX):** `aria-label` (required), `disabled`, `onClick`, `icon` (render function `(color: string) => ReactNode`)  
**States:** Default, Hover, Pressed, Disabled  
**Size:** 20×20px. No background, no border, no padding — color-only state changes.  
**Notes:** Icon prop is a render function so the component drives fill color through all states. Default placeholder icon is `dds2_help-cir.svg` (fill-based, not stroked). `aria-label` is required — no visible text.  
**Key tokens:** `--icon-button-icon-default`, `--icon-button-hover-icon`, `--icon-button-pressed-icon`, `--icon-button-disabled-icon`

---

### Checkbox
**File:** `Checkbox.tsx` / `Checkbox.html`  
**Props:** `label`, `checked`, `state` (overrides internal), `error`, `disabled`, `onChange`  
**States:** Default, Hover, Pressed, Disabled × Unchecked/Checked/Indeterminate, plus Error variants. No error+disabled state in Figma.  
**Key tokens:** `--checkbox-default-box-background-default/checked/disabled`, `--checkbox-default-border-default/disabled`, `--checkbox-error-border-error-default`, `--checkbox-default-icon-checked`

---

### Hyperlink
**File:** `Hyperlink.tsx` / `Hyperlink.html`  
**Props:** `label`, `href`, `visited`, `disabled`, `underline`, `onClick`  
**States:** Default, Hover, Pressed, Visited, Disabled  
**Key tokens:** `--hyperlink-text-default/hover/pressed/visited/disabled`

---

### ToggleSwitch
**File:** `ToggleSwitch.tsx` / `ToggleSwitch.html`  
**Props:** `checked`, `disabled`, `label`, `onChange`  
**States:** Off (Default/Hover/Pressed), On (Default/Hover/Pressed), Disabled  
**Notes:** Off-state background is invariant across hover/pressed — only on-state shifts through blue progression.  
**Key tokens:** `--toggle-off-background-default/hover/pressed`, `--toggle-on-background-default/hover/pressed`, `--toggle-off-thumb-default/hover/pressed`, `--toggle-background-disabled`

---

### Textbox
**File:** `Textbox.tsx` / `Textbox.html`  
**Props:** `value`, `placeholder`, `state` ("default" | "hover" | "active" | "invalid" | "watermark" | "selection"), `showSelection`, `label`, `onChange`  
**States:** Default, Hover, Active, Invalid, Watermark, Selection. No disabled state in Figma.  
**Notes:** Active border is `#0672cb` light, `#f5f6f7` dark. Selection is a special overlay state.  
**Key tokens:** `--textbox-default-background/border/text-default`, `--textbox-hover-*`, `--textbox-active-*`, `--textbox-invalid-*`

---

### Slider
**File:** `Slider.tsx` / `Slider.html`  
**Props:** `type` ("default" | "handle" | "tooltip-top" | "tooltip-bot" | "double"), `value`, `valueMin`, `valueMax`, `min`, `max`, `disabled`, `width`, `onChange`, `onChangeRange`  
**Types:** Default (progress bar, no thumb), Handle (single thumb), Tooltip-top (label above), Tooltip-bot (label below), Double (range, two thumbs)  
**Anatomy:** Track 4px tall, thumb 14×14px solid circle. No border or shadow on thumb — confirmed Figma. Tooltip text uses `--font-body-3-*` (14px / 400wt).  
**Key tokens:** `--slider-track`, `--slider-progress`

---

### BusyIndicator
**File:** `BusyIndicator.tsx` / `BusyIndicator.html`  
**Props:** `size`, `label`  
**Notes:** Animated spinner. Used internally by ProgressButton.  
**Key tokens:** `--busy-indicator-spinner-background`

---

### ProgressBar
**File:** `ProgressBar.tsx` / `ProgressBar.html`  
**Props:** `value` (0–100), `label`  
**Key tokens:** `--progress-bar-background-color`, `--progress-bar-bar-color`

---

### Scrollbar
**File:** `Scrollbar.tsx` / `Scrollbar.html`  
**Props:** `orientation`, `scrollPosition`  
**Key tokens:** `--scrollbar-track`, `--scrollbar-thumb`

---

## Molecules

### MenuItem
**File:** `MenuItem.tsx` / `MenuItem.html`  
**Props:** `label`, `selected`, `disabled`, `leadingIcon`, `trailingIcon`, `onClick`  
**States:** Default, Hover, Selected, Disabled  
**Key tokens:** `--menu-items-label`, `--menu-items-background-hover`, `--menu-items-text-hover`, `--menu-items-label-disabled`

---

### DropdownMenu
**File:** `DropdownMenu.tsx` / `DropdownMenu.html`  
**Props:** `items`, `selectedIndex`, `placeholder`, `onSelect`  
**Notes:** Shadow is `0px 4px 4px 0px rgba(0,42,88,0.08)` — identical in light and dark, not tokenized.  
**Key tokens:** `--menu-items-background`, `--menu-items-field-border-default/selected`, `--menu-items-label`, `--menu-items-label-disabled`

---

### Hyperlink (see Atoms above)

### TextExpander
**File:** `TextExpander.tsx` / `TextExpander.html`  
**Props:** `label`, `expanded`, `onToggle`  
**Key tokens:** `--content-layer-trigger-label`

---

### Toast
**File:** `Toast.tsx` / `Toast.html`  
**Props:** `message`, `type` ("info" | "success" | "warning" | "error"), `onClose`  
**Notes:** Shadow `0px 4px 4px 0px rgba(0,0,0,0.04), 0px 2px 2px 0px rgba(0,0,0,0.02)` — identical in both themes, not tokenized.  
**Key tokens:** `--in-app-toast-background`, `--in-app-toast-border`, `--in-app-toast-label`, `--in-app-toast-icon`, `--in-app-toast-icon-close`

---

### Tooltip
**File:** `Tooltip.tsx` / `Tooltip.html`  
**Props:** `content`, `position` ("top" | "bottom" | "left" | "right"), `children`  
**Notes:** Shadow `0px 2px 2px 0px rgba(0,0,0,0.14), 0px 4px 4px 0px rgba(0,0,0,0.18)` — identical in both themes, named Figma effect style.  
**Key tokens:** `--tooltip-background`, `--tooltip-border`, `--tooltip-text`

---

### ScaleControl
**File:** `ScaleControl.tsx` / `ScaleControl.html`  
**Props:** `items`, `selectedIndex`, `onSelect`  
**States per item:** Default, Hover, Pressed, Selected  
**Key tokens:** `--scale-control-border-default/hover`, `--scale-control-background-pressed/selected`, `--scale-control-text-default/hover/pressed`

---

### Alert
**File:** `Alert.tsx` / `Alert.html`  
**Props:** `status` ("warning" | "note" | "congratulation" | "critical"), `label`, `message`, `onClose`  
**Key tokens:** `--alert-background`, `--alert-label`, `--alert-indicator-warning/info/success/error`

---

## Organisms

### CardMain
**File:** `CardMain.tsx` / `CardMain.html`  
**Props:** `title`, `description`, `image`, `state` ("default" | "hover" | "disabled"), `onClick`  
**Key tokens:** `--card-main-default-background-default`, `--card-main-hover-background-hover`, `--card-main-hover-border-hover`, `--card-main-default-label-default`

---

### ExploreCard
**File:** `ExploreCard.tsx` / `ExploreCard.html`  
**Props:** `title`, `description`, `icon`, `linkLabel`, `state` ("default" | "hover"), `onClick`  
**Key tokens:** `--card-explore-default-background-default`, `--card-explore-hover-background-hover`, `--card-explore-default-icon-default`, `--card-explore-default-link-default`

---

### ContentLayer
**File:** `ContentLayer.tsx` / `ContentLayer.html`  
**Props:** `title`, `content`, `expanded`, `onToggle`  
**States:** Expanded, Collapsed only — no hover/pressed states in Figma.  
**Notes:** Shadow `0px 4px 60px 12px var(--content-layer-drop-shadow)` — large diffuse shadow, different in light (`#0672cb` @ 10%) and dark (`#000000` @ 20%).  
**Key tokens:** `--content-layer-background`, `--content-layer-title-label`, `--content-layer-content-text`, `--content-layer-divider`, `--content-layer-drop-shadow`, `--content-layer-trigger-label`

---

### NotificationOSD
**File:** `NotificationOSD.tsx` / `NotificationOSD.html`  
**Props:** `title`, `message`, `onAction`, `onDismiss`  
**Notes:** Always-dark component (same node in light and dark). Background `rgba(10,14,20,0.85)` with `backdrop-filter: blur(3px)`.

---

### Masthead
**File:** `Masthead.tsx` / `Masthead.html`  
**Props:** `title`, `logoSrc`, `actions`  
**Key tokens:** `--masthead-title-bar`

---

### SplashScreen
**File:** `SplashScreen.tsx` / `SplashScreen.html`  
**Props:** `title`, `subtitle`, `logoSrc`, `version`  
**Notes:** `backdrop-filter: blur(25px)`, `box-shadow: 0px 4px 4px 0px rgba(0,0,0,0.06)`. Decorative blurred ellipses (Ellipse 4–8) are hidden in Figma — replaced by Window Gradient. Disregard entirely.  
**Key tokens:** `--windows-background`, `--windows-text`

---

### Window
**File:** `Window.tsx` / `Window.html`  
**Props:** `title`, `children`, `onClose`, `onMinimize`, `onMaximize`  
**Notes:** Same glass-panel surface as SplashScreen. `backdrop-filter: blur(25px)`, `box-shadow: 0px 4px 4px 0px rgba(0,0,0,0.06)`.  
**Key tokens:** `--windows-background`

---

## Shadow & Blur Reference

All values verified directly from Figma via `node.effects`. Root cause of original errors: blur radius was halved in initial build. Figma blur radius = CSS blur radius, no conversion.

| Component | Effect | Correct CSS value |
|---|---|---|
| ContentLayer | drop-shadow | `0px 4px 60px 12px var(--content-layer-drop-shadow)` |
| DropdownMenu | drop-shadow | `0px 4px 4px 0px rgba(0,42,88,0.08)` |
| Toast | drop-shadow | `0px 4px 4px 0px rgba(0,0,0,0.04), 0px 2px 2px 0px rgba(0,0,0,0.02)` |
| Tooltip | drop-shadow | `0px 2px 2px 0px rgba(0,0,0,0.14), 0px 4px 4px 0px rgba(0,0,0,0.18)` |
| NotificationOSD | backdrop-filter | `blur(3px)` |
| SplashScreen | backdrop-filter | `blur(25px)` |
| Window | backdrop-filter | `blur(25px)` |

---

## Typography Scale

All tokens in `tokens.css` under `:root` (theme-invariant):

| Token prefix | Size | Line height | Weight | Use |
|---|---|---|---|---|
| `--font-header-4-xs-*` | 20px | 28px | 500 | Section headers |
| `--font-header-6-*` | 16px | 24px | 500 | Card titles |
| `--font-button-1-*` | 16px | 24px | 500 | GradientButton |
| `--font-body-2-*` | 16px | 24px | 400 | Body text, RadioButton label |
| `--font-button-2-*` | 14px | 24px | 500 | Button Base/Large, most controls |
| `--font-body-3-*` | 14px | 20px | 400 | Small body, Slider tooltip |
| `--font-button-3-*` | 12px | 20px | 500 | Button Small |
| `--font-caption-*` | 12px | 16px | 400 | Toast, Tooltip body |
| `--font-caption-strong-*` | 12px | 16px | 500 | Tooltip label |
| `--font-lead-*` | 18px | 28px | 400 | CardMain title (Lead/Body 2 Strong) |

---

## Gradient Reference (non-tokenized)

Two named Figma gradient styles used only in GradientButton:

| Style name | CSS value | Used on |
|---|---|---|
| `Gradient button` | `linear-gradient(119deg, #0672cb 0%, #0078d4 0%, #6e69cf 100%)` | Selected fill |
| `Gradient stroke` | `linear-gradient(120deg, #55b4fd 0%, #6e69cf 100%)` | Hover + Selected border |
