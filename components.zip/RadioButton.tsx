import { useState } from "react";

type RadioInteractionState = "rest" | "hover" | "pressed";

interface RadioButtonProps {
  label?: string;
  selected?: boolean;
  name?: string;
  value?: string;
  onChange?: (value: string) => void;
}

/* ============================================
   Resolve circle background/border + inner-dot + label color.
   NOTE: the pulled Figma frame (40000157:3883/3884) only defines
   Rest / Hover / Pressed × Unselected/Selected — six variants total.
   No disabled or focused variant exists in this frame. Unlike Checkbox
   (which does have a documented disabled+focus set), don't fabricate
   one here — flag with Jorge if a disabled Radio Button turns up
   elsewhere in the file before treating this as final.
   ============================================ */
function resolveStyles(
  selected: boolean,
  interaction: RadioInteractionState
): { circleBackground: string; border: string; innerDot: string | null; labelColor: string } {
  const labelColor = "var(--radio-button-text-default, #0e0e0e)";

  if (selected) {
    const circleBackground =
      interaction === "pressed"
        ? "var(--radio-button-background-pressed-selected, #00468b)"
        : interaction === "hover"
        ? "var(--radio-button-background-hover-selected, #0063b8)"
        : "var(--radio-button-background-rest-selected, #0672cb)";
    return {
      circleBackground,
      border: "none",
      innerDot: "var(--radio-button-fill-inner-selected, #f5f6f7)",
      labelColor,
    };
  }

  const border =
    interaction === "pressed"
      ? "1.5px solid var(--radio-button-border-pressed-unselected, #00468b)"
      : interaction === "hover"
      ? "1.5px solid var(--radio-button-border-hover-unselected, #0672cb)"
      : "1.5px solid var(--radio-button-border-rest-unselected, #b6b6b6)";

  return {
    circleBackground: "var(--radio-button-background-default-unselected, #ffffff)",
    border,
    innerDot: null,
    labelColor,
  };
}

export default function RadioButton({
  label = "Button",
  selected = false,
  name,
  value,
  onChange,
}: RadioButtonProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const interaction: RadioInteractionState = pressed ? "pressed" : hovered ? "hover" : "rest";
  const s = resolveStyles(selected, interaction);

  return (
    <label
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        cursor: "pointer",
        userSelect: "none",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setPressed(false);
      }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
    >
      {/* 24px click target, 20px visible circle (4px padding all round, per Figma) */}
      <span
        style={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          width: 24,
          height: 24,
          flexShrink: 0,
        }}
      >
        <input
          type="radio"
          name={name}
          value={value}
          checked={selected}
          onChange={() => onChange?.(value ?? label)}
          style={{
            position: "absolute",
            opacity: 0,
            width: 24,
            height: 24,
            margin: 0,
            cursor: "pointer",
          }}
        />
        <span
          aria-hidden="true"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: 20,
            height: 20,
            borderRadius: "50%",
            boxSizing: "border-box",
            background: s.circleBackground,
            border: s.border,
            transition: "background-color 0.15s ease, border-color 0.15s ease",
          }}
        >
          {s.innerDot && (
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: s.innerDot,
              }}
            />
          )}
        </span>
      </span>

      <span
        style={{
          fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
          fontWeight: "var(--font-body-2-weight, 400)" as React.CSSProperties["fontWeight"],
          fontSize: "var(--font-body-2-size, 16px)",
          lineHeight: "var(--font-body-2-line-height, 24px)",
          letterSpacing: "var(--font-body-2-letter-spacing, 0.08px)",
          color: s.labelColor,
          wordBreak: "break-word",
        }}
      >
        {label}
      </span>
    </label>
  );
}
