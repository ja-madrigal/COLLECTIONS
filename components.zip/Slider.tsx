import { useState, useRef, useCallback } from "react";

type SliderType = "default" | "handle" | "tooltip-top" | "tooltip-bot" | "double";

interface SliderProps {
  type?: SliderType;
  /** Current value 0–100. For "double", use valueMin/valueMax instead. */
  value?: number;
  /** Double slider only — lower thumb value 0–100 */
  valueMin?: number;
  /** Double slider only — upper thumb value 0–100 */
  valueMax?: number;
  min?: number;
  max?: number;
  disabled?: boolean;
  width?: number | string;
  onChange?: (value: number) => void;
  onChangeRange?: (min: number, max: number) => void;
}

/* ============================================
   Anatomy (from Figma):
   - Track:  4px tall, full width, border-radius:100px, --slider-track
   - Fill:   4px tall, --slider-progress (grows from left, or between thumbs for Double)
   - Thumb:  14×14px solid circle, --slider-progress (no border, no shadow — confirmed Figma)
   - Tooltip: 14px / Regular / 400wt label in --slider-progress, floated above or below thumb
   - Wrapper height: 14px (track + thumb occupy same vertical center via flex align-items:center)
     Tooltip variants need extra vertical room — component expands naturally via flexbox column
   ============================================ */

const THUMB_SIZE = 14;
const TRACK_HEIGHT = 4;
const TOOLTIP_GAP = 4; // gap between thumb and tooltip label per Figma (10px total column gap = 4px track-to-thumb + gap)

function clamp(val: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, val));
}

function pctFromEvent(e: React.MouseEvent, trackEl: HTMLElement): number {
  const rect = trackEl.getBoundingClientRect();
  return clamp(Math.round(((e.clientX - rect.left) / rect.width) * 100), 0, 100);
}

/* Single thumb — used by Handle, Tooltip(top), Tooltip(bot) */
function SingleSlider({
  type,
  value,
  disabled,
  onChange,
  width,
}: {
  type: SliderType;
  value: number;
  disabled: boolean;
  onChange?: (v: number) => void;
  width: string;
}) {
  const trackRef = useRef<HTMLDivElement>(null);

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (disabled || !trackRef.current) return;
    const pct = pctFromEvent(e, trackRef.current);
    onChange?.(pct);
  };

  const showThumb = type !== "default";
  const showTooltip = type === "tooltip-top" || type === "tooltip-bot";
  const tooltipAbove = type === "tooltip-top";

  const trackColor = "var(--slider-track, #c5d4e3)";
  const progressColor = "var(--slider-progress, #0672cb)";

  const tooltipLabel = (
    <span
      style={{
        fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
        fontWeight: "var(--font-body-3-weight, 400)" as React.CSSProperties["fontWeight"],
        fontSize: "var(--font-body-3-size, 14px)",
        lineHeight: 1.5,
        letterSpacing: 0,
        color: progressColor,
        textAlign: "center",
        width: THUMB_SIZE,
        display: "block",
        userSelect: "none",
      }}
    >
      {value}
    </span>
  );

  const trackAndFill = (
    <div
      ref={trackRef}
      onClick={handleClick}
      style={{
        position: "relative",
        width,
        height: THUMB_SIZE,
        display: "flex",
        alignItems: "center",
        cursor: disabled ? "not-allowed" : "pointer",
        flexShrink: 0,
      }}
    >
      {/* Track */}
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          height: TRACK_HEIGHT,
          background: trackColor,
          borderRadius: 100,
        }}
      />
      {/* Fill */}
      <div
        style={{
          position: "absolute",
          left: 0,
          width: `${value}%`,
          height: TRACK_HEIGHT,
          background: progressColor,
          borderRadius: 100,
        }}
      />
      {/* Thumb */}
      {showThumb && (
        <div
          style={{
            position: "absolute",
            left: `calc(${value}% - ${THUMB_SIZE / 2}px)`,
            width: THUMB_SIZE,
            height: THUMB_SIZE,
            borderRadius: "50%",
            background: progressColor,
            flexShrink: 0,
          }}
        />
      )}
    </div>
  );

  if (!showTooltip) return trackAndFill;

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: TOOLTIP_GAP,
        width,
        opacity: disabled ? 0.5 : 1,
      }}
    >
      {tooltipAbove && (
        <div style={{ position: "relative", width: "100%", height: 21 }}>
          <div style={{ position: "absolute", left: `calc(${value}% - ${THUMB_SIZE / 2}px)` }}>
            {tooltipLabel}
          </div>
        </div>
      )}
      {trackAndFill}
      {!tooltipAbove && (
        <div style={{ position: "relative", width: "100%", height: 21 }}>
          <div style={{ position: "absolute", left: `calc(${value}% - ${THUMB_SIZE / 2}px)` }}>
            {tooltipLabel}
          </div>
        </div>
      )}
    </div>
  );
}

/* Double (range) slider */
function DoubleSlider({
  valueMin,
  valueMax,
  disabled,
  onChangeRange,
  width,
}: {
  valueMin: number;
  valueMax: number;
  disabled: boolean;
  onChangeRange?: (min: number, max: number) => void;
  width: string;
}) {
  const trackRef = useRef<HTMLDivElement>(null);

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (disabled || !trackRef.current) return;
    const pct = pctFromEvent(e, trackRef.current);
    // Move whichever thumb is closer
    const distMin = Math.abs(pct - valueMin);
    const distMax = Math.abs(pct - valueMax);
    if (distMin <= distMax) {
      onChangeRange?.(clamp(pct, 0, valueMax), valueMax);
    } else {
      onChangeRange?.(valueMin, clamp(pct, valueMin, 100));
    }
  };

  const trackColor = "var(--slider-track, #c5d4e3)";
  const progressColor = "var(--slider-progress, #0672cb)";

  return (
    <div
      ref={trackRef}
      onClick={handleClick}
      style={{
        position: "relative",
        width,
        height: THUMB_SIZE,
        display: "flex",
        alignItems: "center",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        flexShrink: 0,
      }}
    >
      {/* Track */}
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          height: TRACK_HEIGHT,
          background: trackColor,
          borderRadius: 100,
        }}
      />
      {/* Fill between thumbs */}
      <div
        style={{
          position: "absolute",
          left: `${valueMin}%`,
          width: `${valueMax - valueMin}%`,
          height: TRACK_HEIGHT,
          background: progressColor,
          borderRadius: 100,
        }}
      />
      {/* Min thumb */}
      <div
        style={{
          position: "absolute",
          left: `calc(${valueMin}% - ${THUMB_SIZE / 2}px)`,
          width: THUMB_SIZE,
          height: THUMB_SIZE,
          borderRadius: "50%",
          background: progressColor,
        }}
      />
      {/* Max thumb */}
      <div
        style={{
          position: "absolute",
          left: `calc(${valueMax}% - ${THUMB_SIZE / 2}px)`,
          width: THUMB_SIZE,
          height: THUMB_SIZE,
          borderRadius: "50%",
          background: progressColor,
        }}
      />
    </div>
  );
}

export default function Slider({
  type = "handle",
  value: initialValue = 50,
  valueMin: initialMin = 25,
  valueMax: initialMax = 75,
  disabled = false,
  width = 281,
  onChange,
  onChangeRange,
}: SliderProps) {
  const [value, setValue] = useState(initialValue);
  const [valueMin, setValueMin] = useState(initialMin);
  const [valueMax, setValueMax] = useState(initialMax);

  const w = typeof width === "number" ? `${width}px` : width;

  const handleChange = useCallback((v: number) => {
    setValue(v);
    onChange?.(v);
  }, [onChange]);

  const handleRangeChange = useCallback((lo: number, hi: number) => {
    setValueMin(lo);
    setValueMax(hi);
    onChangeRange?.(lo, hi);
  }, [onChangeRange]);

  if (type === "double") {
    return (
      <DoubleSlider
        valueMin={valueMin}
        valueMax={valueMax}
        disabled={disabled}
        onChangeRange={handleRangeChange}
        width={w}
      />
    );
  }

  return (
    <div style={{ opacity: type === "tooltip-top" || type === "tooltip-bot" ? 1 : disabled ? 0.5 : 1 }}>
      <SingleSlider
        type={type}
        value={value}
        disabled={disabled}
        onChange={handleChange}
        width={w}
      />
    </div>
  );
}
