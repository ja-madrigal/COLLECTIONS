import { useState } from "react";

interface ToastProps {
  text?: string;
  loading?: boolean;
  onClose?: () => void;
}

const ToastSpinner = () => (
  <>
    <style>{`
      @keyframes toast-spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      .toast-spinner-ring { animation: toast-spin 0.8s linear infinite; }
    `}</style>
    {/* Icon: dds2_busy-indicator-spinner — sized 26x26, colored via --in-app-toast-icon */}
    <svg
      className="toast-spinner-ring"
      width="26"
      height="26"
      viewBox="0 0 26 26"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        cx="13" cy="13" r="10"
        stroke="var(--in-app-toast-icon, #0672cb)"
        strokeWidth="3"
        strokeOpacity="0.2"
      />
      <path
        d="M13 3 A10 10 0 0 1 23 13"
        stroke="var(--in-app-toast-icon, #0672cb)"
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  </>
);

const CloseIcon = () => (
  /* Icon: dds2_close-x.svg */
  <svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M1 1l9 9M10 1L1 10"
      stroke="var(--in-app-toast-icon-close, #0e0e0e)"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

export default function Toast({
  text = "Launching SupportAssist...",
  loading = true,
  onClose,
}: ToastProps) {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        minHeight: 50,
        maxHeight: 67,
        minWidth: 200,
        width: 317,
        paddingLeft: 19,
        paddingRight: 12,
        paddingTop: 8,
        paddingBottom: 8,
        background: "var(--in-app-toast-background, #ffffff)",
        border: "1px solid var(--in-app-toast-border, #e1e1e1)",
        borderRadius: 4,
        boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.04), 0px 2px 2px 0px rgba(0,0,0,0.02)",
        boxSizing: "border-box",
      }}
    >
      {/* Left: spinner + text */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, flex: 1, minWidth: 0 }}>
        {loading && (
          <div style={{ width: 26, height: 26, flexShrink: 0, display: "flex", alignItems: "center" }}>
            <ToastSpinner />
          </div>
        )}
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-caption-weight, 400)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-caption-size, 12px)",
            lineHeight: "var(--font-caption-line-height, 20px)",
            letterSpacing: "var(--font-caption-letter-spacing, 0.06px)",
            color: "var(--in-app-toast-label, #0e0e0e)",
            wordBreak: "break-word",
          }}
        >
          {text}
        </p>
      </div>

      {/* Close button */}
      <div
        onClick={() => { setVisible(false); onClose?.(); }}
        style={{
          width: 32,
          height: 32,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          flexShrink: 0,
        }}
      >
        {/* Icon: dds2_close-x.svg */}
        <CloseIcon />
      </div>
    </div>
  );
}
