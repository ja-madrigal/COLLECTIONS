import Masthead from "./Masthead";
import { splashGradient, splashGradientDark } from "./SplashScreen";

interface WindowProps {
  children?: React.ReactNode;
  theme?: "light" | "dark";
  onChevron?: () => void;
  onMinimize?: () => void;
  onMaximize?: () => void;
  onClose?: () => void;
}

export default function Window({
  children,
  theme = "light",
  onChevron,
  onMinimize,
  onMaximize,
  onClose,
}: WindowProps) {
  const isDark = theme === "dark";

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        minHeight: 400,
        borderRadius: 9,
        overflow: "hidden",
        backdropFilter: "blur(25px)",
        boxShadow: "0px 4px 4px 0px rgba(0,0,0,0.06)",
        background: isDark
          ? "var(--windows-background, #0a0e14bf)"
          : "var(--windows-background, #fffffff2)",
        backgroundImage: isDark ? splashGradientDark : splashGradient,
        boxSizing: "border-box",
      }}
    >
      {/* Masthead — window controls top right */}
      <Masthead
        onChevron={onChevron}
        onMinimize={onMinimize}
        onMaximize={onMaximize}
        onClose={onClose}
      />

      {/* Content area */}
      <div
        style={{
          position: "absolute",
          inset: "60px 0 0 0",
          overflow: "auto",
        }}
      >
        {children}
      </div>
    </div>
  );
}
