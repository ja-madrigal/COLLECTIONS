import { useState } from "react";

type ProgressState = "idle" | "installing" | "downloading";

interface ProgressButtonProps {
  idleLabel?: string;
  installingLabel?: string;
  downloadingLabel?: string;
  /** "installing" / "downloading" show a spinner + status label and take
   *  visual priority over hover/pressed/disabled — Figma has no combined
   *  disabled+progress or hover+progress variant defined. */
  progress?: ProgressState;
  disabled?: boolean;
  onClick?: () => void;
}

/* Icon: reused animated spinner pattern from BusyIndicator.tsx (14px variant),
   recolored per state via --button-primary-label-default / --button-progress-label.
   Figma's "Installing" and "Downloading" variants bind the spinner label to two
   different tokens even though both resolve to the same white (#f5f6f7) in both
   themes — kept distinct here to match the source bindings exactly. */
const Spinner = ({ color }: { color: string }) => (
  <>
    <style>{`
      @keyframes progress-button-spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      .progress-button__spinner { animation: progress-button-spin 0.8s linear infinite; }
    `}</style>
    <svg
      className="progress-button__spinner"
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="7" cy="7" r="5.5" stroke={color} strokeWidth="1.6" strokeOpacity="0.25" />
      <path d="M7 1.5 A5.5 5.5 0 0 1 12.5 7" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  </>
);

export default function ProgressButton({
  idleLabel = "Install",
  installingLabel = "Installing...",
  downloadingLabel = "Downloading...",
  progress = "idle",
  disabled = false,
  onClick,
}: ProgressButtonProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const isBusy = progress === "installing" || progress === "downloading";
  // No disabled+busy variant exists in Figma — busy state wins if both are set.
  const effectiveDisabled = isBusy ? false : disabled;

  let background: string;
  let color: string;

  if (isBusy) {
    background = "var(--button-progress-background, #293b4d)";
    color =
      progress === "installing"
        ? "var(--button-primary-label-default, #f5f6f7)"
        : "var(--button-progress-label, #f5f6f7)";
  } else if (effectiveDisabled) {
    // NOTE: Figma layers an extra opacity:0.5 on the whole button on top of
    // an already-alpha'd disabled background token (#b6b6b6cc / #63636380),
    // which would double the transparency. Following the precedent set in
    // Button.tsx, we use the token's built-in alpha only and skip the
    // redundant wrapper opacity — same known-inconsistency pattern as
    // Destructive's mislabeled disabled node.
    background = "var(--button-primary-background-disabled, #b6b6b6cc)";
    color = "var(--button-primary-label-disabled, #f5f6f7cc)";
  } else if (pressed) {
    background = "var(--button-primary-background-pressed, #00468b)";
    color = "var(--button-primary-label-default, #f5f6f7)";
  } else if (hovered) {
    background = "var(--button-primary-background-hover, #0063b8)";
    color = "var(--button-primary-label-default, #f5f6f7)";
  } else {
    background = "var(--button-primary-background-default, #0672cb)";
    color = "var(--button-primary-label-default, #f5f6f7)";
  }

  const label =
    progress === "installing" ? installingLabel : progress === "downloading" ? downloadingLabel : idleLabel;

  return (
    <button
      onClick={effectiveDisabled || isBusy ? undefined : onClick}
      disabled={effectiveDisabled}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setPressed(false);
      }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "5px",
        // Fixed 154px width comes from the Figma frame (sized to fit "Install" /
        // "Installing..." / "Downloading..." without reflow). Using minWidth so
        // longer custom labels don't clip instead of hard-locking the width.
        minWidth: "154px",
        minHeight: "40px",
        padding: "8px 17.5px",
        borderRadius: "var(--button-size-default-radius, 2px)",
        cursor: isBusy ? "default" : effectiveDisabled ? "not-allowed" : "pointer",
        fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
        fontWeight: "var(--font-button-2-weight, 500)" as React.CSSProperties["fontWeight"],
        fontSize: "var(--font-button-2-size, 14px)",
        lineHeight: "var(--font-button-2-line-height, 24px)",
        letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
        whiteSpace: "nowrap",
        boxSizing: "border-box",
        background,
        color,
        border: "none",
        transition: "background-color 0.15s ease",
      }}
    >
      {isBusy && <Spinner color={color} />}
      <span>{label}</span>
    </button>
  );
}
