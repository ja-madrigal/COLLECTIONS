import { useState } from "react";

type CheckboxState =
  | "default"
  | "hover"
  | "pressed"
  | "checked"
  | "disabled"
  | "disabled-checked"
  | "indeterminate"
  | "focused";

interface CheckboxProps {
  label?: string;
  /** Controlled visual state. In a real form, leave this unset and let
   *  the component manage hover/pressed/focused internally — only pass
   *  checked / disabled / indeterminate / disabled-checked from outside. */
  state?: CheckboxState;
  /** Error variant. Not applicable when state is "disabled" or "disabled-checked" —
   *  error+disabled does not exist in Figma (no token, no state defined). */
  error?: boolean;
  onChange?: (checked: boolean) => void;
}

/* Icon: dds2_check.svg — placeholder, swap at Storybook handoff */
const CheckIcon = ({ color }: { color: string }) => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M1 6L4.5 9.5L11 2.5" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/* Icon: dds2_indeterminate.svg — placeholder, swap at Storybook handoff */
const IndeterminateIcon = ({ color }: { color: string }) => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M2 6H10" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

/* ============================================
   Resolve box background, border, overlay, label color, and icon color
   based on state + error flag.
   Indeterminate reuses checked tokens — only the glyph differs (dash vs tick).
   Error+Disabled falls back to regular disabled (no error-disabled token in Figma).
   Error+Focused uses the standard blue focus ring, not red — confirmed intentional.
   ============================================ */
function resolveStyles(
  state: CheckboxState,
  error: boolean
): {
  boxBackground: string;
  border: string;
  overlay: string | null;
  labelColor: string;
  iconColor: string;
  cursor: string;
} {
  const isDisabled = state === "disabled" || state === "disabled-checked";
  const isChecked = state === "checked" || state === "disabled-checked" || state === "indeterminate";

  // Disabled — error prop is ignored here; error+disabled does not exist in Figma
  // (same pattern as Button/Destructive having no disabled state).
  if (isDisabled) {
    const bg = isChecked
      ? "var(--checkbox-default-box-background-checked, #0672cb)"
      : "var(--checkbox-default-box-background-disabled, #b6b6b6cc)";
    const iconColor = isChecked
      ? "var(--checkbox-default-icon-checked-disabled, #6e6e6e33)"
      : "transparent";
    return {
      boxBackground: bg,
      border: isChecked ? "none" : "1px solid var(--checkbox-default-border-disabled, #b6b6b6)",
      overlay: null,
      labelColor: "var(--checkbox-default-text-disabled, #b6b6b6)",
      iconColor,
      cursor: "not-allowed",
    };
  }

  // Checked / Indeterminate
  if (isChecked) {
    const bg = error
      ? "var(--checkbox-error-box-background-error-checked, #bb2a33)"
      : "var(--checkbox-default-box-background-checked, #0672cb)";
    const iconColor = error
      ? "var(--checkbox-error-icon-error, #f5f6f7)"
      : "var(--checkbox-default-icon-checked, #f5f6f7)";
    return {
      boxBackground: bg,
      border: "none",
      overlay: null,
      labelColor: error
        ? "var(--checkbox-error-text-error-default, #bb2a33)"
        : "var(--checkbox-default-text-default, #0e0e0e)",
      iconColor,
      cursor: "pointer",
    };
  }

  // Hover
  if (state === "hover") {
    const overlay = error
      ? "var(--checkbox-error-box-overlay-error-hover, #ffecee80)"
      : "var(--checkbox-default-box-overlay-hover, #d9f5fd99)";
    return {
      boxBackground: error
        ? "var(--checkbox-error-box-background-error-default, #ffffff)"
        : "var(--checkbox-default-box-background-default, #ffffff)",
      border: `1px solid ${error
        ? "var(--checkbox-error-border-error-default, #bb2a33)"
        : "var(--checkbox-default-border-default, #0063b8)"}`,
      overlay,
      labelColor: error
        ? "var(--checkbox-error-text-error-default, #bb2a33)"
        : "var(--checkbox-default-text-default, #0e0e0e)",
      iconColor: "transparent",
      cursor: "pointer",
    };
  }

  // Pressed
  if (state === "pressed") {
    const overlay = error
      ? "var(--checkbox-error-box-overlay-error-pressed, #ffc3c9cc)"
      : "var(--checkbox-default-box-overlay-pressed, #97dcf499)";
    return {
      boxBackground: error
        ? "var(--checkbox-error-box-background-error-default, #ffffff)"
        : "var(--checkbox-default-box-background-default, #ffffff)",
      border: `1px solid ${error
        ? "var(--checkbox-error-border-error-default, #bb2a33)"
        : "var(--checkbox-default-border-default, #0063b8)"}`,
      overlay,
      labelColor: error
        ? "var(--checkbox-error-text-error-default, #bb2a33)"
        : "var(--checkbox-default-text-default, #0e0e0e)",
      iconColor: "transparent",
      cursor: "pointer",
    };
  }

  // Focused — error+focused uses standard blue ring, not red (confirmed intentional)
  if (state === "focused") {
    return {
      boxBackground: error
        ? "var(--checkbox-error-box-background-error-default, #ffffff)"
        : "var(--checkbox-default-box-background-default, #ffffff)",
      border: "2px solid var(--checkbox-error-border-error-focused, #0672cb)",
      overlay: null,
      labelColor: error
        ? "var(--checkbox-error-text-error-default, #bb2a33)"
        : "var(--checkbox-default-text-default, #0e0e0e)",
      iconColor: "transparent",
      cursor: "pointer",
    };
  }

  // Default
  return {
    boxBackground: error
      ? "var(--checkbox-error-box-background-error-default, #ffffff)"
      : "var(--checkbox-default-box-background-default, #ffffff)",
    border: `1px solid ${error
      ? "var(--checkbox-error-border-error-default, #bb2a33)"
      : "var(--checkbox-default-border-default, #0063b8)"}`,
    overlay: null,
    labelColor: error
      ? "var(--checkbox-error-text-error-default, #bb2a33)"
      : "var(--checkbox-default-text-default, #0e0e0e)",
    iconColor: "transparent",
    cursor: "pointer",
  };
}

export default function Checkbox({
  label = "Option",
  state = "default",
  error = false,
  onChange,
}: CheckboxProps) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [focused, setFocused] = useState(false);

  const isDisabled = state === "disabled" || state === "disabled-checked";
  const isChecked = state === "checked" || state === "disabled-checked";
  const isIndeterminate = state === "indeterminate";

  // Derive effective interaction state — prop overrides internal state
  const effectiveState: CheckboxState = isDisabled
    ? state
    : state === "checked" || state === "indeterminate" || state === "disabled-checked"
    ? state
    : pressed
    ? "pressed"
    : focused
    ? "focused"
    : hovered
    ? "hover"
    : "default";

  const s = resolveStyles(effectiveState, error);

  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "flex-start",
        gap: 4,
        cursor: s.cursor,
        userSelect: "none",
      }}
      onClick={() => !isDisabled && onChange?.(!isChecked)}
      onMouseEnter={() => !isDisabled && setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => !isDisabled && setPressed(true)}
      onMouseUp={() => setPressed(false)}
    >
      {/* Box + overlay wrapper */}
      <div style={{ position: "relative", flexShrink: 0, marginTop: 3 }}>
        {/* Box */}
        <div
          tabIndex={isDisabled ? -1 : 0}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: 18,
            height: 18,
            borderRadius: 2,
            boxSizing: "border-box",
            background: s.boxBackground,
            border: s.border,
            transition: "background 0.15s ease, border-color 0.15s ease",
          }}
        >
          {(isChecked) && <CheckIcon color={s.iconColor} />}
          {isIndeterminate && <IndeterminateIcon color={s.iconColor} />}
          {/* Checked-disabled gets a dimmed icon */}
          {state === "disabled-checked" && <CheckIcon color="var(--checkbox-default-icon-checked-disabled, #6e6e6e33)" />}
        </div>

        {/* Hover / Pressed overlay */}
        {s.overlay && (
          <div
            style={{
              position: "absolute",
              inset: -4,
              borderRadius: 4,
              background: s.overlay,
              pointerEvents: "none",
            }}
          />
        )}
      </div>

      {/* Label */}
      <p
        style={{
          margin: 0,
          fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
          fontWeight: "var(--font-body-2-weight, 400)" as React.CSSProperties["fontWeight"],
          fontSize: "var(--font-body-2-size, 16px)",
          lineHeight: "var(--font-body-2-line-height, 24px)",
          letterSpacing: "var(--font-body-2-letter-spacing, 0.08px)",
          color: s.labelColor,
          wordBreak: "break-word",
          transition: "color 0.15s ease",
        }}
      >
        {label}
      </p>
    </div>
  );
}
