import { useState } from "react";

interface TextExpanderProps {
  label?: string;
  children?: React.ReactNode;
  defaultExpanded?: boolean;
}

const ChevronIcon = ({ rotated }: { rotated: boolean }) => (
  /* Icon: dds2_chevron-up.svg */
  <svg
    width="14"
    height="14"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={{
      transform: rotated ? "rotate(180deg)" : "rotate(0deg)",
      transition: "transform 0.2s ease",
      flexShrink: 0,
    }}
  >
    <path
      d="M1 11L8 4L15 11"
      stroke="var(--content-layer-trigger-label, #0063b8)"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export default function TextExpander({
  label = "Text Expander",
  children,
  defaultExpanded = false,
}: TextExpanderProps) {
  const [expanded, setExpanded] = useState(defaultExpanded);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {/* Trigger */}
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 4,
          cursor: "pointer",
        }}
      >
        <span
          style={{
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-button-2-weight, 500)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-button-2-size, 14px)",
            lineHeight: "var(--font-button-2-line-height, 24px)",
            letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
            color: "var(--content-layer-trigger-label, #0063b8)",
            whiteSpace: "nowrap",
          }}
        >
          {label}
        </span>
        {/* Icon: dds2_chevron-up.svg */}
        <ChevronIcon rotated={expanded} />
      </div>

      {/* Expanded content */}
      {expanded && children && (
        <div>{children}</div>
      )}
    </div>
  );
}
