interface MastheadProps {
  showChevron?: boolean;
  showMaximize?: boolean;
  onChevron?: () => void;
  onMinimize?: () => void;
  onMaximize?: () => void;
  onClose?: () => void;
}

const ChevronIcon = () => (
  /* Icon: dds2_chevron-down.svg */
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M1 5L8 12L15 5"
      stroke="var(--masthead-title-bar, #0e0e0e)"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const MinimizeIcon = () => (
  /* Icon: dds2_minus-minimize.svg */
  <svg width="10" height="10" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M2.5 8H13.5"
      stroke="var(--masthead-title-bar, #0e0e0e)"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

const MaximizeIcon = () => (
  /* Icon: dds2_stop.svg */
  <svg width="10" height="10" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect
      x="2.5"
      y="2.5"
      width="11"
      height="11"
      stroke="var(--masthead-title-bar, #0e0e0e)"
      strokeWidth="1.5"
    />
  </svg>
);

const CloseIcon = () => (
  /* Icon: dds2_close-x.svg */
  <svg width="10" height="10" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M1 1l9 9M10 1L1 10"
      stroke="var(--masthead-title-bar, #0e0e0e)"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

const ControlButton = ({
  children,
  onClick,
}: {
  children: React.ReactNode;
  onClick?: () => void;
}) => (
  <div
    onClick={onClick}
    style={{
      width: 16,
      height: 16,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      flexShrink: 0,
    }}
  >
    {children}
  </div>
);

export default function Masthead({
  showChevron = true,
  showMaximize = true,
  onChevron,
  onMinimize,
  onMaximize,
  onClose,
}: MastheadProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        padding: "14px 25px",
        width: "100%",
        boxSizing: "border-box",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          gap: 24,
          height: 32,
          width: "100%",
        }}
      >
        {/* Chevron / collapse */}
        {showChevron && (
          <ControlButton onClick={onChevron}>
            <ChevronIcon />
          </ControlButton>
        )}

        {/* Minimize */}
        <ControlButton onClick={onMinimize}>
          <MinimizeIcon />
        </ControlButton>

        {/* Maximize / Restore */}
        {showMaximize && (
          <ControlButton onClick={onMaximize}>
            <MaximizeIcon />
          </ControlButton>
        )}

        {/* Close */}
        <ControlButton onClick={onClose}>
          <CloseIcon />
        </ControlButton>
      </div>
    </div>
  );
}
