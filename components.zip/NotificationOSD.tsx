import Button from "./Button";

interface NotificationOSDProps {
  appIcon?: React.ReactNode;
  title?: string;
  message?: string;
  variant?: "default" | "single-button" | "double-buttons";
  primaryLabel?: string;
  secondaryLabel?: string;
  onClose?: () => void;
  onPrimary?: () => void;
  onSecondary?: () => void;
}

const CloseIcon = () => (
  /* Icon: dds2_close-x.svg */
  <svg width="14" height="14" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M1 1l9 9M10 1L1 10" stroke="#f5f6f7" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const AppIconPlaceholder = () => (
  /* Icon: replace with actual app icon */
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="24" height="24" rx="4" fill="#0672cb" />
    <path d="M6 12h12M12 6v12" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const ArrowLeftIcon = () => (
  /* Icon: dds2_arrow-left.svg */
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 8H3M3 8L7 4M3 8L7 12" stroke="#f5f6f7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const ArrowRightIcon = () => (
  /* Icon: dds2_arrow-right.svg */
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 8H13M13 8L9 4M13 8L9 12" stroke="#f5f6f7" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export default function NotificationOSD({
  appIcon,
  title,
  message = "Detecting onlooker.\nEnable screen effect?",
  variant = "default",
  primaryLabel = "Enable",
  secondaryLabel = "Don't enable",
  onClose,
  onPrimary,
  onSecondary,
}: NotificationOSDProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "16px 16px 24px",
        width: 296,
        borderRadius: 6,
        background: "rgba(10, 14, 20, 0.85)",
        backdropFilter: "blur(3px)",
        boxSizing: "border-box",
        position: "relative",
      }}
    >
      {/* Top row: app icon + close */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          width: "100%",
          marginBottom: 16,
        }}
      >
        <div style={{ width: 24, height: 24 }}>
          {appIcon ?? <AppIconPlaceholder />}
        </div>
        <div
          onClick={onClose}
          style={{
            width: 24,
            height: 24,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            flexShrink: 0,
          }}
        >
          {/* Icon: dds2_close-x.svg */}
          <CloseIcon />
        </div>
      </div>

      {/* Message */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, width: "100%" }}>
        {title && (
          <p
            style={{
              margin: 0,
              fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
              fontWeight: 600,
              /* NotificationOSD uses unnamed 16px/400 style — mapped to body-2 */
              fontSize: "var(--font-body-2-size, 16px)",
              lineHeight: "var(--font-body-2-line-height, 24px)",
              color: "#ffffff",
              textAlign: "center",
            }}
          >
            {title}
          </p>
        )}
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-body-2-weight, 400)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-body-2-size, 16px)",
            lineHeight: "var(--font-body-2-line-height, 24px)",
            color: "#ffffff",
            textAlign: "center",
            whiteSpace: "pre-line",
            width: 264,
          }}
        >
          {message}
        </p>
      </div>

      {/* Buttons */}
      {variant === "single-button" && (
        <div style={{ marginTop: 22, width: "100%", display: "flex", justifyContent: "center" }}>
          <Button variant="primary" label={primaryLabel} onClick={onPrimary} />
        </div>
      )}

      {variant === "double-buttons" && (
        <div style={{ display: "flex", gap: 7, alignItems: "center", justifyContent: "center", marginTop: 22, width: "100%" }}>
          <Button variant="secondary" label={secondaryLabel} onClick={onSecondary} />
          {/* Primary with arrow icons */}
          <div
            onClick={onPrimary}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 4,
              padding: "8px 12px",
              borderRadius: 2,
              background: "var(--button-primary-background-default, #0672cb)",
              cursor: "pointer",
              minHeight: 40,
              maxHeight: 40,
            }}
          >
            {/* Icon: dds2_arrow-left.svg */}
            <ArrowLeftIcon />
            <span
              style={{
                fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
                fontWeight: "var(--font-button-2-weight, 500)" as React.CSSProperties["fontWeight"],
                fontSize: "var(--font-button-2-size, 14px)",
                lineHeight: "var(--font-button-2-line-height, 24px)",
                color: "#f5f6f7",
                whiteSpace: "nowrap",
              }}
            >
              {primaryLabel}
            </span>
            {/* Icon: dds2_arrow-right.svg */}
            <ArrowRightIcon />
          </div>
        </div>
      )}
    </div>
  );
}
