import { useState } from "react";

type CardMainState = "default" | "hover" | "disabled";

interface CardMainProps {
  label?: string;
  state?: CardMainState;
  onClick?: () => void;
}

const PerformanceIcon = ({ color }: { color: string }) => (
  /* Icon: dds2_performance.svg */
  <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#cm-perf-clip)">
      <path d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346625 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C16 5.87827 15.1571 3.84344 13.6569 2.34315C12.1566 0.842855 10.1217 0 8 0ZM3.57 13.33L4.33 12.58L3.57 11.82L2.81 12.58C1.81068 11.4535 1.20672 10.0314 1.09 8.53H2.15V7.47H1.09C1.2173 5.98615 1.8206 4.58314 2.81 3.47L3.57 4.23L4.33 3.48L3.57 2.72C4.67719 1.80582 6.03873 1.25422 7.47 1.14V2.14H8.54V1.14C10.013 1.25093 11.4131 1.82499 12.54 2.78L11.84 3.48L12.6 4.24L13.29 3.54C14.2589 4.66025 14.841 6.0629 14.95 7.54H13.85V8.53H14.91C14.7989 10.0066 14.2171 11.4086 13.25 12.53L12.56 11.84L11.8 12.59L12.49 13.28C11.2516 14.3415 9.67709 14.93 8.04599 14.941C6.41489 14.952 4.83263 14.3848 3.58 13.34L3.57 13.33Z" fill={color}/>
      <path d="M12.15 6.73L11.82 5.93L7.65 6.71C7.2912 6.75276 6.96219 6.9307 6.73 7.20757C6.49781 7.48444 6.37991 7.83941 6.4003 8.20018C6.4207 8.56094 6.57786 8.90037 6.83978 9.1493C7.1017 9.39824 7.44867 9.53796 7.81 9.54C8.13424 9.53658 8.44783 9.42383 8.7 9.22L11.82 7L12.15 6.74V6.73ZM8 8.44C7.95748 8.46194 7.91092 8.47493 7.86318 8.47816C7.81544 8.4814 7.76755 8.47481 7.72246 8.45881C7.67737 8.4428 7.63604 8.41773 7.60102 8.38512C7.566 8.35252 7.53804 8.31308 7.51886 8.26925C7.49968 8.22541 7.4897 8.17811 7.48952 8.13027C7.48934 8.08242 7.49897 8.03505 7.51783 7.99107C7.53668 7.94709 7.56434 7.90745 7.59912 7.87459C7.63389 7.84172 7.67503 7.81634 7.72 7.8L9.34 7.49L8 8.44Z" fill={color}/>
    </g>
    <defs>
      <clipPath id="cm-perf-clip"><rect width="16" height="16" fill="white"/></clipPath>
    </defs>
  </svg>
);

const ArrowCircleRightIcon = ({ color }: { color: string }) => (
  /* Icon: dds2_arrow-cir-right.svg */
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#cm-arrow-clip)">
      <path d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346625 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C16 5.87827 15.1571 3.84344 13.6569 2.34315C12.1566 0.842855 10.1217 0 8 0ZM8 14.93C6.62938 14.93 5.28953 14.5236 4.1499 13.7621C3.01027 13.0006 2.12203 11.9183 1.59752 10.652C1.073 9.3857 0.935766 7.99231 1.20316 6.64802C1.47056 5.30374 2.13058 4.06893 3.09975 3.09975C4.06893 2.13057 5.30374 1.47055 6.64803 1.20316C7.99232 0.935762 9.38571 1.073 10.652 1.59751C11.9183 2.12203 13.0006 3.01027 13.7621 4.1499C14.5236 5.28953 14.93 6.62938 14.93 8C14.9274 9.83714 14.1964 11.5983 12.8973 12.8973C11.5983 14.1964 9.83714 14.9274 8 14.93Z" fill={color}/>
      <path d="M7.84 5.28L10.33 7.47H3.77V8.53H10.33L7.84 10.72L8.54 11.52L12.54 8L8.54 4.48L7.84 5.28Z" fill={color}/>
    </g>
    <defs>
      <clipPath id="cm-arrow-clip"><rect width="16" height="16" fill="white"/></clipPath>
    </defs>
  </svg>
);

export default function CardMain({
  label = "Applications",
  state = "default",
  onClick,
}: CardMainProps) {
  const [hovered, setHovered] = useState(false);

  const isDisabled = state === "disabled";
  const isHovered = !isDisabled && (state === "hover" || hovered);

  const background = isHovered
    ? "var(--card-main-hover-background-hover, #ffffff)"
    : "var(--card-main-default-background-default, #ffffff99)";

  const boxShadow = isHovered
    ? "inset 0 0 0 2px var(--card-main-hover-border-hover, #ffffff)"
    : "none";

  const labelColor = isDisabled
    ? "var(--card-main-disabled-label-disabled, #b6b6b6)"
    : "var(--card-main-default-label-default, #0e0e0e)";

  return (
    <div
      onClick={!isDisabled ? onClick : undefined}
      onMouseEnter={() => !isDisabled && setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "center",
        minHeight: 70,
        maxHeight: 110,
        minWidth: 250,
        width: 250,
        padding: 20,
        background,
        boxShadow,
        borderRadius: 13,
        boxSizing: "border-box",
        cursor: isDisabled ? "not-allowed" : onClick ? "pointer" : "default",
        transition: "background 0.15s ease, box-shadow 0.15s ease",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          width: "100%",
          height: 30,
        }}
      >
        {/* Icon + Label */}
        <div style={{ display: "flex", alignItems: "center", gap: 16, flex: 1, minWidth: 0 }}>
          <div style={{ width: 24, height: 24, flexShrink: 0, display: "flex", alignItems: "center" }}>
            <PerformanceIcon color={labelColor} />
          </div>
          <p
            style={{
              margin: 0,
              fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
              fontWeight: "var(--font-lead-weight, 500)" as React.CSSProperties["fontWeight"],
              fontSize: "var(--font-lead-size, 20px)",
              lineHeight: "var(--font-lead-line-height, 30px)",
              letterSpacing: "var(--font-lead-letter-spacing, 0.1px)",
              color: labelColor,
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              flex: 1,
              minWidth: 0,
              transition: "color 0.15s ease",
            }}
          >
            {label}
          </p>
        </div>

        {/* Arrow circle right */}
        <div style={{ paddingLeft: 10, display: "flex", alignItems: "center", flexShrink: 0 }}>
          <ArrowCircleRightIcon color={labelColor} />
        </div>
      </div>
    </div>
  );
}
