import { useState } from "react";

interface ScrollbarProps {
  height?: number | string;
}

export default function Scrollbar({ height = 255 }: ScrollbarProps) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-end",
        height: typeof height === "number" ? `${height}px` : height,
        width: hovered ? 11 : 8,
        transition: "width 0.15s ease",
        position: "relative",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        style={{
          height: "100%",
          width: hovered ? 8 : 4,
          background: "var(--scrollbar-track, #b6b6b6)",
          borderRadius: 8,
          transition: "width 0.15s ease",
          flexShrink: 0,
        }}
      />
    </div>
  );
}
