import { useState } from "react";
import MenuItem from "./MenuItem";

interface DropdownMenuProps {
  placeholder?: string;
  items?: string[];
  disabled?: boolean;
  defaultOpen?: boolean;
}

/* Icon: dds2_chevron-up.svg */
const ChevronIcon = ({ rotated }: { rotated: boolean }) => (
  <svg
    width="14" height="14" viewBox="0 0 16 16" fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={{ transform: rotated ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s ease", flexShrink: 0 }}
  >
    <path d="M1 11L8 4L15 11" stroke="var(--menu-items-label, #0e0e0e)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export default function DropdownMenu({
  placeholder = "Select an option",
  items = ["Menu item 1", "Menu item 2", "Menu item 3"],
  disabled = false,
  defaultOpen = false,
}: DropdownMenuProps) {
  const [open, setOpen] = useState(defaultOpen);
  const [selected, setSelected] = useState<string | null>(null);
  const [hovered, setHovered] = useState(false);

  const handleSelect = (item: string) => {
    setSelected(item);
    setOpen(false);
  };

  // Trigger border priority: disabled > open/selected > hover > default
  const triggerBorder = disabled
    ? "1px solid var(--menu-items-border-disabled, #d2d2d2)"
    : open
    ? "1px solid var(--menu-items-field-border-selected, #0063b8)"
    : hovered
    ? "1px solid var(--menu-items-field-border-selected, #0063b8)"
    : "1px solid var(--menu-items-field-border-default, #d2d2d2)";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 184, width: 184, position: "relative" }}>
      {/* Trigger field */}
      <div
        onClick={() => !disabled && setOpen(!open)}
        onMouseEnter={() => !disabled && setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "8px 12px",
          borderRadius: 4,
          border: triggerBorder,
          background: "var(--menu-items-background, #ffffff)",
          cursor: disabled ? "not-allowed" : "pointer",
          boxSizing: "border-box",
          transition: "border-color 0.15s ease",
        }}
      >
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: 400 as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-body-3-size, 14px)",
            lineHeight: "var(--font-body-3-line-height, 20px)",
            letterSpacing: "var(--font-body-3-letter-spacing, 0.07px)",
            color: disabled
              ? "var(--menu-items-label-disabled, #b6b6b6)"
              : "var(--menu-items-label, #0e0e0e)",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            flex: 1,
          }}
        >
          {selected ?? placeholder}
        </p>
        <div style={{ width: 24, height: 24, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <ChevronIcon rotated={!open} />
        </div>
      </div>

      {/* Menu panel */}
      {open && (
        <div
          style={{
            background: "var(--menu-items-background, #ffffff)",
            borderRadius: 4,
            padding: "8px 3px",
            display: "flex",
            flexDirection: "column",
            gap: 4,
            boxShadow: "0px 4px 4px 0px rgba(0, 42, 88, 0.08)",
            width: "100%",
            boxSizing: "border-box",
          }}
        >
          {items.map((item, i) => (
            <MenuItem
              key={i}
              text={item}
              selected={selected === item}
              onClick={() => handleSelect(item)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
