import { useState } from "react";

interface ExploreCardProps {
  text?: string;
  state?: "default" | "hover";
  onLearnMore?: () => void;
}

const PerformanceIcon = () => (
  /* Icon: dds2_performance.svg */
  <svg width="26" height="26" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clipPath="url(#perf-clip)">
      <path
        d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346625 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C16 5.87827 15.1571 3.84344 13.6569 2.34315C12.1566 0.842855 10.1217 0 8 0ZM3.57 13.33L4.33 12.58L3.57 11.82L2.81 12.58C1.81068 11.4535 1.20672 10.0314 1.09 8.53H2.15V7.47H1.09C1.2173 5.98615 1.8206 4.58314 2.81 3.47L3.57 4.23L4.33 3.48L3.57 2.72C4.67719 1.80582 6.03873 1.25422 7.47 1.14V2.14H8.54V1.14C10.013 1.25093 11.4131 1.82499 12.54 2.78L11.84 3.48L12.6 4.24L13.29 3.54C14.2589 4.66025 14.841 6.0629 14.95 7.54H13.85V8.53H14.91C14.7989 10.0066 14.2171 11.4086 13.25 12.53L12.56 11.84L11.8 12.59L12.49 13.28C11.2516 14.3415 9.67709 14.93 8.04599 14.941C6.41489 14.952 4.83263 14.3848 3.58 13.34L3.57 13.33Z"
        fill="var(--card-explore-default-icon-default, #f5f6f7)"
      />
      <path
        d="M12.15 6.73L11.82 5.93L7.65 6.71C7.2912 6.75276 6.96219 6.9307 6.73 7.20757C6.49781 7.48444 6.37991 7.83941 6.4003 8.20018C6.4207 8.56094 6.57786 8.90037 6.83978 9.1493C7.1017 9.39824 7.44867 9.53796 7.81 9.54C8.13424 9.53658 8.44783 9.42383 8.7 9.22L11.82 7L12.15 6.74V6.73ZM8 8.44C7.95748 8.46194 7.91092 8.47493 7.86318 8.47816C7.81544 8.4814 7.76755 8.47481 7.72246 8.45881C7.67737 8.4428 7.63604 8.41773 7.60102 8.38512C7.566 8.35252 7.53804 8.31308 7.51886 8.26925C7.49968 8.22541 7.4897 8.17811 7.48952 8.13027C7.48934 8.08242 7.49897 8.03505 7.51783 7.99107C7.53668 7.94709 7.56434 7.90745 7.59912 7.87459C7.63389 7.84172 7.67503 7.81634 7.72 7.8L9.34 7.49L8 8.44Z"
        fill="var(--card-explore-default-icon-default, #f5f6f7)"
      />
    </g>
    <defs>
      <clipPath id="perf-clip">
        <rect width="16" height="16" fill="white" />
      </clipPath>
    </defs>
  </svg>
);

const ChevronRightIcon = ({ color }: { color: string }) => (
  /* Icon: dds2_chevron-right.svg */
  <svg width="8" height="11" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.38 0L3.62 0.76L10.86 8L3.62 15.24L4.38 16L12.38 8L4.38 0Z" fill={color} />
  </svg>
);

export default function ExploreCard({
  text = "Improve app performance when system resources are limited.",
  state = "default",
  onLearnMore,
}: ExploreCardProps) {
  const [hovered, setHovered] = useState(false);
  const isHovered = state === "hover" || hovered;

  const background = isHovered
    ? "var(--card-explore-hover-background-hover, #ffffff)"
    : "var(--card-explore-default-background-default, #ffffff99)";

  const border = isHovered
    ? "2px solid var(--card-explore-hover-border-hover, #ffffff)"
    : "2px solid var(--card-explore-default-border-default, #ffffff)";

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        width: 187,
        minWidth: 187,
        height: 178,
        padding: "20px 20px 10px 20px",
        background,
        border,
        borderRadius: 13,
        overflow: "hidden",
        boxSizing: "border-box",
        transition: "background 0.15s ease, border-color 0.15s ease",
        cursor: "pointer",
      }}
    >
      {/* Top: icon + text */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10, width: "100%" }}>
        <div
          style={{
            width: 46,
            height: 46,
            borderRadius: "50%",
            background: "var(--card-explore-default-icon-background-default, #0672cb)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
          }}
        >
          <PerformanceIcon />
        </div>
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-caption-weight, 400)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-caption-size, 12px)",
            lineHeight: "var(--font-caption-line-height, 20px)",
            letterSpacing: "var(--font-caption-letter-spacing, 0.06px)",
            color: "var(--card-explore-default-text-default, #0e0e0e)",
            wordBreak: "break-word",
          }}
        >
          {text}
        </p>
      </div>

      {/* Bottom: Learn more link */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, height: 32 }}>
        <button
          onClick={onLearnMore}
          style={{
            background: "none",
            border: "none",
            padding: "4px 0",
            cursor: "pointer",
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-button-2-weight, 500)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-button-2-size, 14px)",
            lineHeight: "var(--font-button-2-line-height, 24px)",
            letterSpacing: "var(--font-button-2-letter-spacing, 0.07px)",
            color: "var(--card-explore-default-link-default, #0063b8)",
            whiteSpace: "nowrap",
          }}
        >
          Learn more
        </button>
        {/* Icon: dds2_chevron-right.svg */}
        <ChevronRightIcon color="var(--card-explore-default-link-default, #0063b8)" />
      </div>
    </div>
  );
}
