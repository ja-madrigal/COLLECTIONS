import { useState } from "react";

interface MenuItemProps {
  text?: string;
  /** selected = item was clicked and is now the active selection.
   *  Renders with hover text color but no background — confirmed from Figma
   *  (third state in screenshot reuses text-hover token without background). */
  selected?: boolean;
  onClick?: () => void;
}

export default function MenuItem({
  text = "Menu item",
  selected = false,
  onClick,
}: MenuItemProps) {
  const [hovered, setHovered] = useState(false);

  const background = hovered
    ? "var(--menu-items-background-hover, #94dcf7)"
    : "transparent";

  const color = hovered || selected
    ? "var(--menu-items-text-hover, #0063b8)"
    : "var(--menu-items-label, #0e0e0e)";

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "flex",
        alignItems: "center",
        padding: "8px 16px",
        width: 178,
        minHeight: 36,
        boxSizing: "border-box",
        cursor: "pointer",
        background,
        transition: "background 0.1s ease",
      }}
    >
      <p
        style={{
          margin: 0,
          fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
          /* Figma: "Smaller/Body 2" — 14px/400/20lh (regular weight, not medium) */
          fontWeight: 400 as React.CSSProperties["fontWeight"],
          fontSize: "var(--font-body-3-size, 14px)",
          lineHeight: "var(--font-body-3-line-height, 20px)",
          letterSpacing: "var(--font-body-3-letter-spacing, 0.07px)",
          color,
          whiteSpace: "nowrap",
          transition: "color 0.1s ease",
        }}
      >
        {text}
      </p>
    </div>
  );
}
