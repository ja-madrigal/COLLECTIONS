import { useState } from "react";

interface ToggleSwitchProps {
  label?: string;
  defaultChecked?: boolean;
  disabled?: boolean;
  onChange?: (checked: boolean) => void;
  showLabel?: boolean;
}

export default function ToggleSwitch({
  label,
  defaultChecked = false,
  disabled = false,
  onChange,
  showLabel = true,
}: ToggleSwitchProps) {
  const [checked, setChecked] = useState(defaultChecked);
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const handleClick = () => {
    if (disabled) return;
    const next = !checked;
    setChecked(next);
    onChange?.(next);
  };

  // Track background — off background is invariant across hover/pressed per Figma;
  // only on-state background shifts through the blue progression.
  const trackColor = disabled
    ? "var(--toggle-background-disabled, #839db466)"
    : checked
    ? pressed
      ? "var(--toggle-on-background-pressed, #00468b)"
      : hovered
      ? "var(--toggle-on-background-hover, #0063b8)"
      : "var(--toggle-on-background-default, #0672cb)"
    : pressed
    ? "var(--toggle-off-background-pressed, #839db4)"
    : hovered
    ? "var(--toggle-off-background-hover, #839db4)"
    : "var(--toggle-off-background-default, #839db4)";

  // Thumb color — never changes except in disabled state
  const thumbColor = disabled
    ? "var(--toggle-thumb-disabled, #ffffff66)"
    : checked
    ? pressed
      ? "var(--toggle-on-thumb-pressed, #f5f6f7)"
      : hovered
      ? "var(--toggle-on-thumb-hover, #f5f6f7)"
      : "var(--toggle-on-thumb-default, #f5f6f7)"
    : pressed
    ? "var(--toggle-off-thumb-pressed, #f5f6f7)"
    : hovered
    ? "var(--toggle-off-thumb-hover, #f5f6f7)"
    : "var(--toggle-off-thumb-default, #f5f6f7)";

  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 9,
        cursor: disabled ? "not-allowed" : "pointer",
        userSelect: "none",
      }}
      onClick={handleClick}
      onMouseEnter={() => !disabled && setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => !disabled && setPressed(true)}
      onMouseUp={() => setPressed(false)}
    >
      {/* Label */}
      {showLabel && (
        <span
          style={{
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-body-2-weight, 400)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-body-2-size, 16px)",
            lineHeight: "var(--font-body-2-line-height, 24px)",
            letterSpacing: "var(--font-body-2-letter-spacing, 0.08px)",
            color: "var(--toggle-text, #0e0e0e)",
            minWidth: 36,
            textAlign: "right",
            display: "inline-block",
          }}
        >
          {label ?? (checked ? "ON" : "OFF")}
        </span>
      )}

      {/* Track */}
      <div
        style={{
          position: "relative",
          width: 34,
          height: 17,
          borderRadius: 100,
          background: trackColor,
          transition: "background 0.2s ease",
          flexShrink: 0,
        }}
      >
        {/* Thumb */}
        <div
          style={{
            position: "absolute",
            top: 2,
            left: checked ? "calc(100% - 15px)" : 2,
            width: 13,
            height: 13,
            borderRadius: "50%",
            background: thumbColor,
            transition: "left 0.2s ease, background 0.2s ease",
            boxShadow: "0 1px 2px rgba(0,0,0,0.2)",
          }}
        />
      </div>
    </div>
  );
}
