type AlertStatus = "warning" | "note" | "congratulation" | "critical";

interface AlertProps {
  status?: AlertStatus;
  text?: string;
  showClose?: boolean;
  onClose?: () => void;
}

/* Icon: dds2_alert-notice.svg — icon color is --alert-label for every status, confirmed
   with the design system 2026-09-18 (see constitution D-016). The bar (see statusConfig
   below) carries the per-status indicator color; the icon does not. */
const AlertNoticeIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M9 1L1 16h16L9 1zm0 3l6 11H3L9 4zm-.75 3v4h1.5V7h-1.5zm0 5v1.5h1.5V12h-1.5z"
      fill="var(--alert-label, #f5f6f7)"
    />
  </svg>
);

/* Icon: dds2_alert-info-cir.svg — see D-016; colored via --alert-label, not the indicator token. */
const AlertInfoIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      fillRule="evenodd" clipRule="evenodd"
      d="M9 0C4.037 0 0 4.037 0 9s4.037 9 9 9 9-4.037 9-9-4.037-9-9-9zm1 13H8V8h2v5zm0-7H8V4h2v2z"
      fill="var(--alert-label, #f5f6f7)"
    />
  </svg>
);

/* Icon: dds2_alert-check-cir.svg — see D-016; colored via --alert-label, not the indicator token. */
const AlertCheckIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      fillRule="evenodd" clipRule="evenodd"
      d="M9 0C4.037 0 0 4.037 0 9s4.037 9 9 9 9-4.037 9-9-4.037-9-9-9zm-1.5 13L3 8.5l1.4-1.4 3.1 3.1 6.1-6.1L15 5.5 7.5 13z"
      fill="var(--alert-label, #f5f6f7)"
    />
  </svg>
);

/* Icon: dds2_alert-error.svg — GHOST override for critical status (see constitution D-011). Design system pairs alert-critical with dds2_close-cir; GHOST swaps in the error icon for clarity, since a close-style glyph reads as dismiss and this variant already has its own close button. Colored via --alert-label per the design system's alert-error usage, not the red indicator token. */
const AlertErrorIcon = () => (
  <svg width="18" height="18" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7.5 10.5L7.5 3.5H8.5V10.5H7.5Z" fill="var(--alert-label, #f5f6f7)" />
    <path d="M7.5 11.5V12.5H8.5V11.5H7.5Z" fill="var(--alert-label, #f5f6f7)" />
    <path
      fillRule="evenodd" clipRule="evenodd"
      d="M0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8ZM8 1C4.13401 1 1 4.13401 1 8C1 11.866 4.13401 15 8 15C11.866 15 15 11.866 15 8C15 4.13401 11.866 1 8 1Z"
      fill="var(--alert-label, #f5f6f7)"
    />
  </svg>
);

/* Icon: dds2_close-x.svg */
const CloseIcon = () => (
  <svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M1 1l9 9M10 1L1 10" stroke="var(--alert-label, #f5f6f7)" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const statusConfig: Record<AlertStatus, { token: string; fallback: string; icon: React.ReactNode }> = {
  warning:       { token: "--alert-indicator-warning", fallback: "#e67f01", icon: <AlertNoticeIcon /> },
  note:          { token: "--alert-indicator-info",    fallback: "#31a2e3", icon: <AlertInfoIcon /> },
  congratulation:{ token: "--alert-indicator-success", fallback: "#7aa809", icon: <AlertCheckIcon /> },
  critical:      { token: "--alert-indicator-error",   fallback: "#d0353f", icon: <AlertErrorIcon /> },
};

export default function Alert({
  status = "warning",
  text = "Your battery health is poor and needs to be replaced.",
  showClose = true,
  onClose,
}: AlertProps) {
  const { token, fallback, icon } = statusConfig[status];

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        minHeight: 53,
        maxHeight: 93,
        minWidth: 260,
        borderRadius: 4,
        background: "var(--alert-background, #141d28)",
        overflow: "hidden",
        boxSizing: "border-box",
      }}
    >
      {/* Left color bar */}
      <div
        style={{
          width: 7,
          alignSelf: "stretch",
          background: `var(${token}, ${fallback})`,
          flexShrink: 0,
        }}
      />

      {/* Icon + text */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          flex: 1,
          minWidth: 0,
          padding: "16.5px 0",
        }}
      >
        <div style={{ flexShrink: 0, display: "flex", alignItems: "center" }}>
          {icon}
        </div>
        <p
          style={{
            margin: 0,
            fontFamily: "var(--font-family-base, 'Roboto', sans-serif)",
            fontWeight: "var(--font-body-3-weight, 400)" as React.CSSProperties["fontWeight"],
            fontSize: "var(--font-body-3-size, 14px)",
            lineHeight: "var(--font-body-3-line-height, 20px)",
            letterSpacing: "var(--font-body-3-letter-spacing, 0.07px)",
            color: "var(--alert-label, #f5f6f7)",
            overflow: "hidden",
            display: "-webkit-box",
            WebkitLineClamp: 3,
            WebkitBoxOrient: "vertical",
          }}
        >
          {text}
        </p>
      </div>

      {/* Close button */}
      {showClose && (
        <div
          onClick={onClose}
          style={{
            padding: "0 16px",
            alignSelf: "stretch",
            display: "flex",
            alignItems: "center",
            cursor: "pointer",
            flexShrink: 0,
          }}
        >
          {/* Icon: dds2_close-x.svg */}
          <CloseIcon />
        </div>
      )}
    </div>
  );
}
