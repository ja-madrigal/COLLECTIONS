# Unity.WinUI preview testing

`Unity.WinUI` is a pre-release NuGet package for evaluating the completed UNITY WinUI 3 controls in real applications.

Current package: `Unity.WinUI.0.1.0-preview.4.nupkg`

Validated configuration:

- .NET 8
- WinUI 3
- Microsoft Windows App SDK 2.3.1
- Debug x64
- Windows 10 version 1809 or later

## What to share

Send testers:

1. `artifacts\packages\Unity.WinUI.0.1.0-preview.4.nupkg`
2. This guide
3. Optionally, the `PackageConsumer.WinUI` sample project

The full `ControlSpecs.WinUI` harness is useful as the visual catalog, but applications should consume the NuGet package rather than copying harness code.

## Install from a local folder

Place the `.nupkg` in a folder available to the application team. Add that folder as a NuGet source in Visual Studio, or create a `NuGet.config` beside the consuming project:

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
    <add key="UnityPreview" value="C:\path\to\unity-package-folder" />
    <add key="nuget.org" value="https://api.nuget.org/v3/index.json" />
  </packageSources>
</configuration>
```

Add the package reference:

```xml
<PackageReference Include="Unity.WinUI" Version="0.1.0-preview.4" />
```

The consuming application should use the same Windows App SDK version during this preview:

```xml
<PackageReference Include="Microsoft.WindowsAppSDK" Version="2.3.1" />
```

## Register the UNITY resources

Merge the UNITY entry dictionary after `XamlControlsResources` in `App.xaml`:

```xml
<Application.Resources>
    <ResourceDictionary>
        <ResourceDictionary.MergedDictionaries>
            <controls:XamlControlsResources />
            <ResourceDictionary Source="ms-appx:///DesignSystem.WinUI/Themes/Generic.xaml" />
        </ResourceDictionary.MergedDictionaries>
    </ResourceDictionary>
</Application.Resources>
```

Add this namespace when using custom UNITY controls:

```xml
xmlns:unity="using:DesignSystem.WinUI.Controls"
```

## Included completed controls

- Button: Primary, Secondary, Tertiary, and Destructive styles and sizes
- Alert / InfoBar
- Busy Indicator / ProgressRing, including determinate
- Basic Tile
- Card Main
- Check box
- Control Layer / Expander
- Drop Down Field and List Menu / ComboBox
- Text Link / HyperlinkButton
- `UnityToast`
- `UnityMasthead`

Placeholder TextBox, Banner, Form Field, and Modal resources are intentionally excluded from this preview package.

## Quick smoke test

```xml
<StackPanel Spacing="16">
    <Button Content="Continue"
            Style="{StaticResource DesignSystemPrimaryButtonStyle}" />

    <CheckBox Content="Send diagnostics"
              Style="{StaticResource DesignSystemCheckBoxStyle}" />

    <unity:UnityToast Message="Package loaded successfully."
                      IsOpen="True"
                      IsAutoDismissEnabled="False" />
</StackPanel>
```

## Feedback requested

Ask testers to report:

- Application target framework and Windows App SDK version
- Architecture tested: x64, x86, or ARM64
- Light, Dark, and High Contrast observations
- Keyboard navigation and visible focus behavior
- Screen-reader or UI Automation observations
- Controls that are difficult to discover or configure
- Missing public properties or common compositions
- Screenshots and the smallest XAML example that reproduces an issue

This is a preview API. Style keys, package setup, and custom-control properties may change before the first stable release.
