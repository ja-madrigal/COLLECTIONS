# AI agent instructions for UNITY WinUI

## Objective

Build and modify WinUI 3 applications using the `Unity.WinUI` design-system package. Reuse the package controls, style keys, tokens, and behaviors. Do not recreate UNITY visuals locally unless a required API is genuinely missing and the user explicitly approves extending the design system.

## Required reading

Before changing application UI, read:

1. `ai/UNITY_WINUI_AI_GUIDE.md`
2. `ai/unity-winui.catalog.json`
3. `UNITY_WINUI_PREVIEW_TESTING.md`
4. `PackageConsumer.WinUI/MainWindow.xaml` for a known-good package consumer

## Supported stack

- Windows desktop application
- C# and WinUI 3
- .NET 8: `net8.0-windows10.0.19041.0`
- Microsoft Windows App SDK 2.3.1
- `Unity.WinUI` 0.1.0-preview.4
- Validated configuration: Debug x64

Do not convert these controls to WPF, UWP, MAUI, web, React, or another UI framework. UNITY is derived from DDS but is the WinUI design system for on-the-box applications. The `dds2_` prefix remains on inherited icon assets.

## Package setup

The local package is:

`artifacts/packages/Unity.WinUI.0.1.0-preview.4.nupkg`

Consumer projects must reference the package, not compile or link files from `DesignSystem.WinUI`.

```xml
<PackageReference Include="Unity.WinUI" Version="0.1.0-preview.4" />
```

Merge the resource dictionary after `XamlControlsResources`:

```xml
<ResourceDictionary Source="ms-appx:///DesignSystem.WinUI/Themes/Generic.xaml" />
```

Custom controls use:

```xml
xmlns:unity="using:DesignSystem.WinUI.Controls"
```

## UI rules

- Consult `ai/unity-winui.catalog.json` before selecting a native control or style key.
- Preserve native WinUI keyboard, focus, automation, selection, and accessibility behavior.
- Use `ThemeResource` and package tokens. Do not hardcode colors already represented by UNITY resources.
- Support Light and Dark themes. Do not assume WinUI’s default foreground is correct for a custom surface.
- Use approved DDS SVG/vector geometry. Do not approximate icons with Unicode characters or unrelated font glyphs.
- Keep `UnityToast` inside the application window. It is not a Windows notification and must not appear outside the app window.
- Treat `UnityMasthead` caption buttons in the catalog harness as previews. Windows owns actual minimize, maximize/restore, and close behavior when a title bar is registered with a real window.
- Do not expose placeholder TextBox, Banner, Form Field, or Modal resources as completed UNITY controls.
- Do not silently change the package version, Windows App SDK version, target framework, or architecture.

## Build and validation

On Windows, restore and build the consumer project:

```powershell
dotnet restore .\PackageConsumer.WinUI\PackageConsumer.WinUI.csproj -p:Platform=x64 --configfile .\PackageConsumer.WinUI\NuGet.config
dotnet build .\PackageConsumer.WinUI\PackageConsumer.WinUI.csproj -c Debug -p:Platform=x64 --no-restore
```

After XAML or resource changes, launch the executable. A successful compile is insufficient because some WinUI resource failures occur only at runtime.

Validate:

- Light and Dark themes
- Keyboard navigation and visible focus
- Pointer-over, pressed, disabled, selected, error, expanded, and open states as applicable
- UI Automation names and native patterns
- Layout at common DPI scaling values

If the agent environment is not Windows, perform static code changes only. Do not claim that WinUI compiled or rendered successfully. Leave the exact Windows validation commands and identify what still requires Visual Studio or a Windows runner.

## Repository boundaries

- `DesignSystem.WinUI/`: reusable source and NuGet project
- `ControlSpecs.WinUI/`: full visual specification harness
- `PackageConsumer.WinUI/`: clean NuGet consumer smoke-test app
- `controls/`: design source documents
- `artifacts/packages/`: generated preview packages
- `ai/`: AI-facing catalog, examples, and prompts

The working tree may contain accumulated implementation work and visual QA artifacts. Preserve unrelated changes. Do not reset or discard them.
