---
agent: 'agent'
description: 'Build or extend a WinUI 3 application using the Unity.WinUI preview package'
---

Build or extend this Windows desktop application using the UNITY WinUI design system.

Feature or screen to implement:

${input:feature:Describe the screen, workflow, or feature to build}

Requirements:

1. Read `AGENTS.md`, `ai/UNITY_WINUI_AI_GUIDE.md`, and `ai/unity-winui.catalog.json` before editing.
2. Confirm the project is C# WinUI 3 targeting .NET 8 and Microsoft Windows App SDK 2.3.1.
3. Install `Unity.WinUI` 0.1.0-preview.4 from the configured local/private NuGet source.
4. Merge `ms-appx:///DesignSystem.WinUI/Themes/Generic.xaml` after `XamlControlsResources` if it is not already registered.
5. Use exact catalog style keys and custom-control APIs. Do not reproduce UNITY colors, templates, typography, or icons in application-local resources.
6. Preserve native accessibility, keyboard, focus, selection, and automation behavior.
7. Implement useful empty, loading, error, disabled, and success states where the requested workflow requires them.
8. Validate Light and Dark themes.
9. On Windows, build Debug x64 and launch the application. Report compile and runtime validation separately.
10. If Windows execution is unavailable, complete static implementation, provide the exact Windows build/run commands, and explicitly mark visual validation as pending.

Before finishing, list:

- UNITY controls and style keys used
- Files changed
- Validation completed
- Any missing design-system capability that required an application-level workaround
