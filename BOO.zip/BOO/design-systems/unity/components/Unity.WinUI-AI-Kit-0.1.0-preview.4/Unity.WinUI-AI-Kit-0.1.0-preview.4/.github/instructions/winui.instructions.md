---
description: 'UNITY requirements for WinUI XAML, C#, and project files'
applyTo: '**/*.{xaml,cs,csproj}'
---

- Target C# WinUI 3, .NET 8, and Microsoft Windows App SDK 2.3.1.
- Use `Unity.WinUI` 0.1.0-preview.4 through `PackageReference` in consumer applications.
- Select controls and exact resource keys from `ai/unity-winui.catalog.json`.
- Never recreate a packaged UNITY style locally to make a screen look approximately correct.
- Keep application-specific layout and data binding in the app; keep reusable design-system fixes in `DesignSystem.WinUI`.
- Preserve dependency properties, routed/native events, keyboard behavior, UI Automation, and theme resources.
- Treat build success and runtime XAML loading as separate validation gates.
