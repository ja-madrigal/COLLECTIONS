# Unity.WinUI AI consumer kit

This kit lets an application team or AI coding tool build a C# WinUI 3 application using `Unity.WinUI` 0.1.0-preview.4.

## Fastest test in Visual Studio

1. Extract the kit on a Windows development machine.
2. Open `PackageConsumer.WinUI\PackageConsumer.WinUI.csproj` in Visual Studio.
3. Restore NuGet packages.
4. Select **Debug** and **x64**.
5. Build and run.

The sample consumes the `.nupkg` from the kit’s `packages` directory. It does not contain or link the design-system source.

## Use the kit with Devin

1. Copy `AGENTS.md`, `.github`, `ai`, and `packages` into the root of the application repository.
2. Commit those files so Devin receives them when it clones the repository.
3. Connect the repository to Devin.
4. Paste the prompt from `ai\DEVIN_STARTER_PROMPT.md` and replace the bracketed application description.
5. Let Devin implement the application.
6. If Devin is not running on Windows, pull its branch and perform the final build/runtime validation in Visual Studio.

For a private team feed, upload the `.nupkg` and replace the local folder source with the private NuGet source. Do not commit credentials in `NuGet.config`.

## Use the kit with Visual Studio Copilot

1. Keep `.github\copilot-instructions.md` in the repository.
2. Enable repository custom instructions in Visual Studio Copilot settings.
3. Type `/build-unity-winui-app` in Copilot Chat.
4. Provide the feature description.
5. Confirm Copilot references the repository instructions and selects style keys from `ai\unity-winui.catalog.json`.

## Important

- This is a preview API.
- Validated stack: .NET 8, WinUI 3, Windows App SDK 2.3.1, Debug x64.
- `UnityToast` must remain inside the application window.
- Actual window caption behavior belongs to Windows, not the Masthead gallery preview.
- Placeholder TextBox, Banner, Form Field, and Modal controls are not included.
