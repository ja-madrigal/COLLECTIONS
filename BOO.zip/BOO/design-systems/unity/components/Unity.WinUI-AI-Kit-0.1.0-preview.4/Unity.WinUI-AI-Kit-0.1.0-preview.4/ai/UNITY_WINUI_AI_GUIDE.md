# Using Unity.WinUI with AI coding tools

This guide supplies the context an AI coding agent needs to build a real WinUI 3 application with the UNITY design-system package instead of approximating the controls.

## Authoritative inputs

Use these sources in this order:

1. `ai/unity-winui.catalog.json` for supported controls, style keys, and public APIs
2. `ai/UNITY_XAML_RECIPES.md` for copyable integration patterns
3. `PackageConsumer.WinUI` for a working package consumer
4. `ControlSpecs.WinUI` for the complete visual/state harness
5. `controls/` documents for design intent and specification details

The package implementation is the source of runtime behavior. Screenshots and specification documents are validation references, not code dependencies.

## Current compatibility contract

| Setting | Required preview value |
|---|---|
| UI framework | WinUI 3 |
| Language | C# |
| Target framework | `net8.0-windows10.0.19041.0` |
| Windows App SDK | `2.3.1` |
| UNITY package | `Unity.WinUI` `0.1.0-preview.4` |
| Validated platform | Debug x64 |
| Minimum Windows version | 10.0.17763.0 |

The preview package has not yet been fully validated on x86 or ARM64. Do not silently downgrade or upgrade the Windows App SDK to resolve a package mismatch.

## What an AI agent should do

1. Inspect the consuming `.csproj` and confirm it is a WinUI 3 application.
2. Configure a local or private NuGet source containing the `.nupkg`.
3. Add the exact `PackageReference`.
4. Merge the UNITY resource dictionary at application scope.
5. Choose native controls and exact style keys from the catalog.
6. Use `DesignSystem.WinUI.Controls` only for `UnityToast` and `UnityMasthead`.
7. Keep screen layout, view models, commands, and application-specific content in the consuming app.
8. Keep reusable visual corrections in the design-system project, not duplicated in the app.
9. Build and launch on Windows.
10. Compare Light and Dark results with the harness.

## What an AI agent must not do

- Do not copy `DesignSystem.WinUI` source files into a consumer project.
- Do not replace an unavailable style key with a similarly named guess.
- Do not hardcode package colors or reconstruct templates in a page resource dictionary.
- Do not create WPF, UWP, MAUI, web, or React equivalents and call them UNITY WinUI controls.
- Do not invent icons with text characters.
- Do not claim visual validation from a Linux-only agent environment.
- Do not use `UnityToast` as a Windows system notification.
- Do not make the gallery caption preview responsible for real window operations.

## Devin workflow

Devin reads the repository-root `AGENTS.md`. Connect Devin to a repository containing:

- `AGENTS.md`
- `ai/`
- the application source
- access to the `Unity.WinUI` package through either a committed local package folder or a private NuGet feed

Start with the prompt in `ai/DEVIN_STARTER_PROMPT.md`. If Devin’s execution environment is not Windows, ask it to implement the project statically, commit the changes, and provide the exact Windows validation commands. Pull the branch and perform the final build in Visual Studio on Windows.

## Visual Studio Copilot workflow

Visual Studio automatically uses `.github/copilot-instructions.md` when repository custom instructions are enabled. The path-specific `.github/instructions/winui.instructions.md` applies to XAML, C#, and project files.

In Copilot Chat, invoke the reusable prompt:

```text
/build-unity-winui-app
```

Provide the feature or screen description when prompted. Confirm `.github/copilot-instructions.md` appears in the Copilot response references.

## Expected agent report

Every AI implementation should finish with:

- Package/version used
- UNITY style keys and custom controls used
- Files changed
- Build result
- Runtime launch result
- Theme/accessibility checks performed
- Known gaps or pending Windows validation

Passing compilation does not prove that WinUI resource dictionaries load correctly. Runtime launch is a separate requirement.
