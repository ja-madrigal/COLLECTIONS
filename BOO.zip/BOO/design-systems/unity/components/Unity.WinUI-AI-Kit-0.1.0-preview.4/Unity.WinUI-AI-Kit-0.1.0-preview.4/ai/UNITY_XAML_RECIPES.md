# UNITY WinUI XAML recipes

These recipes are safe starting points for AI-generated applications. Use exact package style keys. Application-specific text, bindings, commands, and approved icon content remain the responsibility of the consuming app.

## Package and application resources

```xml
<PackageReference Include="Microsoft.WindowsAppSDK" Version="2.3.1" />
<PackageReference Include="Unity.WinUI" Version="0.1.0-preview.4" />
```

```xml
<Application
    x:Class="MyApp.App"
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    xmlns:controls="using:Microsoft.UI.Xaml.Controls">
    <Application.Resources>
        <ResourceDictionary>
            <ResourceDictionary.MergedDictionaries>
                <controls:XamlControlsResources />
                <ResourceDictionary Source="ms-appx:///DesignSystem.WinUI/Themes/Generic.xaml" />
            </ResourceDictionary.MergedDictionaries>
        </ResourceDictionary>
    </Application.Resources>
</Application>
```

Add the namespace to pages using custom controls:

```xml
xmlns:unity="using:DesignSystem.WinUI.Controls"
```

## Buttons

```xml
<StackPanel Orientation="Horizontal" Spacing="12">
    <Button Content="Continue"
            Style="{StaticResource DesignSystemPrimaryButtonStyle}" />
    <Button Content="Not now"
            Style="{StaticResource DesignSystemSecondaryButtonStyle}" />
    <Button Content="Learn more"
            Style="{StaticResource DesignSystemTertiaryButtonStyle}" />
    <Button Content="Delete"
            Style="{StaticResource DesignSystemDestructiveButtonStyle}" />
</StackPanel>
```

Use the corresponding `SmallStyle` or `LargeStyle` catalog key only when the specification calls for that size.

## Alert / InfoBar

```xml
<InfoBar IsOpen="True"
         IsClosable="True"
         Severity="Informational"
         Message="Your changes were saved."
         Style="{StaticResource DesignSystemAlertInfoStyle}">
    <InfoBar.IconSource>
        <ImageIconSource>
            <ImageIconSource.ImageSource>
                <SvgImageSource UriSource="ms-appx:///DesignSystem.WinUI/Assets/Icons/Alert/dds2_alert-info-cir.svg" />
            </ImageIconSource.ImageSource>
        </ImageIconSource>
    </InfoBar.IconSource>
</InfoBar>
```

Match the severity, style, and icon paths listed in `unity-winui.catalog.json`.

## Busy Indicator / ProgressRing

```xml
<ProgressRing IsActive="True"
              AutomationProperties.Name="Loading"
              AutomationProperties.LiveSetting="Polite"
              Style="{StaticResource DesignSystemBusyIndicatorDotStyle}" />
```

```xml
<ProgressRing IsActive="True"
              Minimum="0"
              Maximum="100"
              Value="65"
              AutomationProperties.Name="Loading, 65 percent complete"
              AutomationProperties.LiveSetting="Polite"
              Style="{StaticResource DesignSystemBusyIndicatorDeterminateStyle}" />
```

## Check box

```xml
<CheckBox Content="Send diagnostics"
          IsChecked="True"
          Style="{StaticResource DesignSystemCheckBoxStyle}" />
```

```xml
<CheckBox Content="Accept the required terms"
          Style="{StaticResource DesignSystemCheckBoxErrorStyle}"
          AutomationProperties.HelpText="You must accept the terms to continue." />
```

## Drop Down Field and List Menu

```xml
<ComboBox Header="Performance mode"
          PlaceholderText="Select an option"
          SelectedIndex="0"
          Style="{StaticResource DesignSystemDropDownFieldStyle}">
    <ComboBoxItem Content="Recommended"
                  Style="{StaticResource DesignSystemListMenuItemStyle}" />
    <ComboBoxItem Content="Balanced"
                  Style="{StaticResource DesignSystemListMenuItemStyle}" />
    <ComboBoxItem Content="Performance"
                  Style="{StaticResource DesignSystemListMenuItemStyle}" />
</ComboBox>
```

Use native `ItemsSource`, `SelectedItem`, and data templates for dynamic data. Preserve the `ComboBoxItem` container style.

## Control Layer / Expander

```xml
<Expander Header="Advanced settings"
          IsExpanded="False"
          Style="{StaticResource DesignSystemControlLayerExpanderStyle}">
    <StackPanel Spacing="12">
        <TextBlock Text="Configure advanced application behavior."
                   TextWrapping="Wrap" />
        <!-- Application-specific controls -->
    </StackPanel>
</Expander>
```

## Text links

```xml
<HyperlinkButton Content="Learn more"
                 NavigateUri="https://example.com"
                 Style="{StaticResource DesignSystemTextLinkStyle}" />
```

```xml
<HyperlinkButton Content="View privacy statement"
                 NavigateUri="https://example.com/privacy"
                 Style="{StaticResource DesignSystemTextLinkUnderlinedStyle}" />
```

For a link embedded in a sentence, use WinUI’s inline `Hyperlink` rather than a `HyperlinkButton`.

## Basic Tile

The tile is one native Button. Supply an approved DDS icon as `TileIcon`; do not use a text character as an icon.

```xml
<Button Command="{Binding OpenApplicationsCommand}"
        AutomationProperties.Name="Applications"
        Style="{StaticResource DesignSystemBasicTileButtonStyle}">
    <Grid ColumnSpacing="16">
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto" />
            <ColumnDefinition Width="*" />
            <ColumnDefinition Width="Auto" />
        </Grid.ColumnDefinitions>

        <ContentControl Width="{StaticResource SizeBasicTilePrimaryIcon}"
                        Height="{StaticResource SizeBasicTilePrimaryIcon}"
                        Content="{Binding TileIcon}" />
        <TextBlock Grid.Column="1"
                   Text="Applications"
                   VerticalAlignment="Center" />
        <PathIcon Grid.Column="2"
                  Width="{StaticResource SizeBasicTileInteractiveIcon}"
                  Height="{StaticResource SizeBasicTileInteractiveIcon}"
                  Data="M4.38 0L3.62 0.76L10.86 8L3.62 15.24L4.38 16L12.38 8L4.38 0Z" />
    </Grid>
</Button>
```

## Card Main

The whole card is one native Button. Do not place another Button or HyperlinkButton inside it.

```xml
<Button Command="{Binding LearnMoreCommand}"
        AutomationProperties.Name="Improve app performance; Learn more"
        Style="{StaticResource DesignSystemCardMainButtonStyle}">
    <StackPanel>
        <ContentControl Width="{StaticResource SizeCardMainThumbnail}"
                        Height="{StaticResource SizeCardMainThumbnail}"
                        Margin="{StaticResource MarginCardMainThumbnailToText}"
                        Content="{Binding ThumbnailIcon}" />
        <TextBlock Text="Improve app performance when system resources are limited."
                   TextWrapping="Wrap"
                   FontFamily="{StaticResource FontFamilyBase}"
                   FontSize="{StaticResource FontSizeCaption}"
                   FontWeight="{StaticResource FontWeightCaption}"
                   CharacterSpacing="{StaticResource CharacterSpacingCaption}"
                   LineHeight="{StaticResource LineHeightCaption}" />
        <StackPanel Orientation="Horizontal"
                    Spacing="{StaticResource GapCardMainActionTextToIcon}">
            <TextBlock Text="Learn more"
                       Padding="{StaticResource PaddingCardMainActionLabel}"
                       FontFamily="{StaticResource FontFamilyBase}"
                       FontSize="{StaticResource FontSizeButton2}"
                       FontWeight="{StaticResource FontWeightButton2}"
                       CharacterSpacing="{StaticResource CharacterSpacingButton2}"
                       LineHeight="{StaticResource LineHeightButton2}" />
            <PathIcon Width="{StaticResource SizeCardMainActionIcon}"
                      Height="{StaticResource SizeCardMainActionIcon}"
                      Data="M4.38 0L3.62 0.76L10.86 8L3.62 15.24L4.38 16L12.38 8L4.38 0Z" />
        </StackPanel>
    </StackPanel>
</Button>
```

## UnityToast

```xml
<unity:UnityToast x:Name="SaveToast"
                  Message="Changes saved."
                  ActionText="Undo"
                  IsOpen="False"
                  IsAutoDismissEnabled="True"
                  Duration="0:0:4"
                  ActionInvoked="SaveToast_ActionInvoked" />
```

```csharp
SaveToast.Show();
```

Keep the toast inside the application window, usually in page layout or an in-window `Popup`.

## UnityMasthead

```xml
<unity:UnityMasthead x:Name="AppMasthead"
                     Title="Device manager"
                     Subtitle="UNITY"
                     IsBackButtonVisible="True"
                     IsPaneToggleButtonVisible="True"
                     BackRequested="AppMasthead_BackRequested"
                     PaneToggleRequested="AppMasthead_PaneToggleRequested">
    <unity:UnityMasthead.LeftHeader>
        <TextBlock Text="SupportAssist"
                   Style="{StaticResource DesignSystemUnityMastheadTextStyle}" />
    </unity:UnityMasthead.LeftHeader>
    <unity:UnityMasthead.MastheadContent>
        <AutoSuggestBox Width="280"
                        Height="36"
                        PlaceholderText="Search" />
    </unity:UnityMasthead.MastheadContent>
    <unity:UnityMasthead.RightHeader>
        <!-- Application actions using approved DDS icon content -->
    </unity:UnityMasthead.RightHeader>
</unity:UnityMasthead>
```

When using it as the real window title bar:

```csharp
ExtendsContentIntoTitleBar = true;
SetTitleBar(AppMasthead.TitleBarElement);
```

Do not reproduce the gallery’s visual caption preview. Windows supplies the actual minimize, maximize/restore, and close behavior.
