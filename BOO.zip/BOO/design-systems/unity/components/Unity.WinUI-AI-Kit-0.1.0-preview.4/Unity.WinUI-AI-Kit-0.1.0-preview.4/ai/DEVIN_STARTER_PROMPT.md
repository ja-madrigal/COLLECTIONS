# Devin starter prompt

Copy this into a new Devin session after connecting the application repository.

```text
Build a C# WinUI 3 desktop application using the Unity.WinUI design-system package.

Before editing, read AGENTS.md, ai/UNITY_WINUI_AI_GUIDE.md,
ai/unity-winui.catalog.json, and ai/UNITY_XAML_RECIPES.md.

Application to build:
[DESCRIBE THE APPLICATION, USERS, AND PRIMARY WORKFLOW]

Required screens and behaviors:
[LIST THE SCREENS, DATA, NAVIGATION, AND IMPORTANT STATES]

Use .NET 8, target net8.0-windows10.0.19041.0, Microsoft Windows
App SDK 2.3.1, and Unity.WinUI 0.1.0-preview.4. Consume the package
through PackageReference. Do not copy or recreate design-system source.

Use exact control/style mappings from the catalog. Support Light and Dark
themes and preserve native keyboard, focus, accessibility, selection, and
UI Automation behavior. Use approved DDS icons; do not approximate them
with Unicode or unrelated font glyphs.

First inspect the repository and provide a short implementation plan.
Then implement the application. If the environment is Windows, restore,
build Debug x64, launch, and validate the runtime XAML. If the environment
is not Windows, make the static code changes but explicitly leave runtime
validation pending and provide exact commands for Visual Studio/Windows.

Finish with the package version, UNITY controls/style keys used, files
changed, validation completed, and any missing design-system capability.
```

## Useful follow-up prompts

```text
Audit this screen against ai/unity-winui.catalog.json. Replace local visual
approximations with the correct Unity.WinUI controls and style keys.
```

```text
Review the WinUI screen for Light/Dark theming, keyboard navigation, focus,
UI Automation names, and native selection behavior. Do not change approved
UNITY dimensions or tokens without identifying the conflict first.
```

```text
Prepare this branch for Windows validation. List every command and every
interaction/state that must be checked in Visual Studio after I pull it.
```
