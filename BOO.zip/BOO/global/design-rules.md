# Unity Design Rules

## Reading Order

The AI must read and apply this document from broad decisions to detailed construction. Do not start by assembling controls.

| Order | Chapter | Why it is read at this stage |
| ---: | --- | --- |
| 1 | [Spacing Hierarchy](#spacing-hierarchy) | Establishes the semantic spacing ladder and structural relationship rules before any layout is applied. |
| 2 | [Container Layer Rules](#container-layer-rules) | Defines the maximum surface depth and nesting rules before panels or cards are constructed. |
| 3 | [Icon Size Rules](#icon-size-rules) | Locks icon sizes and gap rules before controls are assembled. |
| 4 | [Colors](#colors) | Establishes the surface depth model, atmospheric background, and all color token rules before any styling is applied. |
| 5 | [Typography](#typography) | Defines the type tier budget, weight rules, and token usage before text elements are placed. |

## Spacing Hierarchy

Spacing encodes semantic distance. Every step up in relationship distance
uses the next rung of the ladder — never skip rungs, never apply a larger
gap to a tighter relationship.

#### The Gap Ladder

| Rung | Token | Value | Semantic role |
| --- | --- | --- | --- |
| `closely_coupled` | `var(--spacing-closely-coupled)` | 8px | Elements that belong to the **same object** |
| `standard` | `var(--spacing-standard)` | 16px | Elements in the **same section** |
| `major_transition` | `var(--spacing-major-transition)` | 24px | **Different sections** on the same page |
| `guided_narrative` | `var(--spacing-guided-narrative)` | 76px | Full editorial / onboarding narrative inset only |

The `action_group` rung (`var(--spacing-action-group)`, 10px) exists but
is narrow-use only (checkbox + label, paired progression buttons). For
general layout rhythm the operative ladder is
**`closely_coupled` → `standard` → `major_transition`**.

Always write the token, never the pixel value — `token_fidelity_mandate`
applies to spacing exactly as it does to color. There is deliberately no
numeric alias (`--spacing-8` and the like): choosing a gap by its size
rather than by the relationship it encodes is the precise mistake this
ladder exists to prevent.

> These tokens were added on 2026-09-30 (D-055). Before that this table
> named a `spacing.relationship.*` namespace that existed nowhere in the
> repo — the same phantom-namespace problem D-039 found with `--type-*`.
> `tokens.css` owns the values; this file owns which rung applies where.

#### Structural Relationships

**Same object — `closely_coupled`**
Elements that are part of the same logical unit; they describe or modify
each other.
- Page title ↔ subtitle
- Icon ↔ label within a row
- Header ↔ its immediately following content
- Toggle row sub-elements
- Items in a stacked list within one card

**Same section — `standard`**
Distinct elements that share a parent container or conceptual group.
- Content padding inside any card or panel
- Gap between sibling rows in a settings panel
- Label ↔ its control (toggle, dropdown, slider)
- Back arrow ↔ page title
- Column gap between the nav strip and the content area

**Different sections — `major_transition`**
Two independent feature blocks or named sections on the same screen.
- Section A title block ↔ Section B title block
- Gap between named groups inside a scrollable panel
- Masthead paddingX (separates app chrome from content)

**Editorial / narrative — `guided_narrative`**
Only for onboarding or guided walkthrough screens. Never in utility UI.
- Left inset of all text content
- Gap between progress bar and hero headline
- Navigation button anchor matches this same inset

#### Card Auto-Layout Rule

```
Container padding : standard        — all sides
Gap between rows  : closely_coupled — within same card
Gap between cards : major_transition— between distinct cards/sections
```

If a card contains **named sub-sections**, the gap between them inside
the card is `standard`, not `closely_coupled` — because they are
conceptually separate even though physically inside the same container.

#### The One Invariant

Structural depth = spacing token.

| Hierarchy level | Token |
| --- | --- |
| Same atom | `closely_coupled` |
| Same molecule | `standard` |
| Same organism | `major_transition` |
| Page inset | `guided_narrative` |

Never use a larger token for a tighter relationship. Never use a smaller
token across a section boundary.

## Container Layer Rules

Derived from analysis of all 32 Figma frames. Maximum 3 design layers per screen.

| Layer | Role | Background token | Radius token |
| --- | --- | --- | --- |
| **1 — Panel or nav pill** | Primary surface — settings panel or nav rail | `var(--background-container-accent-subtle)` | `var(--radius-surface-primary)` (16px) for panels; pills use `var(--radius-pill)` (100px) |
| **2 — Feature group** | Groups related controls under a heading | `var(--background-container-accent-base)` | `var(--radius-surface-secondary)` (8px) |
| **3 — Feature row / atom** | Individual control row, toggle, or selector | `var(--background-surface)` | `var(--radius-button)` (2px) |

**What gets a layer at all — chrome vs. content**

Confirmed 2026-10-02 from a real DACC screen (D-061). The atmospheric background is not a surface
you place things on freely, but it is also not off-limits:

- **On the background, with no container:** navigation and location chrome only — the back
  affordance, the page title or breadcrumb, and a step indicator if the screen is part of a flow.
  These tell the user where they are; they are not content.
- **In a container, always:** everything else. Every control, every value, every group of settings.
  A single lone control is still content and still belongs on a Layer 1 surface.

This is the boundary §12's anti-pattern "do not scatter controls directly across the atmospheric
background" is drawing. It bans *controls* on the background, not the title and back arrow — those
are correct there, and a real DACC screen shows exactly that: back arrow, "Easy Setup / Created
Profile 1", and a four-step stepper sitting directly on the gradient, with every toggle, text field
and dropdown below them inside nested containers.

**Invariants**

- Never exceed 3 design layers
- **3 layers is a maximum, not a requirement** — use only as many layers as your content actually needs
- Nav pills and the content panel are **sibling Layer 1 elements** — nav pills are never nested inside the content panel
- Each deeper layer uses a visually distinct background token — never the same token at two consecutive layers
- Radius strictly decreases with depth: `surface_primary` → `surface_secondary` → `button_compact`
- Onboarding screens use max 2 layers and have no nav rail

## Icon Size Rules

Derived from analysis of 32 Figma frames. Two intentional sizes only.

| Context | Token | Value |
| --- | --- | --- |
| Nav pills, feature rows, primary buttons with icon | `var(--icon-size-lg)` | 24px |
| Back arrow, firmware alert, connection type tag, undo/redo toolbar | `var(--icon-size-sm)` | 16px |

**One Decision Rule**

> If the icon sits inside a nav pill, feature row, or button — use `var(--icon-size-lg)`.
> If the icon sits inline with text in a header row — use `var(--icon-size-sm)`.

**Invariants**

- Icon-to-label gap: always `var(--spacing-closely-coupled)` (8px)
- State is expressed by the container (background, border, gradient) — never by icon size
- Icon size never changes between default, hover, and selected states
- Never use any size other than `icon_size.lg` or `icon_size.sm`

## Colors

All values reference `BOO/design-systems/unity/components/tokens.css` as the single source of truth.

> For full contrast requirements (4.5:1 for body text, 3:1 for UI components and large text), see `BOO/global/accessibility-guides.md` §1.1.

---

#### The Core Model: 3 Surface Depths + 1 Action Layer

Every screen resolves to exactly this structure — no more, no less:

| Depth | Token / Variable | Light | Dark | Role |
|---|---|---|---|---|
| **App / window** | `--background-app` | `primitives.color.white_transparent.95` | `primitives.color.slate_transparent.900-95` | Window root, masthead, nav rail. Never a panel color. |
| **Content surface** | `--background-container-accent-subtle` | `primitives.color.white_transparent.60` | `primitives.color.blue_ue_transparent.500-60` | Major cards, settings panels. Semi-transparent over backdrop blur. ⚠️ Token name suggests accent use but resolves to correct values for content surface. |
| **Accent surface** | `--background-container-accent-base` | `primitives.color.white` + white border | `primitives.color.blue_ue.500` + `blue_ue.500` border | Feature cards, icon containers. |
| **Action / option tile** | `--tertiary-bg` + `--tertiary-stroke` | `var(--background-surface)` + `var(--background-track-base)` border | `var(--background-surface-action)` + `var(--border-container-accent)` border | Setting option tiles (Bright / Dark / Vivid pattern). Declare both variables per theme. |
| **Nav rail tile** | `--navigation/main-nav/default-background` | `var(--background-surface)` + `var(--background-track-base)` border | `var(--background-surface-action)` + `var(--border-container-accent)` border | Category nav items in the left rail. Same token values as action tile. |

**Budget: 3 surface depths per screen maximum. A 4th is a structural error.**

#### Atmospheric Body Background

Every app window carries the window gradient — always. The backdrop behind the app window uses a tinted surface color, never a flat white or neutral.

**App window — two-layer composition (both required):**
```css
.app-window {
  background-color: var(--background-app);   /* theme-aware base: white-95% light / dark-slate-75% dark */
  background-image: var(--gradient-window);  /* Figma-sourced gradient overlay — same for both modes */
}
```

Do not use the `background` shorthand — it drops the color layer. `--background-app` has a dark mode override in `[data-theme="dark"]` in `tokens.css`.

**Viewport backdrop** (behind the floating app window):
```css
body {
  background-color: var(--atmospheric-bg-color); /* Screen-Level Constant in tokens.css */
}
```

> `--atmospheric-gradient-1` and `--atmospheric-gradient-2` have been removed. See `screen-constants-source.md` for documentation.

#### Card Shadow

Content panels use a per-theme `--card-shadow` variable. These values are now in `BOO/design-systems/unity/components/tokens.css` under the Screen-Level Constants section.

```css
:root, [data-theme="light"] {
  --card-shadow: 0px 4px 60px 12px rgba(6,114,203,0.1);
}
[data-theme="dark"] {
  --card-shadow: 0px 4px 157px 0px rgba(0,0,0,0.25);
}
```

Apply with `box-shadow: var(--card-shadow)` on Layer 1 panels. See screen-constants-source.md for full documentation.

#### Tertiary Background & Stroke (Action Tiles)

Setting option tiles use `--tertiary-bg` and `--tertiary-stroke`. These values are now in `BOO/design-systems/unity/components/tokens.css` under the Screen-Level Constants section.

```css
:root, [data-theme="light"] {
  --tertiary-bg: var(--background-surface);
  --tertiary-stroke: var(--background-track-base);
}
[data-theme="dark"] {
  --tertiary-bg: var(--background-surface-action);
  --tertiary-stroke: var(--border-container-accent);
}
```

Apply to action tiles and nav rail items. See screen-constants-source.md for full documentation.

#### 4 Rules That Cannot Be Broken

**1 — Brand blue is for action and selection only.**

| Use | Token | Light → primitive | Dark → primitive |
|---|---|---|---|
| Primary button, toggle on, nav accent bar | `--background-brand-base` | `blue.600` | `blue.600` |
| Hover / emphasis | `--background-brand-emphasis` | `blue.700` | `blue.700` |
| Active nav item fill | `--background-neutral-emphasis` | `blue.100` | `slate.600` |
| Selection / active tile | `gradient.button_selected` | `linear-gradient(120.33deg, #0672cb 0.46%, #0078d4 0.46%, #6e69cf 118.31%)` | ← same |

Never flood a surface, panel, or background with `--background-brand-base`. Never use the gradient outside of a selected tile.

---

**2 — Dividers are always brand-tinted whisper, never solid gray.**

| Token | Light → primitive | Dark → primitive |
|---|---|---|
| `--border-divider` | `light_blue_transparent.600-20` | `light_blue_transparent.100-20` |

One pixel. Every horizontal separator — masthead bottom, card rows, section breaks — uses this token. Never use `gray.300` or `gray.600` as a divider.

---

**3 — Dark mode has exactly three text colors. Never use a single white for all.**

| Role | Token | Light → primitive | Dark → primitive | Notes |
|---|---|---|---|---|
| All primary text, headings, card titles | `--foreground-default` | `gray.900` | `gray.100` | |
| Secondary metadata, descriptions | `--foreground-neutral` | `gray.800` | `gray.400` | |
| Tertiary helper, captions | `--foreground-neutral-subtle` | `gray.600` | `gray.500` | |
| Links / text actions | `--foreground-interactive-base` | `blue.700` | `blue.400` | |
| Text actions on filled accent cards | `--foreground-interactive-contrast` | `light_blue.200` | `light_blue.200` | |
| Brand-tinted subtitle | `--foreground-brand-accent` | `blue.700` | `gray.100` | Section subtitles, model numbers. ⚠️ `--foreground-brand-subtle` does not exist in yaml — use `--foreground-brand-accent`. |
| Text on any filled surface | `--foreground-on-fill` | `gray.100` | `gray.100` | |

Using `white` or `--foreground-default` for metadata and descriptions is the most common AI error in this system.

> Light mode secondary text is `gray.800`. Dark mode secondary is `gray.400`. Never use a single white for all dark mode text.

---

**4 — Every element must explicitly declare its color token.**

Never rely on color inheritance. Every surface, text, border, and icon must include an explicit token:

```
background: var(--background-...);  ← explicit, never inherited
color: var(--foreground-...);        ← explicit, never inherited
border-color: var(--border-...);     ← explicit, never inherited
```

Inheritance breaks the token-based system and causes dark mode inconsistencies.

---

#### Quick Decision

```
What surface is this element sitting on?
  → Window root / masthead / nav rail  →  --background-app
  → Major card or settings panel       →  --background-container-accent-subtle
  → Brand-tinted feature card          →  --background-container-accent-base
  → Setting option tile (Bright/Dark/Vivid)  →  --tertiary-bg / --tertiary-stroke
  → Clickable tile inside a panel            →  --background-surface-action

What is this text doing?
  → Primary heading or label           →  --foreground-default
  → Description or metadata            →  --foreground-neutral
  → Caption or helper                  →  --foreground-neutral-subtle
  → On a filled (blue) surface         →  --foreground-on-fill
  → A link or text action              →  --foreground-interactive-base

Is this a border?
  → Panel outline                      →  --border-container-neutral
  → Option tile (light mode)           →  --tertiary-stroke (#d0e4eb)
  → Option tile (dark mode)            →  --tertiary-stroke (#1e3f6c)
  → Row separator / masthead bottom    →  --border-divider
  → Button (light mode)                →  --border-brand-base
  → Button (dark mode)                 →  --border-brand-inverse-base
  → Focus ring                         →  --border-focus-default  (purple.500, 2px)
```

## Typography

Use `Roboto` throughout. All values below reference `BOO/design-systems/unity/components/tokens.css` as the single source of truth.

---

#### The Core Model: 3 Tiers + 1 Interactive Layer

Every screen resolves to exactly this structure — no more, no less:

| Tier | Token | Size | Line Height | Weight | Letter Spacing | Role |
|---|---|---|---|---|---|---|
| **Structural** | `--font-header-1` | `var(--font-header-1-size)` | `var(--font-header-1-line-height)` | `var(--font-header-1-weight)` | `var(--font-header-1-letter-spacing)` | Where the user is (page/module title) |
| **Structural (homepage)** | `--font-header-2` | `var(--font-header-2-size)` | `var(--font-header-2-line-height)` | `var(--font-header-2-weight)` | `var(--font-header-2-letter-spacing)` | Homepage identity |
| **Content — section** | `--font-header-5` | `var(--font-header-5-size)` | `var(--font-header-5-line-height)` | `var(--font-header-5-weight)` | `var(--font-header-5-letter-spacing)` | What a section is (card/expander title) |
| **Content — body** | `--font-body-2` | `var(--font-body-2-size)` | `var(--font-body-2-line-height)` | `var(--font-body-2-weight)` | `var(--font-body-2-letter-spacing)` | What it does (description, label, body) |
| **Support** | `--font-caption` | `var(--font-caption-size)` | `var(--font-caption-line-height)` | `var(--font-caption-weight)` | `var(--font-caption-letter-spacing)` | Meta, captions |
| **Interactive** *(outside budget)* | `--font-button-2` | `var(--font-button-2-size)` | `var(--font-button-2-line-height)` | `var(--font-button-2-weight)` | `var(--font-button-2-letter-spacing)` | Every button label, every time |

**Budget: 3 reading tiers per screen maximum. A 4th is a structural error.**

#### Additional Tokens (Not in Budget — Specialist Use Only)

These tokens exist in `BOO/design-systems/unity/components/tokens.css` but are **not counted** against the 3-tier budget. Use only for the specific component contexts listed.

| Token | Size | Weight | Letter Spacing | When to use |
|---|---|---|---|---|
| `--font-subtitle-2` | `var(--font-subtitle-2-size)` | `var(--font-subtitle-2-weight)` | `var(--font-subtitle-2-letter-spacing)` | Label emphasis — item names in lists, selected nav labels. **Never** use `body-2 + font-weight:500`; use this instead. |
| `--font-header-6` | `var(--font-header-6-size)` | `var(--font-header-6-weight)` | `var(--font-header-6-letter-spacing)` | Small section heading when header-5 (20px) is too large — e.g. compact sidebars, dense settings rails. |
| `--font-body-3` | `var(--font-body-3-size)` | `var(--font-body-3-weight)` | `var(--font-body-3-letter-spacing)` | Dense data, alert text, form helper text. Same size as `button-2` but weight 400 — never mix them. |

---

#### 5 Rules That Cannot Be Broken

**1 — Weight signals role, not importance.**

| Weight | Token reference | Allowed on |
|---|---|---|
| `300` | `--font-header-1-weight` · `--font-header-2-weight` | Structural title only |
| `400` | `--font-header-5-weight` · `--font-body-2-weight` · `--font-body-3-weight` · `--font-caption-weight` | All informational, non-interactive text |
| `500` | `--font-button-2-weight` · `--font-subtitle-2-weight` · `--font-header-6-weight` | Everything clickable / activatable; label emphasis (subtitle-2 — list/nav item names, not form field labels) |
| `600` | *(no token — ad-hoc)* | Selected state in option tile group **only** |
| `700–900` | *(no token — hero numerics only)* | Single hero numeral when it is the screen's sole purpose |

Never raise weight on a heading to make it "feel stronger." Never use `600+` on body or headings.

⚠️ **Common trap:** `body-2` (16px / 400) and `subtitle-2` (16px / 500) are the same pixel size. Never write `font-size: var(--font-body-2-size); font-weight: 500` — that contradicts `body-2`'s own weight token. Use `--font-subtitle-2` instead.

---

**2 — Letter spacing by token.**

| Token | Value | Applied to |
|---|---|---|
| `--font-header-1-letter-spacing` | `0px` | Page titles ≥ 32px |
| `--font-header-2-letter-spacing` | `0px` | |
| `--font-header-5-letter-spacing` | `0px` | |
| `--font-body-2-letter-spacing` | `0.08px` | Body, labels, descriptions |
| `--font-button-2-letter-spacing` | `0.07px` | All button labels |
| `--font-caption-letter-spacing` | `0.06px` | Meta, captions |

Do not invent new letter-spacing values. Read the token's real value from tokens.css — do not approximate
it as a flat `0.005em` across every role; the actual per-role values above are not uniform.

---

**3 — Dark mode text has three tiers. Never use a single white for all.**

| Role | Token | Resolved value |
|---|---|---|
| Titles / headings | `--foreground-default` | `primitives.color.gray.100` |
| Card body / content | `--foreground-default` | `primitives.color.gray.100` |
| Expander / meta / descriptions | `--foreground-neutral-contrast` | `primitives.color.slate.200` |
| Links / ghost buttons | `--foreground-interactive` | `primitives.color.light_blue.200` |
| Text on filled surface | `--foreground-on-fill` | `primitives.color.gray.100` |

Using `white` or `--foreground-default` for expander body and meta text is the most common AI error in this system.

---

**4 — Uppercase is allowed in exactly one confirmed place, with one open case.**

| Use | Size token | Letter Spacing | `text-transform` |
|---|---|---|---|
| Toggle label ("ON") | `--font-body-2-size` | `0.8px` *(component-specific)* | `uppercase` |

Nowhere else. Not headings, not card titles, not buttons, not body.

Open case: eyebrow-style uppercase copy above a heading (e.g. "WELCOME TO YOUR...") does appear in real
screens (see `02-archetype-bindings.yaml`), but there is no dedicated token backing it — a previous
version of this rule cited a `--type-overline` role that turned out to be invented, not sourced (see
decisions-log.yaml D-039, same class of finding as D-022's "label" role). Until the design system
confirms which real token (caption and button-3 are both uppercase-compatible size candidates) is meant
to back this use, do not add a second uppercase exception here — treat it as unresolved, not as
license to invent a value.

---

**5 — Every text element must explicitly declare its color token.**

Never rely on color inheritance. Every text element must include an explicit `color` property using the appropriate foreground token:

```
font-size: var(--font-...-size);
font-weight: var(--font-...-weight);
color: var(--foreground-...);  ← explicit, never inherited
```

This includes buttons, labels, captions, and all interactive elements. Inheritance breaks the token-based system and causes dark mode inconsistencies.

---

#### Quick Decision

```
What does the user DO with this text?

  Orient / navigate    →  --font-header-1   (48px / 300 / 0px)
  Understand section   →  --font-header-5   (20px / 400 / 0px)
  Read description     →  --font-body-2     (16px / 400 / 0.08px)
  Emphasise item name  →  --font-subtitle-2 (16px / 500 / 0.08px)  ← not body-2+500
  Dense / helper text  →  --font-body-3     (14px / 400 / 0.07px)
  Click / activate     →  --font-button-2   (14px / 500 / 0.07px)
  Reference meta       →  --font-caption    (12px / 400 / 0.06px)
  Form field label     →  --font-body-3     (14px / 400 / 0.07px)  ← no separate label role, see D-022

Is this the 4th reading size on this screen?
  → Stop. Reclassify into an existing tier.

Is weight above 500 on non-selected, non-hero text?
  → Stop. Drop to 400.

Is this dark mode meta/description text showing as white?
  → Change to --foreground-neutral-contrast.
```

