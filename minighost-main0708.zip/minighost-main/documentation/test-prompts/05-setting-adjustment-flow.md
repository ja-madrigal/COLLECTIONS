# Canonical Prompt — Flow 05: Setting Adjustment (3 Screens)

**Validation role:** Multi-screen flow test. Tests the agent's ability to manage a settings journey across three distinct screen types — hub navigation, settings detail with interactive controls, and save confirmation — without mixing frameworks, leaking chrome between screens, or placing configuration controls on the hub.

**Contributor instructions:** Use each screen prompt verbatim and in order. Do not add context, clarify the brief, or modify the wording. Run each in your branch sequentially. Capture the HTML output for each screen.

---

## Screen A — Hub

### Prompt

Generate the home screen for a Dell on-box PC management desktop app (Electron, 1132×782). Light mode.

The user has already signed in. They land on the home screen and want to adjust a display setting. The app manages battery, display, and presence detection settings for the device.

The screen is a hub — the user picks which capability area to enter. They are not configuring anything here. There are three capability areas: Battery, Display, and Presence Detection. Surface each as a navigable card. No configuration controls appear on this screen.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

### Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | User wants to adjust a display setting and needs to navigate to the right area |
| Primary action | Tap the Display capability card |
| Secondary action | Battery or Presence Detection card (alternate destinations) |
| User location | Home screen, post-login |
| Return path | None — this is the root screen |

**Expected components** (reviewer checklist — not shown to agent)
- `masthead` — app title + window controls
- `card-explore` or `card-main` — one per capability area (Battery, Display, Presence Detection)
- No settings controls, sliders, or toggles
- No onboarding progression

**What should NOT appear**
- Sliders, toggles, or any configuration controls
- Settings rail
- Onboarding steps or progress bar
- More than one primary button
- Per-feature data or current values

---

## Screen B — Settings Detail

### Prompt

Generate a Display settings screen for a Dell on-box PC management desktop app (Electron, 1132×782). Light mode.

The user has navigated here from the home screen by selecting Display. They want to change the display refresh rate. The current refresh rate is 60Hz. Available options are 60Hz, 120Hz, and 165Hz.

This is a focused settings screen. Show the setting label, current value, and a control to change it. Include a clear way to apply the change and a way to go back without saving. There is one setting on this screen — do not add unrelated controls.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

### Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | User is changing the display refresh rate from 60Hz to a higher value |
| Primary action | Apply / Save the new refresh rate |
| Secondary action | Cancel or navigate back without saving |
| User location | Display settings, one level below home |
| Return path | Back to home screen |

**Expected components** (reviewer checklist — not shown to agent)
- `masthead` or sub-header — with back navigation
- Setting label — "Refresh Rate" with description
- Control — dropdown, segmented control, or radio group for 60Hz / 120Hz / 165Hz
- Current value indicator — 60Hz shown as selected on arrival
- `button-primary` — Apply or Save
- `button-secondary` or `hyperlink` — Cancel or Back

**Expected data on screen**
- Setting: Refresh Rate
- Current value: 60Hz
- Options: 60Hz, 120Hz, 165Hz

**What should NOT appear**
- Other display settings (brightness, resolution, etc.) unless composing a settings list — one focused setting is the brief
- Hub cards or navigation tiles
- Onboarding progression
- More than one primary button

---

## Screen C — Confirmation

### Prompt

Generate a confirmation screen for a Dell on-box PC management desktop app (Electron, 1132×782). Light mode.

The user has just saved a change to their display refresh rate. The new value is 120Hz. The change has been applied successfully.

Show the user that their change was saved. The confirmed value (120Hz) should be visible in context — not on a blank screen. The user can navigate back to home from here. There is no primary action to take on this screen.

Generate the full HTML screen using Unity design tokens from `tokens.css`. Follow the 9-step generation sequence from the constitution. Emit the manifest block before the code.

---

### Reviewer Metadata

**Context**

| Field | Value |
|---|---|
| Intent | Confirm to the user that their refresh rate change was saved successfully |
| Primary action | None — user navigates back naturally |
| Secondary action | Back to home |
| User location | Display settings, post-save state |
| Return path | Back to home screen |

**Expected components** (reviewer checklist — not shown to agent)
- Success indicator — inline success state, toast, or status message; must use icon + color + text (not color alone)
- Confirmed value in context — "120Hz" visible on screen
- Back navigation — link, button, or masthead back control
- No primary CTA button

**Expected data on screen**
- Setting: Refresh Rate
- Saved value: 120Hz
- Success state: applied/saved

**What should NOT appear**
- A blank or empty screen with only a toast
- Another Save or Apply button
- Hub cards or navigation tiles
- Error states (this is the success path)
- Onboarding progression
