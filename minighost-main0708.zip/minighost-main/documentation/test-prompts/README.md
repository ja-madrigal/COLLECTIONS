# Validation Prompts

Canonical screen prompts used during the validation pass. All contributors use the same prompt for a given screen so outputs are comparable.

---

| # | Screen | File | Complexity |
|---|---|---|---|
| 01 | Login Form | [01-login-form.md](01-login-form.md) | Low — warmup |
| 02 | Peripheral Manager Home | [02-peripheral-manager-home.md](02-peripheral-manager-home.md) | Medium — hub screen |
| 03 | Fleet Management Dashboard | [03-fleet-dashboard.md](03-fleet-dashboard.md) | High — status grid at scale |
| 05 | Setting Adjustment Flow (3 screens) | [05-setting-adjustment-flow.md](05-setting-adjustment-flow.md) | High — multi-screen flow |

## How to use

1. Pick a screen. Open its prompt file.
2. Copy the prompt under the `## Prompt` heading verbatim — do not paraphrase or add context.
3. Run it against the agent in your own branch.
4. Capture the HTML output.
5. A reviewer walks the output against `documentation/pass-criteria.md` and logs results in `validation/screen-validation-results/{screen-name}-val{date}.html`.

## Order

Run screens in order: 01 → 02 → 03. Screen 01 is the warmup. Do not start 02 until 01 passes.
