#!/usr/bin/env python3
"""
build-tokens.py — Unity Design System token builder

Reads Figma JSON exports and generates canonical CSS + YAML outputs.

Inputs (project-relative):
  BOO/design-systems/unity/figma-exports/Light.tokens.json  — semantic, light mode
  BOO/design-systems/unity/figma-exports/Dark.tokens.json   — semantic, dark mode
  BOO/design-systems/unity/figma-exports/Token.tokens.json  — component tokens

Outputs:
  BOO/design-systems/unity/components/tokens.css            — canonical token source
  BOO/design-systems/unity/components/tokens-primitives.yaml — color palette reference

Usage:
  python scripts/build-tokens.py
"""

import json
import re
from pathlib import Path
from collections import defaultdict

# ── Paths ──────────────────────────────────────────────────────────────────

SCRIPT_DIR  = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
FIGMA_DIR   = PROJECT_ROOT / "BOO" / "design-systems" / "unity" / "figma-exports"
OUT_DIR     = PROJECT_ROOT / "BOO" / "design-systems" / "unity" / "components"

INPUT_LIGHT     = FIGMA_DIR / "Light.tokens.json"
INPUT_DARK      = FIGMA_DIR / "Dark.tokens.json"
INPUT_COMPONENT = FIGMA_DIR / "Token.tokens.json"

OUTPUT_CSS        = OUT_DIR / "tokens.css"
OUTPUT_PRIMITIVES = OUT_DIR / "tokens-primitives.yaml"

# ── Non-color token constants (typography, shadows, etc.) ──────────────────
# These are not in Figma exports and are manually maintained here.
# Edit this section when design system specs change.

TYPOGRAPHY_CSS = """\
  /* ── TYPOGRAPHY SCALE (DDS2) ────────────────────────────────────────── */
  --font-family-base: 'Roboto', sans-serif;
  --font-variation-settings: "wdth" 100;

  /* Display */
  --font-display-1-size: 72px;
  --font-display-1-line-height: 88px;
  --font-display-1-weight: 300;
  --font-display-1-letter-spacing: -1.08px;

  --font-display-2-size: 64px;
  --font-display-2-line-height: 76px;
  --font-display-2-weight: 300;
  --font-display-2-letter-spacing: -0.64px;

  --font-display-3-size: 56px;
  --font-display-3-line-height: 68px;
  --font-display-3-weight: 300;
  --font-display-3-letter-spacing: -0.28px;

  --font-display-1-xs-size: 56px;
  --font-display-1-xs-line-height: 68px;
  --font-display-1-xs-weight: 300;
  --font-display-1-xs-letter-spacing: -0.28px;

  --font-display-2-xs-size: 48px;
  --font-display-2-xs-line-height: 56px;
  --font-display-2-xs-weight: 300;
  --font-display-2-xs-letter-spacing: 0px;

  --font-display-3-xs-size: 40px;
  --font-display-3-xs-line-height: 48px;
  --font-display-3-xs-weight: 300;
  --font-display-3-xs-letter-spacing: 0px;

  /* Headers */
  --font-header-1-size: 48px;
  --font-header-1-line-height: 56px;
  --font-header-1-weight: 300;
  --font-header-1-letter-spacing: 0px;

  --font-header-2-size: 40px;
  --font-header-2-line-height: 48px;
  --font-header-2-weight: 300;
  --font-header-2-letter-spacing: 0px;

  --font-header-3-size: 32px;
  --font-header-3-line-height: 40px;
  --font-header-3-weight: 300;
  --font-header-3-letter-spacing: 0px;

  --font-header-4-size: 24px;
  --font-header-4-line-height: 32px;
  --font-header-4-weight: 400;
  --font-header-4-letter-spacing: 0px;

  --font-header-5-size: 20px;
  --font-header-5-line-height: 28px;
  --font-header-5-weight: 400;
  --font-header-5-letter-spacing: 0px;

  --font-header-6-size: 16px;
  --font-header-6-line-height: 24px;
  --font-header-6-weight: 500;
  --font-header-6-letter-spacing: 0.08px;

  --font-header-1-xs-size: 40px;
  --font-header-1-xs-line-height: 48px;
  --font-header-1-xs-weight: 300;
  --font-header-1-xs-letter-spacing: 0px;

  --font-header-2-xs-size: 32px;
  --font-header-2-xs-line-height: 40px;
  --font-header-2-xs-weight: 300;
  --font-header-2-xs-letter-spacing: 0px;

  --font-header-3-xs-size: 24px;
  --font-header-3-xs-line-height: 32px;
  --font-header-3-xs-weight: 400;
  --font-header-3-xs-letter-spacing: 0px;

  --font-header-4-xs-size: 20px;
  --font-header-4-xs-line-height: 28px;
  --font-header-4-xs-weight: 400;
  --font-header-4-xs-letter-spacing: 0px;

  --font-header-5-xs-size: 16px;
  --font-header-5-xs-line-height: 24px;
  --font-header-5-xs-weight: 500;
  --font-header-5-xs-letter-spacing: 0.08px;

  /* Subtitles */
  --font-subtitle-1-size: 24px;
  --font-subtitle-1-line-height: 36px;
  --font-subtitle-1-weight: 400;
  --font-subtitle-1-letter-spacing: 0px;

  --font-subtitle-2-size: 16px;
  --font-subtitle-2-line-height: 24px;
  --font-subtitle-2-weight: 500;
  --font-subtitle-2-letter-spacing: 0.08px;

  /* Body */
  --font-body-1-size: 24px;
  --font-body-1-line-height: 36px;
  --font-body-1-weight: 300;
  --font-body-1-letter-spacing: 0px;

  --font-body-2-size: 16px;
  --font-body-2-line-height: 24px;
  --font-body-2-weight: 400;
  --font-body-2-letter-spacing: 0.08px;

  --font-body-3-size: 14px;
  --font-body-3-line-height: 20px;
  --font-body-3-weight: 400;
  --font-body-3-letter-spacing: 0.07px;

  /* Buttons */
  --font-button-1-size: 16px;
  --font-button-1-line-height: 24px;
  --font-button-1-weight: 500;
  --font-button-1-letter-spacing: 0.08px;

  --font-button-2-size: 14px;
  --font-button-2-line-height: 24px;
  --font-button-2-weight: 500;
  --font-button-2-letter-spacing: 0.07px;

  --font-button-3-size: 12px;
  --font-button-3-line-height: 20px;
  --font-button-3-weight: 500;
  --font-button-3-letter-spacing: 0.06px;

  /* Caption */
  --font-caption-size: 12px;
  --font-caption-line-height: 20px;
  --font-caption-weight: 400;
  --font-caption-letter-spacing: 0.06px;

  --font-caption-strong-size: 12px;
  --font-caption-strong-line-height: 20px;
  --font-caption-strong-weight: 700;
  --font-caption-strong-letter-spacing: 0.18px;

  /* Lead */
  --font-lead-size: 20px;
  --font-lead-line-height: 30px;
  --font-lead-weight: 500;
  --font-lead-letter-spacing: 0.1px;\
"""

STRUCTURAL_CSS = """\
  /* ── SHADOWS (elevation) ─────────────────────────────────────────────── */
  --shadow-window: 0px 4px 4px 0px rgba(0, 0, 0, 0.06);
  --shadow-window-large: 0px 8px 8px 0px rgba(0, 0, 0, 0.06);
  --shadow-window-small: 0px 2px 2px 0px rgba(0, 0, 0, 0.06);
  --shadow-tooltip: 0px 4px 2px rgba(0, 0, 0, 0.18), 0px 2px 1px rgba(0, 0, 0, 0.14);
  --shadow-toast: 0px 4px 2px rgba(0, 0, 0, 0.04), 0px 2px 1px rgba(0, 0, 0, 0.02);
  --shadow-content-elevated: rgba(6, 114, 203, 0.10);

  /* ── GRADIENTS ───────────────────────────────────────────────────────── */
  --gradient-window: linear-gradient(235deg, rgba(48, 153, 199, 0.075), rgba(0, 99, 184, 0.075), rgba(0, 58, 206, 0.098), rgba(0, 185, 255, 0.075), rgba(0, 99, 184, 0.075));
  --gradient-splash-screen: linear-gradient(235deg, rgba(48, 153, 199, 0.075), rgba(0, 99, 184, 0.075), rgba(0, 58, 206, 0.098), rgba(0, 185, 255, 0.075), rgba(0, 99, 184, 0.075)), linear-gradient(90deg, rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.95));
  --gradient-button-selected: linear-gradient(119.07deg, #0672cb 0.46%, #0078d4 0.46%, #6e69cf 118.31%);

  /* ── RADIUS ──────────────────────────────────────────────────────────── */
  --radius-button: 2px;
  --radius-button-small: 4px;
  --radius-input: 4px;
  --radius-tooltip: 4px;
  --radius-card-special: 13px;
  --radius-window: 9px;
  --radius-surface-secondary: 8px;
  --radius-surface-primary: 16px;

  /* ── MOTION ──────────────────────────────────────────────────────────── */
  --motion-easing-in: cubic-bezier(0.4, 0, 1, 1);
  --motion-easing-out: cubic-bezier(0, 0, 0.2, 1);
  --motion-easing-in-out: cubic-bezier(0.4, 0, 0.2, 1);
  --motion-duration-fast: 0.15s;
  --motion-duration-default: 0.30s;
  --motion-duration-slow: 0.48s;

  /* ── Z-INDEX ─────────────────────────────────────────────────────────── */
  --z-base: 0;
  --z-raised: 10;
  --z-dropdown: 100;
  --z-sticky: 200;
  --z-overlay: 300;
  --z-modal: 400;
  --z-popover: 500;
  --z-tooltip: 600;
  --z-toast: 700;
  --z-notification: 800;

  /* ── LAYOUT CONSTANTS ────────────────────────────────────────────────── */
  --masthead-height: 64px;
  --category-rail-width: 212px;
  --nav-rail-width: 94px;\
"""

# Design system extras not in Figma variable exports.
# border-focus-default is the Dell accessibility focus ring — #a95adc, never changes.
EXTRAS_CSS = """\
  /* ── DESIGN SYSTEM EXTRAS (not in Figma variable exports) ───────────── */
  --border-focus-default: #a95adc;

  /* ── BUTTON SIZING (not in Figma color exports) ──────────────────────── */
  --button-size-small-height: 24px;
  --button-size-small-padding: 2px 6px;
  --button-size-small-gap: 4px;
  --button-size-small-radius: 4px;
  --button-size-default-height: 40px;
  --button-size-default-padding: 8px 12px;
  --button-size-default-gap: 10px;
  --button-size-default-radius: 2px;
  --button-size-large-height: 48px;
  --button-size-large-padding: 8px 18px;
  --button-size-large-gap: 10px;
  --button-size-large-radius: 2px;

  /* ── COMPONENT TOKEN ALIASES ─────────────────────────────────────────── */
  /* Radio-button: Figma nests tokens under a 'default' group; HTML omits it */
  --radio-button-background-default-unselected: var(--radio-button-default-background-default-unselected);
  --radio-button-text-default: var(--radio-button-default-text-default);
  --radio-button-fill-inner-selected: var(--radio-button-default-fill-inner-selected);
  --radio-button-background-rest-selected: var(--radio-button-rest-background-rest-selected);
  --radio-button-border-rest-unselected: var(--radio-button-rest-border-rest-unselected);
  --radio-button-border-hover-unselected: var(--radio-button-hover-border-hover-unselected);
  --radio-button-background-hover-selected: var(--radio-button-hover-background-hover-selected);
  --radio-button-background-pressed-selected: var(--radio-button-pressed-background-pressed-selected);
  --radio-button-border-pressed-unselected: var(--radio-button-pressed-border-pressed-unselected);
  /* Icon-button: HTML omits the redundant state suffix on the icon property */
  --icon-button-hover-icon: var(--icon-button-hover-icon-hover);
  --icon-button-pressed-icon: var(--icon-button-pressed-icon-pressed);
  /* Textbox: selection highlight name mismatch */
  --textbox-selection-background-highlight: var(--textbox-selection-background-highlight-selection);
  /* Masthead / Window: title bar foreground */
  --masthead-title-bar: var(--foreground-default);
  /* Content-layer: drop shadow */
  --content-layer-drop-shadow: var(--background-drop-shadow);\
"""

# ── Helpers ────────────────────────────────────────────────────────────────

def extract_css_value(token: dict) -> str:
    """Return a CSS color string from a Figma token (handles alpha)."""
    val = token["$value"]
    hex_color = val["hex"]
    alpha = val.get("alpha", 1.0)
    if abs(alpha - 1.0) < 0.001:
        return hex_color
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f"rgba({r}, {g}, {b}, {round(alpha, 2)})"


def semantic_to_css_var(category: str, name: str) -> str:
    """'Background', 'brand-base'  →  '--background-brand-base'"""
    return f"--{category.lower()}-{name}"


def ref_to_var(ref_name: str) -> str:
    """'Background/brand-base'  →  'var(--background-brand-base)'"""
    parts = ref_name.split("/")
    css_var = "--" + "-".join(p.lower().replace(" ", "-") for p in parts)
    return f"var({css_var})"


def path_to_css_var(path: list) -> str:
    """['Button', 'primary', 'background-default']  →  '--button-primary-background-default'"""
    parts = [p.lower().replace(" ", "-") for p in path]
    return "--" + "-".join(parts)


def flatten_tokens(data: dict, path: list = None):
    """Recursively yield (path_list, token_dict) for every leaf token."""
    if path is None:
        path = []
    for key, value in data.items():
        if key.startswith("$"):
            continue
        if isinstance(value, dict) and "$type" in value:
            yield path + [key], value
        elif isinstance(value, dict):
            yield from flatten_tokens(value, path + [key])


# ── Primitives extraction ──────────────────────────────────────────────────

# Regex to parse "Blue (DDS)/Solid/-Blue 600 - #0672CB" style names
_PRIMITIVE_RE = re.compile(
    r'^(?P<family>[A-Za-z][A-Za-z ]+?)(?:\s*\(DDS\))?'
    r'(?:/(?:Solid|Transparent))?'
    r'(?:/[^/]+)?'
    r'(?:\s*-\s*#(?P<hex>[0-9A-Fa-f]{6}))?'
    r'(?:\s*\((?P<pct>\d+)%\))?$'
)

def parse_primitive_name(target_name: str) -> dict | None:
    """
    Parse a Figma primitive targetVariableName into structured data.
    Returns dict with family, step (if numeric), hex, alpha, or None if unparseable.
    """
    # Extract step number from name
    step_match = re.search(r'\b(\d{3})\b', target_name)
    step = step_match.group(1) if step_match else None

    # Extract hex
    hex_match = re.search(r'#([0-9A-Fa-f]{6})', target_name)
    hex_val = "#" + hex_match.group(1).upper() if hex_match else None

    # Extract alpha percentage
    pct_match = re.search(r'\((\d+)%\)', target_name)
    alpha = round(int(pct_match.group(1)) / 100, 2) if pct_match else 1.0

    # Extract family
    family_match = re.match(r'^([A-Za-z][A-Za-z ]+?)(?:\s*\(DDS\))?(?:/|$)', target_name)
    if not family_match:
        return None
    family = family_match.group(1).strip().lower().replace(" ", "-")

    return {"family": family, "step": step, "hex": hex_val, "alpha": alpha}


def collect_primitives(files: list) -> dict:
    """
    Gather all unique primitive references from Figma files.
    Returns nested dict: {family: {step_or_key: {"hex": ..., "alpha": ...}}}
    """
    seen = {}  # target_variable_id → parsed primitive

    for path in files:
        with open(path) as f:
            data = json.load(f)
        for _token_path, token in flatten_tokens(data):
            ext = token.get("$extensions", {})
            alias = ext.get("com.figma.aliasData", {})
            target_id   = alias.get("targetVariableId", "")
            target_name = alias.get("targetVariableName", "")
            target_set  = alias.get("targetVariableSetName", "")

            if target_set != "Primitive Tokens" or not target_id:
                continue
            if target_id in seen:
                continue

            parsed = parse_primitive_name(target_name)
            if parsed and parsed["hex"]:
                seen[target_id] = {**parsed, "source_name": target_name}

    # Organise by family → list of steps
    families: dict[str, dict] = defaultdict(dict)
    for entry in seen.values():
        family = entry["family"]
        step   = entry["step"]
        hex_v  = entry["hex"]
        alpha  = entry["alpha"]
        key    = step if step else "base"
        # For transparent variants, suffix with alpha percentage
        if alpha < 1.0:
            key = f"{key}-{int(round(alpha * 100))}a"
        families[family][key] = {"hex": hex_v, "alpha": alpha}

    # Sort families and steps
    ordered = {}
    for fam in sorted(families.keys()):
        steps = families[fam]
        ordered[fam] = dict(sorted(steps.items(), key=lambda x: (x[0].split("-")[0].zfill(4), x[0])))

    return ordered


# ── CSS generation ─────────────────────────────────────────────────────────

def format_semantic_block(data: dict, categories: list, comment: str) -> str:
    lines = [f"\n  /* ── {comment} ──{'─' * max(0, 60 - len(comment))} */"]
    for cat in categories:
        if cat not in data:
            continue
        lines.append(f"  /* {cat} */")
        for name, token in data[cat].items():
            if not isinstance(token, dict) or "$value" not in token:
                continue
            css_var = semantic_to_css_var(cat, name)
            css_val = extract_css_value(token)
            lines.append(f"  {css_var}: {css_val};")
        lines.append("")
    return "\n".join(lines).rstrip()


def format_component_block(comp_data: dict) -> str:
    lines = ["\n  /* ── COMPONENT TOKENS ───────────────────────────────────────────────── */",
             "  /* Each references a semantic var — dark mode inherits automatically.    */"]

    # Group by top-level component name
    current_component = None
    for path, token in flatten_tokens(comp_data):
        if not path:
            continue
        component = path[0]
        if component != current_component:
            lines.append(f"\n  /* {component} */")
            current_component = component

        css_var = path_to_css_var(path)
        ext = token.get("$extensions", {})
        alias = ext.get("com.figma.aliasData", {})
        target_name = alias.get("targetVariableName", "")

        if target_name:
            # Reference the semantic var so dark mode resolves automatically
            css_val = ref_to_var(target_name)
            resolved = extract_css_value(token)
            lines.append(f"  {css_var}: {css_val}; /* {resolved} */")
        else:
            # No semantic alias — use the literal value
            css_val = extract_css_value(token)
            lines.append(f"  {css_var}: {css_val};")

    return "\n".join(lines)


def format_dark_overrides(light: dict, dark: dict, categories: list) -> str:
    lines = ["[data-theme=\"dark\"] {",
             "  /* ── SEMANTIC OVERRIDES — DARK MODE ─────────────────────────────────── */",
             "  /* Only tokens whose value differs from light mode are listed here.      */"]

    for cat in categories:
        if cat not in light or cat not in dark:
            continue
        cat_lines = []
        for name in light[cat]:
            if name not in dark[cat]:
                continue
            l_token = light[cat][name]
            d_token = dark[cat][name]
            if not isinstance(l_token, dict) or "$value" not in l_token:
                continue
            if not isinstance(d_token, dict) or "$value" not in d_token:
                continue
            light_val = extract_css_value(l_token)
            dark_val  = extract_css_value(d_token)
            if light_val != dark_val:
                css_var = semantic_to_css_var(cat, name)
                cat_lines.append(f"  {css_var}: {dark_val};")

        if cat_lines:
            lines.append(f"\n  /* {cat} */")
            lines.extend(cat_lines)

    lines.append("}")
    return "\n".join(lines)


def generate_css(light: dict, dark: dict, comp: dict) -> str:
    cats = ["Background", "Foreground", "Border"]

    header = """\
/* ============================================================
   Unity Design System — Canonical Tokens
   GENERATED FILE — do not edit directly.
   Source: BOO/design-systems/unity/figma-exports/
   Regenerate: python scripts/build-tokens.py

   STRUCTURE
   1. Typography scale (manually maintained in this script)
   2. Semantic tokens — light mode (generated from Light.tokens.json)
   3. Component tokens (generated from Token.tokens.json)
   4. Structural tokens: shadows, gradients, radius, motion,
      z-index, layout (manually maintained in this script)
   5. Design system extras (manually maintained)

   [data-theme="dark"] — semantic overrides only
   ============================================================ */

:root {"""

    semantic_light = format_semantic_block(light, cats, "SEMANTIC TOKENS — LIGHT (default)")
    component_block = format_component_block(comp)
    dark_block      = format_dark_overrides(light, dark, cats)

    return "\n".join([
        header,
        TYPOGRAPHY_CSS,
        semantic_light,
        component_block,
        "",
        STRUCTURAL_CSS,
        "",
        EXTRAS_CSS,
        "}",
        "",
        dark_block,
        "",
    ])


# ── YAML generation ────────────────────────────────────────────────────────

def generate_primitives_yaml(primitives: dict) -> str:
    lines = [
        "# Unity Design System — Primitive Color Palette",
        "# Extracted from Figma Primitive Tokens variable set.",
        "# This is a REFERENCE file — do not use primitives directly in component code.",
        "# Use semantic tokens (--background-*, --foreground-*, --border-*) instead.",
        "#",
        "# Format:",
        "#   hex: the resolved color value",
        "#   alpha: opacity (1.0 = fully opaque)",
        "",
        "primitives:",
    ]

    for family, steps in primitives.items():
        lines.append(f"  {family}:")
        for step, val in steps.items():
            if val["alpha"] < 1.0:
                lines.append(f"    {step}:")
                lines.append(f"      hex: \"{val['hex']}\"")
                lines.append(f"      alpha: {val['alpha']}")
            else:
                lines.append(f"    {step}: \"{val['hex']}\"")

    return "\n".join(lines) + "\n"


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    for path in [INPUT_LIGHT, INPUT_DARK, INPUT_COMPONENT]:
        if not path.exists():
            print(f"ERROR: {path} not found")
            raise SystemExit(1)

    with open(INPUT_LIGHT) as f:
        light = json.load(f)
    with open(INPUT_DARK) as f:
        dark = json.load(f)
    with open(INPUT_COMPONENT) as f:
        comp = json.load(f)

    # Generate tokens.css
    css = generate_css(light, dark, comp)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_CSS.write_text(css, encoding="utf-8")
    line_count = css.count("\n")
    var_count  = css.count("--")
    print(f"✓ {OUTPUT_CSS.relative_to(PROJECT_ROOT)}  ({line_count} lines, {var_count} vars)")

    # Generate tokens-primitives.yaml
    primitives = collect_primitives([INPUT_LIGHT, INPUT_DARK, INPUT_COMPONENT])
    yaml_out = generate_primitives_yaml(primitives)
    OUTPUT_PRIMITIVES.write_text(yaml_out, encoding="utf-8")
    fam_count = len(primitives)
    prim_count = sum(len(v) for v in primitives.values())
    print(f"✓ {OUTPUT_PRIMITIVES.relative_to(PROJECT_ROOT)}  ({fam_count} families, {prim_count} primitives)")


if __name__ == "__main__":
    main()
